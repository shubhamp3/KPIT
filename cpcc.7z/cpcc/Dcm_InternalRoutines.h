/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_InternalRoutines.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsl Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By             Description                 **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              As per CR #493                **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_INTERNALROUTINES_H
#define DCM_INTERNALROUTINES_H

#include "Dcm_Types.h"
#include "Dcm_DspDidConfig.h"
#include "Dcm_DspRoutineConfig.h"
#define Dcm_MemCpy MEMCPY
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#if ((DCM_RIDS_PRESENT == STD_ON)&&(STD_OFF == DCM_DSP_ENABLEOBDMIRROR))
typedef P2FUNC(boolean, DCM_CODE, Dcm_ReqRCIdValidate)
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ReqRCIdValidate, DCM_CONST) Dcm_GaaDspProcessRCTID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_InternalMemCpy
(

  P2CONST(uint8, AUTOMATIC, DCM_CONST) Src,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Dest,
  Dcm_MsgLenType Length
);

extern FUNC(void, DCM_CODE) Dcm_MemCpyByteByByte
(
  P2CONST(uint8, AUTOMATIC, DCM_CONST) Src,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Dest,
  Dcm_MsgLenType Length
);

extern FUNC(void, DCM_CODE) Dcm_UnpackDidOrRid
(
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpReqDID,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) DID
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ROEWriteNVData(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if (DCM_RIDS_PRESENT == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ExtractRidSignals
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) pRxUnpack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) ExtractedSignal,
  P2CONST(uint8, AUTOMATIC, DCM_CONST) OptionRecord

);

 extern FUNC(void, DCM_CODE) Dcm_PackRidSignals
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) SignalToPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) ResData
);

extern FUNC(boolean, DCM_CODE) Dcm_WriteRidLengthValidate
(
  P2CONST(Dcm_RoutineControlType, AUTOMATIC, DCM_CONST) LpRoutineControl,
  uint32 RidDataLen
);

extern FUNC(void, DCM_CODE)Dsd_ProcessRid
(
  P2CONST(Dcm_RoutineControlType, AUTOMATIC, DCM_CONST) LpRoutineControl,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dsp_RidSubfnValidateAndProcess
(
  P2CONST(Dcm_DspRidType, AUTOMATIC, DCM_CONST) pRidConfig,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(boolean, DCM_CODE) Dcm_UDSInterface
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#if(STD_ON == DCM_DSP_ENABLEOBDMIRROR)
extern FUNC(boolean, DCM_CODE)DCM_OBDService8ReqHandl
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
  #if(DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON)
  ,Dcm_OpStatusType OpStatus
  #endif
);
#endif
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#if(STD_OFF == DCM_DSP_ENABLEOBDMIRROR)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(boolean, DCM_CODE)DCM_OBDRCReqHandle
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  uint16 Rid
);

extern FUNC(boolean, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyRID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(boolean, DCM_CODE) Dcm_DspProcessNonAvialiabilityRID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint16,DCM_CODE)
Dcm_BinarySearch(
uint16 ID,
uint16 LusSize,
P2CONST(uint16, AUTOMATIC, DCM_CONST)Data);

extern FUNC(uint16, DCM_CODE) DataIdentiferSearch(uint16 DID);

extern FUNC(uint16, DCM_CODE) RouitneIdentiferSearch(uint16 RID);

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON)||\
    (DCM_DSP_OBDVEHINFO==STD_ON)||\
    (DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON))
extern FUNC(VAR(uint8, DCM_VAR),DCM_CODE)
Dcm_OBDBinarySearch(
uint8 ID,
uint32 LulSize,
uint8_least LucLow,
P2CONST(uint8, AUTOMATIC, DCM_CONST)Data) ;
#endif
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
