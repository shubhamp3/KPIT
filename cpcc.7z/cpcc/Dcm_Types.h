/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Types.h                                                   **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of  published structure definitions                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC fix           **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_TYPES_H
#define DCM_TYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Rte_Dcm_Type.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      DET ERROR CODES                                       **
*******************************************************************************/

/* Timeout is reported using following error code */
#define DCM_E_INTERFACE_TIMEOUT                                     (uint8)0x01

/* Buffer Overflow is reported using following error code */
#define DCM_E_INTERFACE_BUFFER_OVERFLOW                             (uint8)0x03

/* Dcm not initialized is reported using following error code */
#define DCM_E_UNINIT                                                (uint8)0x05

/*
 * Dcm API function with invalid input parameter is reported using following
 * error code
 */
#define DCM_E_PARAM                                                 (uint8)0x06
/*
 * Dcm API function with invalid pointer parameter is reported using following
 * error code
 */
#define DCM_E_PARAM_POINTER                                         (uint8)0x07
#define DCM_E_INIT_FAILED                                           (uint8)0x08
#define DCM_E_SET_PROG_CONDITIONS_FAIL                              (uint8)0x09
#define DCM_E_FORCE_RCRRP_IN_SILENT_COMM                            (uint8)0x0A

/*******************************************************************************
**                     Std_Types                                              **
*******************************************************************************/
#define DCM_E_PENDING              0x0Au

#define DCM_E_FORCE_RCRRP          0x0Cu

#define DCM_E_COMPARE_KEY_FAILED   0x0Bu

/* Unaccepted request */
#define E_REQUEST_NOT_ACCEPTED     0x08u

/*******************************************************************************
**                      Dcm_StatusType                                        **
*******************************************************************************/
/*Design ID : DCM_SDD_5030*/
typedef uint8 Dcm_StatusType;
#define DCM_E_OK (Dcm_StatusType)0x00


/******************************************************************************/

/* Length of diagnostic message (request, positive or negative response) */
/*Design ID : DCM_SDD_5043*/
typedef uint32 Dcm_MsgLenType;

/* Base type for diagnostic message item */
/*Design ID : DCM_SDD_5042*/
typedef uint8 Dcm_MsgItemType;

/* Base type for diagnostic message (request, positive or negative response) */
/*Design ID : DCM_SDD_5047*/
typedef Dcm_MsgItemType* Dcm_MsgType;

/*Design ID : DCM_SDD_5044*/
typedef uint8 Dcm_IdContextType;


/*Design ID : DCM_SDD_5045*/
typedef struct STag_Dcm_MsgAddInfoType
{
  /* To know if the request type is physical or functional */
  uint8 reqType:1;
  /* To know if the positive response is to be suppressed */
  boolean suppressPosResponse:1;

  /* To know if the Cancel operation is pending  */
  boolean cancelOperation:1;
}Dcm_MsgAddInfoType;


/*
 * This structure contains all information, which is necessary to process a
 * diagnostic message from request to response and response confirmation.
 */
 /*Design ID : DCM_SDD_5046*/
typedef struct STag_Dcm_MsgContextType
{
  /* Request data, starting directly after service identifier */
  Dcm_MsgType reqData;
  /* Request data length (excluding service identifier) */
  Dcm_MsgLenType reqDataLen;
  /* Positive response data, starting directly after service identifier */
  Dcm_MsgType resData;
  /* Positive response data length (excluding service identifier) */
  Dcm_MsgLenType resDataLen;
  /* The maximal length of a response */
  Dcm_MsgLenType resMaxDataLen;

  #if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
  /* Max page size */
  Dcm_MsgLenType ddMaxPagedResponseSize;

  /* Expected size of the paged response calculated at the outset of paged
     buffering */
  Dcm_MsgLenType ddExpResponseSize;

  /* Current size of the paged response */
  Dcm_MsgLenType ddCurrentRespSize;
  #endif
  /* Additional information about service request and response */
  Dcm_MsgAddInfoType msgAddInfo;
  /* Pdu Identifier on which the request was received */
  PduIdType dcmRxPduId;

    /*
   * This message context identifier can be used to determine the relation
   * between request and response confirmation
   */
  Dcm_IdContextType idContext;

  #if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
  uint8 ucROEConnectionIndex;
  #endif

}Dcm_MsgContextType;
/*******************************************************************************
**                      Dcm_CommunicationModeType                             **
*******************************************************************************/


/*******************************************************************************
**                      Dcm_ProgConditionsType                                **
**                      Design ID : DCM_SDD_5041                              **
*******************************************************************************/
typedef struct STag_Dcm_ProgConditionsType
{
  /* Tester source address configured per protocol */
  uint16 TesterSourceAddr;
  /* Id of the protocol on which the request has been received */
  uint8 ProtocolId;
  /* Service identifier of the received request */
  uint8 Sid;
  /* Identifier of the received subfunction */
  uint8 SubFncId;
  /* Set to true in order to request reprogramming of the ECU. */
  boolean ReprogramingRequest;
  /* Indicate whether the application has been updated or not.*/
  boolean ApplUpdated;
  /* Set to true in case the flashloader or application shall send a response.*/
  boolean ResponseRequired;
}Dcm_ProgConditionsType;
/*******************************************************************************
**                      Dcm_EcuStartModeType                                  **
**                    Design ID : DCM_SDD_5040                                **
*******************************************************************************/

typedef uint8 Dcm_EcuStartModeType;

#define DCM_COLD_START                                (Dcm_EcuStartModeType)0x00

#define DCM_WARM_START                                (Dcm_EcuStartModeType)0x01

/*******************************************************************************
**                      Dcm_ReturnWriteMemoryType                             **
**                       Design ID : DCM_SDD_5039                             **
*******************************************************************************/

typedef uint8 Dcm_ReturnWriteMemoryType;

#define DCM_WRITE_OK                            (Dcm_ReturnWriteMemoryType)0x00

#define DCM_WRITE_FAILED                        (Dcm_ReturnWriteMemoryType)0x02

#define DCM_WRITE_PENDING                       (Dcm_ReturnWriteMemoryType)0x01

#define DCM_WRITE_FORCE_RCRRP                   (Dcm_ReturnWriteMemoryType)0x03


/*******************************************************************************
**                      Dcm_ReturnReadMemoryType                              **
**                       Design ID : DCM_SDD_5038                             **
*******************************************************************************/

typedef uint8 Dcm_ReturnReadMemoryType;

#define DCM_READ_OK                             (Dcm_ReturnReadMemoryType)0x00

#define DCM_READ_PENDING                        (Dcm_ReturnReadMemoryType)0x01

#define DCM_READ_FAILED                         (Dcm_ReturnReadMemoryType)0x02

#define DCM_READ_FORCE_RCRRP                    (Dcm_ReturnReadMemoryType)0x03

/*****************************************************************************/








#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
