/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm.h                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Published file. Publishes all the functions necessary for     **
**              other BSW or SW-C modules i.e.,                               **
**              Dcm_Init()                                                    **
**              Dcm_MainFunction()                                            **
**              Dcm_GetSecurityLevel()                                        **
**              Dcm_GetSesCtrlType()                                          **
**              Dcm_GetVersionInfo()                                          **
**              Dcm_ SetActiveDiagnostic()                                    **
**              Dcm_TriggerOnEvent()                                          **
**              Dcm_DemTriggerOnDTCStatus()                                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/** Design ID : DCM_SDD_9652                                                  */

#ifndef DCM_H
#define DCM_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Dcm_Types.h"
#include "Dcm_PBTypes.h"
#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#include "Dem_Dcm.h"
#endif
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

#if (DCM_PRE_COMPILE_SINGLE == STD_OFF)
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern P2CONST(Dcm_ConfigType, AUTOMATIC, DCM_CONST) Dcm_GpConfigPtr;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/* SWS_Dcm_00037: */
extern FUNC(void, DCM_CODE) Dcm_Init
  (P2CONST(Dcm_ConfigType, AUTOMATIC, DCM_CONST) ConfigPtr);

/* Design ID :  DCM_SDD_5007 */
#if(DCM_VERSION_INFO_API == STD_ON)
extern FUNC(void, DCM_CODE) Dcm_GetVersionInfo
(
  P2VAR(Std_VersionInfoType, AUTOMATIC, DCM_APPL_DATA) versioninfo
);
#endif

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_GetSesCtrlType
(P2VAR(Dcm_SesCtrlType, AUTOMATIC, DCM_APPL_DATA) SesCtrlType);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SetActiveDiagnostic
(boolean active);


extern FUNC(Std_ReturnType, DCM_CODE) Dcm_GetSecurityLevel
(
  P2VAR(Dcm_SecLevelType,AUTOMATIC,DCM_APPL_DATA) SecLevel
);

extern FUNC(Std_ReturnType,DCM_CODE)
Dcm_ResetToDefaultSession(void);



#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_TriggerOnEvent
(
  uint8 RoeEventId
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DemTriggerOnDTCStatus
(
  uint32 DTC,
  Dem_UdsStatusByteType DTCStatusOld,
  Dem_UdsStatusByteType DTCStatusNew
);
#endif
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_RESPONSE_FROM_MAINFUNC_ENABLED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)Dcm_DslReponseMainFunctionNRC(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
