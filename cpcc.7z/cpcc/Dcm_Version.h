/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Version.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Macros for inter-module version check                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_VERSION_H
#define DCM_VERSION_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/
/* AUTOSAR SPECIFICATION VERSION */
#define DCM_VERSION_AR_RELEASE_MAJOR_VERSION        4
#define DCM_VERSION_AR_RELEASE_MINOR_VERSION        2
#define DCM_VERSION_AR_RELEASE_REVISION_VERSION     2

/* SOFTWARE VERSION INFORMATION */
#define DCM_VERSION_SW_MAJOR_VERSION                1
#define DCM_VERSION_SW_MINOR_VERSION                3

#define DCM_DET_AR_RELEASE_MAJOR_VERSION            4
#define DCM_DET_AR_RELEASE_MINOR_VERSION            2

#define DCM_SCHM_AR_RELEASE_MAJOR_VERSION           4
#define DCM_SCHM_AR_RELEASE_MINOR_VERSION           2
#define DCM_RTE_AR_RELEASE_MAJOR_VERSION            4
#define DCM_RTE_AR_RELEASE_MINOR_VERSION            2

#define DCM_DEM_AR_RELEASE_MAJOR_VERSION            4
#define DCM_DEM_AR_RELEASE_MINOR_VERSION            2

#define DCM_COMM_AR_RELEASE_MAJOR_VERSION           4
#define DCM_COMM_AR_RELEASE_MINOR_VERSION           2

#define DCM_PDUR_AR_RELEASE_MAJOR_VERSION           4
#define DCM_PDUR_AR_RELEASE_MINOR_VERSION           2

#define DCM_NVM_AR_RELEASE_MAJOR_VERSION            4
#define DCM_NVM_AR_RELEASE_MINOR_VERSION            2

#define DCM_IOHWAB_AR_RELEASE_MAJOR_VERSION         4
#define DCM_IOHWAB_AR_RELEASE_MINOR_VERSION         2

#define DCM_BSWM_AR_RELEASE_MAJOR_VERSION           4
#define DCM_BSWM_AR_RELEASE_MINOR_VERSION           2

#define DCM_DLT_AR_RELEASE_MAJOR_VERSION            4
#define DCM_DLT_AR_RELEASE_MINOR_VERSION            2

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#endif /* DCM_VERSION_H */




/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
