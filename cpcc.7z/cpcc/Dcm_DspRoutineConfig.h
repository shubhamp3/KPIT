/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspRoutineConfig.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager                      **
**                                                                            **
**  PURPOSE   : To provide Dsp routine declarations to other components       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Macro Definitions                                     **
**                 Design ID : DCM_SDD_5137                                   **
*******************************************************************************/
#ifndef DCM_DSPROUTINECONFIG_H
#define DCM_DSPROUTINECONFIG_H

#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"

#if(DCM_RIDS_PRESENT == STD_ON)
#define DCM_INVALID_RID                            0xFFFFu
#define DCM_ROUTINE_START_IN_STATIC                    0x01u
#define DCM_ROUTINE_START_IN_DYNAMIC                   0x02u
#define DCM_ROUTINE_STOP_IN_STATIC                     0x03u
#define DCM_ROUTINE_STOP_IN_DYNAMIC                    0x04u
#define DCM_ROUTINE_DEFAULT                            0xFFu
#define DCM_OBD_RID_START                          0xE000u
#define DCM_OBD_RID_END                            0xE0FFu

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/**
  Name: Dcm_GaaRidMapping
  Type: Mapping array
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine, DcmDspRoutineIdentifier,
  DcmDspRoutineUsed
  Description: This array shall contain a mapping between
  DcmDspRoutine->DcmDspRoutineIdentifier
  and a consecutive range of numbers.
  Because of the fact first 0x0000-0x00FF Did ranges are ISO reserved, and only
  values from 0x00FF onwards are earmarked for use for legislative purposes
  or by vehicle manufacturers, this mapping doesn't start from 0. It starts
  from the first Did configured. For example, if 0x0100 is the lowest Did
  configured, then Dcm_GaaRidMapping[] shall consider this as the first ID to
  be mapped, and shall map it to zero.

  If 0x0100, 0x0102, 0x0107 are DcmDspRoutineIdentifiers configured the mapping
  array shall be Dcm_GaaRidMapping[] shall be,

  Dcm_GaaRidMapping[] =
  {
    Rid 0x0100
    0x00,

    Rid 0x0101
    DCM_INVALID_RID,

    Rid 0x0102
    0x01,

    Rid 0x0103
    DCM_INVALID_RID,

    Rid 0x0104
    DCM_INVALID_RID,

    Rid 0x0105
    DCM_INVALID_RID,

    Rid 0x0106
    DCM_INVALID_RID,

    Rid 0x0107
    0x02
  };

  A valid mapping shall be provided only if DcmDspRoutineUsed is configured as
  true.

**/

/*Design ID : DCM_SDD_6074*/
#define DCM_START_SEC_CONST_16
#include "Dcm_MemMap.h"
extern CONST(uint16, DCM_CONST) Dcm_GaaRidMapping[];
#define DCM_STOP_SEC_CONST_16
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaInSignalType[]
  Type: Dcm_InSignalType
  Tool Generated?: Yes
  Configuration Dependencies:
  DcmDspRoutine->DcmDspStartRoutine->DcmDspStartRoutineIn->
  DcmDspStartRoutineInSignal
  DcmDspRoutine->DcmDspStopRoutine->DcmDspStopRoutineIn->
  DcmDspStopRoutineInSignal
  Generation Description: The array of structures contains information
  about all the instances of the "In" signals configured for this
  RoutineControlType.

  Sorting: All "In" signals belonging to a particular DcmDspStartRoutineIn and
   a particular DcmDspStopRoutineIn will be generated together.
   Within these, all "In" signals that require processing shall be generated
   before those that do not require any processing.
**/

#if(DCM_ROUTINE_IN_SIGNALS_PRESENT == STD_ON)
/*Design ID : DCM_SDD_0963*/
typedef struct STag_DcmInSignalType
{
  /* This shall point to the relevant entry in Dcm_GaaRxUnpack[]. If processing
     is not required, (see notes on processing within Dcm_RxUnpackType),
     NULL_PTR shall be generated */
  #if(DCM_ROUTINE_IN_SIGNALS_WITH_PROCESSING == STD_ON)
  P2CONST(Dcm_RxUnpackType, DCM_CONST, DCM_CONST) pRxUnpack;
  #endif
  /* See the description for ddPosInBytes. Here DcmDspDidDataPos replaced by
     DcmDspRoutineSignalLength for DcmDspStartRoutineInSignal and
     DcmDspStopRoutineInSignal. */
  PduLengthType ddInSignalPos;
  #if(DCM_ROUTINE_IN_SIGNALS_WITH_PROCESSING == STD_ON)
    PduLengthType ddInSignalRamPos;
  #endif
}Dcm_InSignalType;

/* Design ID : DCM_SDD_6145 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_InSignalType, DCM_CONST) Dcm_GaaInSignalType[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_OutSignalType[]
  Type: Dcm_OutSignalType
  Tool Generated?: Yes
  Configuration Dependencies:
  DcmDspRoutine->DcmDspStartRoutine->DcmDspStartRoutineOut->
  DcmDspStartRoutineOutSignal
  DcmDspRoutine->DcmDspStopRoutine->DcmDspStopRoutineOut->
  DcmDspStopRoutineOutSignal
  DcmDspRoutine->DcmDspStopRoutine->DcmDspRequestRoutineResultsOut->
  DcmDspRequestRoutineResultsOutSignal

  Generation Description: The array of structures contains information
  about all the instances of the "In" signals configured for this
  RoutineControlType.

   Sorting: All "Out" signals belonging to a particular DcmDspStartRoutineOut or
   DcmDspStopRoutineOut or  DcmDspRequestRoutineResultsOutwill be generated
   together.
   Within these, all "Out" signals that require processing shall be generated
   before those that do not require any processing.
**/

#if(DCM_ROUTINE_OUT_SIGNALS_PRESENT == STD_ON)
/*Design ID : DCM_SDD_0964*/
typedef struct STag_DcmOutSignalType
{
  #if(DCM_ROUTINE_OUT_SIGNALS_WITH_PROCESSING == STD_ON)
  /* Points to the relevant Dcm_GaaTxPack[]. If processing is not required (see
  notes on Dcm_GaaTxPack[] to know the conditions for processing), this pointer
  shall be generated as NULL_PTR. */
  P2CONST(Dcm_TxPackType, DCM_CONST, DCM_CONST) pTxPack;
  #endif
   /* See the description for ddPosInBytes. Here DcmDspDidDataPos replaced by
     DcmDspRoutineSignalLength for DcmDspStartRoutineOutSignal and
     DcmDspStopRoutineOutSignal. */
  PduLengthType ddOutSignalPos;
  #if(DCM_ROUTINE_OUT_SIGNALS_WITH_PROCESSING == STD_ON)
  PduLengthType ddOutSignalRamPos;
  #endif

}Dcm_OutSignalType;

/* Design ID : DCM_SDD_6146 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_OutSignalType, DCM_CONST) Dcm_GaaOutSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

/**
  Name: Dcm_GaaRoutineControl[]
  Type: Dcm_RoutineControlType
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine->DcmDspRequestRoutineResults,
  DcmDspRoutine->DcmDspStartRoutine,
  DcmDspRoutine->DcmDspStopRoutine.
  Generation Description: The array of structures contains information
  about all the instances of "RoutineControlType" i.e.,
  DcmDspRequestRoutineResults, DcmDspStartRoutine, DcmDspStartRoutine.

  Sorting: All the RoutineControlTypes belonging to the same DcmDspRoutine are
  listed together. They are also listed in the order of the corresponding
  sub-functions i.e., the following order:
  1. DcmDspStartRoutine,
  2. DcmDspStopRoutine,
  3. DcmDspRequestRoutineResults.
**/

/*Design ID : DCM_SDD_0965*/
typedef struct STag_Dcm_RoutineControlType
{

  #if(DCM_ROUTINE_IN_SIGNALS_PRESENT == STD_ON)
  /* Pointer to the first instance Dcm_GaaInSignal[] allocated to this
     RoutineControlType. If there are no "in" signals i.e.,
     DcmDspStartRoutineInSignal or DcmDspStopRoutineInSignal depending on the
     RoutineControlType, this pointer shall be NULL_PTR. */
  P2CONST(Dcm_InSignalType, DCM_CONST, DCM_CONST) pInSignal;

    /* The total number of bytes occupied by the "In" signals allocated to this
     RoutineControlType. This could come from either DcmDspStopRoutineInSignal
     or DcmDspStartRoutineInSignal. The total bytes occupied depends on a lot
     of properties of each Insignal. Refer to the generation of RxUnpack
     for further details. */
  PduLengthType ddTotalInSignalLen;

  #endif
  #if(DCM_ROUTINE_OUT_SIGNALS_PRESENT == STD_ON)
  /* Pointer to the first instance Dcm_GaaOutSignal[] allocated to this
     RoutineControlType. If there are no "in" signals i.e.,
     DcmDspStartRoutineOutSignal or DcmDspStopRoutineInSignal or
     DcmDspRequestRoutineResultsOutSignal depending on the
     RoutineControlType, this pointer shall be NULL_PTR. */
  P2CONST(Dcm_OutSignalType, DCM_CONST, DCM_CONST) pOutSignal;

 /* The total number of bytes occupied by the "Out" signals allocated to this
 RoutineControlType. This could come from either DcmDspStopRoutineOutSignal
 or DcmDspStartRoutineOutSignal or DcmDspRequestRoutineResultsOutSignal.
 The total bytes occupied depends on a lot of properties of each Insignal.
 Refer to the generation of TxPack for further details. */
  PduLengthType ddTotalOutSignalLen;

  #endif
  /* Similar to ulSubServiceSesVector in Dcm_DsdSubService. The parameter
     DcmDsdSubServiceSecurityLevelRef is replaced here by

     DcmDspRequestRoutineResults->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSessionRef
     OR
      DcmDspStopRoutine->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSessionRef
      OR
     DcmDspStartRoutine->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSessionRef

     depending on the RoutineControlType */

  uint32 ulRoutineSesVector;
  /* Similar to ulSubServiceSecLevVector in Dcm_DsdSubService. The parameter
     DcmDsdSubServiceSessionLevelRef is replaced here by

     DcmDspRequestRoutineResults->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSecurityLevelRef
     OR
      DcmDspStopRoutine->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSecurityLevelRef
      OR
     DcmDspStartRoutine->
     DcmDspRequestRoutineResultsCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSecurityLevelRef

     depending on the RoutineControlType */
  uint32 ulRoutineSecVector;


  #if(DCM_ROUTINE_IN_SIGNALS_PRESENT == STD_ON)

  /* No. of "In" signals (either DcmDspStopRoutineInSignal or
    DcmDspStartRoutineInSignal), that require unpack processing. */
  uint8 ucNoOfInSigForProcessing;
  #endif

  #if(DCM_ROUTINE_OUT_SIGNALS_PRESENT == STD_ON)


  /* No. of "Out" signals (either DcmDspStopRoutineOutSignal or
    DcmDspStartRoutineOutSignal or DcmDspRequestRoutineResultsOutSignal),
    that require unpack processing. */
  uint8 ucNoOfOutSigForProcessing;
  #endif

  /* Index of Dcm_GaaRoutineCtrlExec[] relevant for this
     RoutineControlType. */
  uint8 ucRoutineControlExecute;

    /*
    Configuration dependencies:
    DcmDspRoutine->DcmDspStartRoutine->DcmDspStartRoutineIn
      OR
    DcmDspRoutine->DcmDspStopRoutine->DcmDspStopRoutineIn
    For RequestResults Type Defaults to DCM_ROUTINE_DEFAULT
    For a particular StartRoutine if all Insignals are fixed length then type
    equals to  DCM_ROUTINE_START_IN_STATIC
    For a particular StartRoutine if any one of the signal type is
    VARIABLE_LENGTH then type equals to  DCM_ROUTINE_START_IN_DYNAMIC
    For Stop Routine same as StartRoutine but element name differ.
    */
  uint8 ucRoutineType;

}Dcm_RoutineControlType;

/* Design ID : DCM_SDD_6181 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RoutineControlType, DCM_CONST) Dcm_GaaRoutineControl[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_RoutineCtrlExecType)
(
  P2CONST(Dcm_RoutineControlType, AUTOMATIC, DCM_CONST) LpRoutineControl,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LusNRC
);
/**
  Name: Dcm_GaaRoutineCtrlExec[]
  Type: Dcm_RoutineCtrlExecType
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine->DcmDspRequestRoutineResults,
  DcmDspRoutine->DcmDspStartRoutine,
  DcmDspRoutine->DcmDspStopRoutine.
  Generation Description: The array of function pointers contains
  points to the tool generated functions that actually perform the
  Stop, Start or RequestRoutineResults actions.
  See file 'Dcm_RoutineCtrlExec.c' for details about the functions.

  Sorting: All the functions belonging to the same DcmDspRoutine are
  listed together. They are also listed in the order of the corresponding
  sub-functions i.e., the following order:
  1. Function corresponding to DcmDspStartRoutine,
  2. Function corresponding to DcmDspStartRoutine
  3. Function corresponding to DcmDspRequestRoutineResults.
**/

/*Design ID : DCM_SDD_7608*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RoutineCtrlExecType, DCM_CONST) Dcm_GaaRoutineCtrlExec[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/**
  Name: Dcm_GaaDspRid[]
  Type: Dcm_DspRidType
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine, DcmDspRoutine->
  DcmDspRoutineIdentifier, DcmDspRoutineUsed
  Generation Description: This array of structures contains basic description
  about all the routines configured in Dcm.  It also contains further references
  RoutineControlType related data. This structure shall be instantiated for
  every instance of DcmDspRoutine with DcmDspRoutineUsed TRUE.
  Sorting: This shall be sorted according to the corresponding
  mapping array i.e., Dcm_GaaRidMapping[].
**/

/*Design ID : DCM_SDD_0966*/




/**
  Name: Dcm_GaaRoutineCtrlRef[]
  Type: Pointer to Dcm_RoutineControlType
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine,
  DcmDspRoutine->DcmDspRequestRoutineResults,
  DcmDspRoutine->DcmDspStartRoutine,
  DcmDspRoutine->DcmDspStopRoutine
  Generation Description:This is an array of pointers to Dcm_GaaRoutineControl[]
  It shall contain 3 pointers per DcmDspRoutine. The pointers shall
  be arranged in the same order as the sub-functions i.e.,
  a. Start
  b. Stop
  c. RequestRoutineResults

  If any of the sub-functions are not configured, the corresponding instance
  of Dcm_GaaRoutineCtrlRef[] shall be NULL_PTR.

**/
/*Design ID : DCM_SDD_7609*/
/* Design ID : DCM_SDD_6147 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern P2CONST(Dcm_RoutineControlType, AUTOMATIC, DCM_CONST)
Dcm_GaaRoutineCtrlRef[];
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
