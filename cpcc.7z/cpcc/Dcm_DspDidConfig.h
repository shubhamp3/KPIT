/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspDidConfig.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions related to DIDs        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for Structure padding **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPDIDCONFIG_H
#define DCM_DSPDIDCONFIG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_PBTypes.h"
#include "Dcm_DspInternalTypes.h"
#include "NvM.h"

/*******************************************************************************
**                      Macro Definitions                                     **
**                  Design ID : DCM_SDD_5134                                  **
*******************************************************************************/
#define DCM_INVALID_DID 0xFFFFu
#define DCM_INVALID_INTERNAL  0xFFu
#define DCM_INVALID_SESSION_MASK  0xFFFFFFFFu

#define DCM_DID_STATIC 0x01u
#define DCM_DID_DYNAMIC 0x02u
#define DCM_DID_RANGE 0x03u
#define DCM_DSP_DID_CURRENT_SESSION 0xF186u
#define DCM_DSP_DID_PERIODIC_LOW_RANGE 0xF200u
#define DCM_DSP_DID_PERIODIC_HIGH_RANGE 0xF2FFu
#define DCM_DSP_DID_IOCTRL_MASKU8      0x00000080u
#define DCM_DSP_DID_IOCTRL_MASKU16     0x00008000u
#define DCM_DSP_DID_IOCTRL_MASKU32     0x80000000u
#define DCM_IO_INITIAL                0x05u
#define DCM_IO_RETURNCTRLECU          0x07u
#define DCM_IO_RESETTODEFAULT         0x01u
#define DCM_IO_FREZZECURRENTSTAE      0x02u
#define DCM_IO_SHORTTERMADJUST        0x04u
/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
/**
  Name: Dcm_GaaTxPack[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidSignal, DcmDspDidSignal->DcmDspData
  Generation Description: This shall be instantiated
  a. per instance of DcmDspData with a non-null pDspDataRead
  which requires processing, and shall be referred from Dcm_GaaDspDidSignal.
  Hence the sorting does not matter.
  b. per instance of DcmDspStopRoutineOutSignal that requires processing
  c. per instance of DcmDspStartRoutineOutSignal that requires processing
  d. per instance of DcmDspRequestRoutineResultsOutSignal

  Note: All the following elements are generated exactly the same for cases
  b, c, and d, except that

  DcmDspDataEndianness  is replaced by DcmDspRoutineSignalEndianness
  DcmDspDataSize is replaced by DcmDspRoutineSignalLength
  DcmDspDidDataPos is replaced by DcmDspRoutineSignalPos
  DcmDspDataType is replaced by DcmDspRoutineSignalType
  DcmDspDataDefaultEndianness is used as before

**/

/* Structure for Tx Pack */
/*Design ID : DCM_SDD_0946*/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
typedef struct STag_Dcm_TxPack
{
  /* Signal type or size of the signal. Higher nibble represents the type of the
  signal and Lower nibble represents the size of the signal that is spread
  across I-PDU. Generation tool should generate the value based on the following
  formulae:
    0x11     8 bit signal pack into one byte
    0x12     8 bit signal pack into two byte
    0x22    16 bit signal pack into two byte
    0x23    16 bit signal pack into three byte
    0x33    24 bit signal pack into three byte
    0x34    24 bit signal pack into four byte
    0x44    24  bit signal pack into four byte
    0x45    32 bit signal pack into five byte
    0x0x    uint8[x], uint32[x], uint16[x], sint8[x], sint32[x], sint16[x]
    To determine how many bytes a particular data spreads across depends on the
    following characteristics:
    DcmDspDataSize, DcmDspDidDataPos.
    For example, if the DcmDspDidDataPos is 6, and DcmDspDataSize is 8, then
    the data begins at 6th bit in the response and ends at the 14th bit.
    Hence it spreads across 2 bytes.
    Incremental implementation:
    Endianness also plays a role in this but this will be done in the next
    cycles. Right now we are only considering Little Endian signals in a
    Little Endian System.

    */
  PduLengthType ddSigTypeOrSize;

  /* Index of the write function pointer array. Generation tool should allocate
  the array index based on the type of the signal and size of the network signal
  that is spread across an I-PDU.



  There shall be following pack functions:
  Dcm_PackOneByte: For packing data of less than or equal to one byte. For
  this ucWrFuncIndex shall be 0.
  Dcm_PackBytes: For packing data that spread across 2 and 4 bytes. For
  this ucWrFuncIndex shall be 1.
  Dcm_PackFiveBytes: For packing data that spread across 5 bytes. For
  this ucWrFuncIndex shall be 2.
  Dcm_PackByteOrdering: For packing data that spread across 2 and 4 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 3.
  Dcm_PackFiveByteOrdering: For packing data that spread across 5 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 4.
  Dcm_PackNBytes: For packing uint8_n/sint8_n data. For
  this ucWrFuncIndex shall be 5.
  Dcm_Pack2NBytes: For packing uint16_n/sint16_n data. For
  this ucWrFuncIndex shall be 6.
  Dcm_Pack4NBytes: For packing uint32_n/sint32_n data. For
  this ucWrFuncIndex shall be 7.
  Dcm_Pack2NBytesOrdering: For packing uint16_n/sint16_n data with
  endianness conversion. For this ucWrFuncIndex shall be 8.
  Dcm_Pack4NBytesOrdering: For packing uint32_n/sint32_n data with
  endianness conversion. For this ucWrFuncIndex shall be 9.

  For the example given above (6th starting bit, 8 bits) the ucWrFuncIndex
  shall be 2 i.e., Dcm_PackBytes.

  Endianness conversion becomes necessary if system endianness is different
  from DcmDspDataEndianness. If DcmDspDataEndianness is not configured, the
  endianness of all data shall be derived from DcmDspDataDefaultEndianness.
  System endianness can be found in the system's
  Platform_Types.h as CPU_BYTE_ORDER. If CPU_BYTE_ORDER is HIGH_BYTE_FIRST
  then the endian-ness of the system is BIG_ENDIAN. If it is LOW_BYTE_FIRST,
  then the endianness of the system is LITTLE_ENDIAN.

  Decision pending: How to fetch the system endianness.

  */
  uint8 ucWrFuncIndex;

  /*
    Number of shift bits. Generation tool should generate the value based on
    the offset position in an I-PDU.
    For LE data types: ucNoOfShiftBit means shifting in the starting byte.
    For example, suppose a data begins at 6th bit and is of length 8 bits.
    This means, to fit it in the first byte, we have to shift the data by
    6 bits.

    Extending this example. Suppose instead of 6, the starting bit 13, and
    the size is still 8. This means this data begins in the 2nd byte. In the
    2nd byte, it starts actually from 5th bit. Hence the  ucNoOfShiftBit shall
    be 0x05.

    For BE signals, the logic will be reverse and we will be shifting in the
    last byte of the signal.

    If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

    Hence ucNoOfShiftBit will be considered from the higher byte as 7.

  */
  uint8 ucNoOfShiftBit;

  /*
  Write start mask. Generation tool should generate the value based on the
  start position of the signal in an I-PDU i.e.., lowest byte for
  LE signals and highest byte for BE signals.

  When writing a (part of) data into a byte, we must make sure that the rest
  of the byte remains intact. For this purpose, we have a ucWrStartMask.

  Consider the above example. Data is starting at the 6th bit. It means that the
  first 6 bits could be occupied by another data. Hence we have to have a mask
  to retain that data. Hence this mask shall be 00011111b i.e., 0x1F.

  For BE systems, the StartMask will apply to the higher byte in the frame.

  If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

  Hence ucWrStartMask will be considered from the higher byte as 01111111 i.e.,
  the lowest 7 bits set.


  */
  uint8 ucWrStartMask;

  /*

  Write end mask. Generation tool should generate the value based on the end
  position of the signal in an I-PDU.

  This has the same logic as the ucWrStartMask except for the end byte.


  Consider the below examples.


  For Little Endian data in a Little Endian system:
  Data is starting at the 6th bit and ending
  at 13th bit. It means that the
  last 2 bits in the second byte be occupied by another data.

  Hence we have to have a mask
  to retain that data. Hence this mask shall be 11000000b i.e., 0xC0.

  For Big Endian data in a Little Endian system:
  If the data is starting at the 6th bit and ending
  at 13th bit. It means that the
  last 2 bits in the second byte be occupied by another data.

  Hence we have to have a mask
  to retain that data. Hence this mask shall be 11000000b i.e., 0xC0.

  For BE systems, the StartMask will apply to the higher byte in the frame.

  If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

  Hence ucWrStartMask will be considered from the higher byte as 01111111 i.e.,
  the lowest 7 bits set.

  */
  uint8 ucWrEndMask;

}Dcm_TxPackType;

/* Design ID : DCM_SDD_6152 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_TxPackType, DCM_CONST) Dcm_GaaTxPack[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_SCALINGSERVICE== STD_ON)

#if(DCM_DSP_SCALING_SENDERRECEVIER == STD_ON)
typedef struct STag_Dcm_DspScalingSendRecFuncs
{
  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.*/

  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pScalingSRReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );

}Dcm_DspScalingSendRecFuncs;

#endif
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if(DCM_DSP_SCALINGSERVICE == STD_ON)
#if((DCM_DSP_SCALING_SYNC_FUNC == STD_ON)||\
   (DCM_DSP_SCALING_ASYNC_FUNC == STD_ON)||\
   (DCM_DSP_SCALING_SENDERRECEVIER == STD_ON))
typedef struct STag_Dcm_DspScalingInformation
{
  #if(DCM_DSP_SCALING_SYNC_FUNC == STD_ON)
  /*
   Default value: NULL_PTR.
   If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as DataServices_{Data}_GetScalingInformation where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in pReadSyncScalingData. */
   P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadSyncScalingData)
   (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) pErrorCode
   );
  #endif
  #if(DCM_DSP_SCALING_ASYNC_FUNC == STD_ON)
   /*
   Default value: NULL_PTR.
   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER and
   USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
   be generated as DataServices_{Data}_GetScalingInformation where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC and USE_DATA_ASYNCH_FNC_ERROR,
   it shall be the function name in pReadASyncScalingData. */
   P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadASyncScalingData)
   (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) pErrorCode
   );
  #endif

  #if(DCM_DSP_SCALING_SENDERRECEVIER == STD_ON)
  /*PointerReference to SenderReceiver Array*/
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pDspScalingSRSignal)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );
  #endif

  /*DcmDspScalininfosize*/
  uint32 ulScalingSize;

}Dcm_DspScalingInformation;

/* Design ID : DCM_SDD_6132 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspScalingInformation, DCM_CONST) Dcm_GaaDspDidScalingFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif
#endif

#if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
     (DCM_DSP_REQ_UPLOAD == STD_ON)||\
(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON) ||\
(DCM_DSP_SCALINGSERVICE == STD_ON)||\
(DCM_DSP_IO_CONTROL == STD_ON))
/* Design ID : DCM_SDD_6113 */
#define DCM_START_SEC_VAR_INIT_16
#include "Dcm_MemMap.h"
  /* Unnecessary check? */
 extern VAR(uint16, DCM_VAR_INIT) Dcm_GusWriteIoPendingDid;
#define DCM_STOP_SEC_VAR_INIT_16
#include "Dcm_MemMap.h"
#endif

typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DspMask8FuncPtrType)
(Dcm_OpStatusType OpStatus,
uint8 IoControlMask,
uint8 controlMask,
P2VAR(uint8, AUTOMATIC, DCM_VAR)ControlStateInfo,
uint16 DataLength,
P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode);


typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DspMask16FuncPtrType)
(Dcm_OpStatusType OpStatus,
uint8 IoControlMask,
uint16 controlMask,
P2VAR(uint8, AUTOMATIC, DCM_VAR)ControlStateInfo,
uint16 DataLength,
P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode);


typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DspMask32FuncPtrType)
(Dcm_OpStatusType OpStatus,
uint8 IoControlMask,
uint32 controlMask,
P2VAR(uint8, AUTOMATIC, DCM_VAR)ControlStateInfo,
uint16 DataLength,
P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode);
/**
  Name: Dcm_GaaRxUnpack[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidSignal, DcmDspDidSignal->DcmDspData
  Generation Description: This shall be instantiated for the following:
  a. per instance of DcmDspData with a non-null pDspDataWrite
  (if processing is required) and shall be referred
  from Dcm_GaaDspDidSignal. Hence the sorting does not matter.

  b. per instance of  DcmDspStopRoutineInSignal that requires processing

  c. per instance of  DcmDspStartRoutineInSignal that requires processing

**/
/* Structure for Tx Pack */
/*Design ID : DCM_SDD_0951*/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
typedef struct STag_Dcm_RxUnpack
{
  /*
    DcmDspDataSize is optional in case of primitive datatypes like:
    boolean: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 1
    uint8: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 8
    uint16: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 16
    uint32: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 32
    sint8: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 8
    sint16: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 16
    sint32: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 32
    The rest of the calculation remains identical.

    Signal Type based on the size of the signal configured via DcmDspDataSize
    Between 0 and 8 bits ucSignalType = 0
    Between 9 and 16 bits ucSignalType = 1
    Between 17 and 24 bits ucSignalType = 2
    Between 25 and 32 bits ucSignalType = 3
    If uint8_n, uint16_n, uint32_n,
    sint8_n, sint16_n, sint32_n, ucSignalType shall be 'n' i.e.,
    the number of bytes in case of uint8_n and sint8_n i.e.  DcmDspDataSize/8
    Number of words in case of sint16_n and uint16_n i.e.  DcmDspDataSize/16 ,
    Number of double-words in case of sint32_n, and  uint32_n i.e., i.e.
    DcmDspDataSize/32

    For DcmDspStopRoutineInSignal and DcmDspStartRoutineInSignal, the same
    logic applies, with DcmDspDataSize replaced by DcmDspRoutineSignalLength.

    Note that DcmDspRoutineSignalLength and DcmDspDataSize are optional in
    case of primitive datatypes like boolean. In case of boolean datatypes,
    the size has to be assumed to be 1 bit.
    */
  uint8 ucSignalType;

  /* Index of the read function pointer array. Depending upon the signal type
  and endianness, generation tool should generate the appropriate array index.

  There shall be following pack functions:
  Dcm_UnpackOneByte: For unpacking data of less than or equal to one byte. For
  this ucWrFuncIndex shall be 0.
  Dcm_UnpackBytes: For unpacking data that spread across 2 and 4 bytes. For
  this ucWrFuncIndex shall be 1.
  Dcm_UnpackFiveBytes: For unpacking data that spread across 5 bytes. For
  this ucWrFuncIndex shall be 2.
  Dcm_UnpackByteOrdering: For unpacking data that spread across 2 and 4 bytes
  with endianness conversion. For this ucWrFuncIndex shall be 3.
  Dcm_UnpackFiveByteOrdering: For unpacking data that spread across 5 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 4.
  Dcm_UnpackNBytes: For unpacking uint8_n/sint8_n data. For
  this ucWrFuncIndex shall be 5.
  Dcm_Unpack2NBytes: For unpacking uint16_n/sint16_n data. For
  this ucWrFuncIndex shall be 6.
  Dcm_Unpack4NBytes: For unpacking uint32_n/sint32_n data. For
  this ucWrFuncIndex shall be 7.
  Dcm_Unpack2NBytesOrdering: For unpacking uint16_n/sint16_n data with
  endianness conversion. For this ucWrFuncIndex shall be 8.
  Dcm_Unpack4NBytesOrdering: For unpacking uint32_n/sint32_n data with
  endianness conversion. For this ucWrFuncIndex shall be 9.

  For the example given above (6th starting bit, 8 bits) the ucWrFuncIndex
  shall be 2 i.e., Dcm_UnpackBytes.

  Endianness conversion becomes necessary if system endianness is different
  from DcmDspDataEndianness. If DcmDspDataEndianness is not configured, the
  endianness of all data shall be derived from DcmDspDataDefaultEndianness.
  System endianness can be found in the system's
  Platform_Types.h as CPU_BYTE_ORDER. If CPU_BYTE_ORDER is HIGH_BYTE_FIRST
  then the endian-ness of the system is BIG_ENDIAN. If it is LOW_BYTE_FIRST,
  then the endianness of the system is LITTLE_ENDIAN.

  For DcmDspStopRoutineInSignal and DcmDspStartRoutineInSignal, the same
    logic applies, with DcmDspDataSize replaced by DcmDspRoutineSignalLength,
  DcmDspDataEndianness replaced by DcmDspRoutineSignalEndianness.
  DcmDspDataDefaultEndianness is used as before.

  */
  uint8 ucRdFuncIndex;

  /* Number of shift bits. Generation tool should generate the value based on
  the configuration

  Again, which byte we consider for shifting depending on the endianness.

  The logic is the same as in TxPack structure.

  */
  uint8 ucNoOfShiftBits;


  /* End mask value. Generation tool should generate the end mask value based
  on the size of the network signal.

    End mask in unpack structure is the reverse of the end mask in TxPack i.e.,
    it has to be set for the bits the data occupies not reset.

    For example consider a signal that starts at the 6th bit and occupies
    8 bits. The signal is configured as a LE system i.e., coming in
    from a LE system. In that frame the last byte is the 2nd byte, and
    0-4 bits are occupied. Hence ucRdEndMask shall be 00011111b.

  */
  uint8 ucRdEndMask;



  /* This should be generated only for the
  signed data. For unsigned data it shall be generated as
  This shall be used for sign extension.

  For example, if a signed data of type sint16 contains only 13 bits,
  we have to convert it to full 16 bits i.e., we have to extend the sign
  by 3 bits. Hence the ucRdSignMask here is 11110000b i.e., 4 bits.
  It's 4 bits because it includes the sign bit as well.

 */
  uint8 ucRdSignMask;

  /* Size of the signal. Generation tool should generate the value based on the
  size of the signal spread across an I-PDU. This value is in bytes. */
  PduLengthType ddSignalSize;

}Dcm_RxUnpackType;


/* Design ID : DCM_SDD_6149 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RxUnpackType, DCM_CONST) Dcm_GaaRxUnpack[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/* All the following arrays/structure arrays shall be generated only if at
least one Did is present in the Dcm configuration i.e., at least one
DcmDspDid is present

*/

#if(DCM_DIDS_PRESENT == STD_ON)
/*Design ID : DCM_SDD_6063*/
#define DCM_START_SEC_CONST_16
#include "Dcm_MemMap.h"
extern CONST(uint16, DCM_CONST) Dcm_GaaDidMapping[];
#define DCM_STOP_SEC_CONST_16
#include "Dcm_MemMap.h"

#if(DCM_DATA_READ_CONFIGURED == STD_ON)
/* Having a uint32 array bit vector to store the status of all pending actions.
   There can at most be 3 actions in a pending signal:
   a. CheckReadFunction
   b. ReadLength
   c. Read
   Hence, at most three bits will have to be allocated per DID for read.
   (This may be reused for write as well, although in write there are only
   2 pending actions and maybe other services).

   It makes sense to store pending actions in a common array because
   a. Almost all services have pending actions
   b. They are all mutually exclusive

   Modelling it:

   a. Each pending action has a bit vector mask: If it is a ASYNC C/S or
      an ASYNC FNC interface, for instance.
      For example, if there is a DID which has a CheckReadFunction and is
      a dynamic signal, there shall be 3 actions and hence the mask i.e.,
      usPendingReadActionMask will have 3 bits set.
   b. It also has a position in Dcm_GaaCommonRamArea to indicate the
      word to use, since Dcm_GaaCommonRamArea is a shared variable i.e.,
      usPendingWordPos.

    Suppose there are 2 pending signals in a configuration both with all
    3 actions configured. Then 6 bits will have to be used to store the
    pending actions. Hence only one byte of Dcm_GaaCommonRamArea[]
    is sufficient.

    For the first pending signal:
    usPendingReadActionMask shall be 0000000000000000000000000111b
    and usPendingWordPos shall be 0.

    For the second pending signal:
    usPendingReadActionMask shall be 0000000000000000000000111000b
    and usPendingWordPos shall be 0.


  Suppose we have three sequential actions to be performed for a particular
  service.

*/


/*Design ID : DCM_SDD_5068*/
typedef struct STag_Dcm_DspPendingDids
{
  uint16 ddDid;
  uint32 ddPosInResp;
}Dcm_DspPendingDids;

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
typedef enum
{
  #if(DCM_SYNC_DATA_READ_CONFIGURED == STD_ON)
  DCM_SYNC_DATA_READ,
  #endif

  #if(DCM_ASYNC_DATA_READ_CONFIGURED == STD_ON)
  DCM_ASYNC_DATA_READ,
  #endif

  #if(DCM_ASYNC_DATA_READ_WITH_ERROR_CONFIGURED == STD_ON)
  DCM_ASYNC_ERROR_DATA_READ,
  #endif

  #if(DCM_NV_BLOCK_READ_CONFIGURED == STD_ON)
  DCM_NVM_BLOCK_ID_DATA_READ,
  #endif

  #if(DCM_ECU_SIGNAL_CONFIGURED == STD_ON)
  DCM_ECU_SIGNAL_DATA_READ,
  #endif

  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  DCM_DID_RANGE_READ,
  #endif

  #if(DCM_SR_DATA_READ_CONFIGURED == STD_ON)
  DCM_SR_DATA_READ,
  #endif

  DCM_0xF186_DATA_READ,

  DCM_DUMMY_DATA
}Dcm_DspSrcType;
#endif
/**
  Name: Dcm_GaaDidMapping
  Type: Mapping array
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDid, DcmDspDidRange
  Description: This array shall contain a mapping between
  DcmDspDid->DcmDspDidIdentifier,
  DcmDspDidRange->DcmDspDidRangeIdentifierLowerLimit, UpperLimit,
  DcmDspDidUsed.
  and a consecutive range of numbers.
  Because of the fact first 0x0000-0x00FF Did ranges are ISO reserved, and only
  values from 0x00FF onwards are earmarked for use for legislative purposes
  or by vehicle manufacturers, this mapping doesn't start from 0. It starts
  from the first Did configured. For example, if 0x0100 is the lowest Did
  configured, then Dcm_GaaDidMapping[] shall consider this as the first ID to
  be mapped, and shall map it to zero.

  If 0x0100, 0x0102, 0x0107 are DcmDspDidIdentifiers configured, and also
  suppose a DcmDspDidRange is also involved with
  DcmDspDidRangeIdentifierLowerLimit 0x0108 and UpperLimit 0x010C, the mapping
  array shall be Dcm_GaaDidMapping[] shall be,

  Dcm_GaaDidMapping[] =
  {
    Did 0x0100
    0x00,

   Did 0x0101
    DCM_INVALID_Did,

   Did 0x0102
    0x01,

   Did 0x0103
    DCM_INVALID_Did,

   Did 0x0104
    DCM_INVALID_Did,

   Did 0x0105
    DCM_INVALID_Did,

   Did 0x0106
    DCM_INVALID_Did,

   Did 0x0107
    0x02,

    DcmDspDidRange 0x0108 - 0x010C
    0x03,

    0x03,


    0x03,

    0x03,

    0x03

  };

  A valid mapping shall be provided only if DcmDspDidUsed is configured as
  true.

**/

/* Structure for reading 0xF186 */
/*Design ID : DCM_SDD_5069*/
typedef struct STag_Dcm_DspDid0xF186
{
  /* This shall always point to the function Dcm_Read0xF186() i.e.,
  it shall always be '&Dcm_ReadAndPack0xF186'. */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );

}Dcm_DspDid0xF186;

#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
 extern P2CONST(Dcm_DspDid0xF186,AUTOMATIC, DCM_CONST) Dcm_GstDspDid0xF186;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif
/*
    If DcmDspData->DcmDspDataUsePort is either USE_DATA_SENDER_RECEIVER or
    USE_DATA_SENDER_RECEIVER_AS_SERVICE, Dcm_GaaDspDidSendRecFuncs
    shall be generated for
    that DcmDspData
*/

/**
  Name: Dcm_GaaDspDidSendRecFuncs[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData->DcmDspDataUsePort, DcmDspDataReadFnc,
  DcmDspDataWriteFnc
  Generation Description: The array of structures contains function pointers
  to Read and Write.
  This has to be only generated if any DcmDspDid with DcmDspDidUsed
  refers to this DcmDspData.

**/
#if((DCM_SR_DATA_READ_CONFIGURED == STD_ON) || \
   (DCM_SR_DATA_WRITE_CONFIGURED == STD_ON))
/*Design ID : DCM_SDD_0948*/
typedef struct STag_Dcm_DspDidSendRecFuncs
{
  #if(DCM_SR_DATA_READ_CONFIGURED == STD_ON)
  /*
     Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.

     If DcmDspDataUsePort is USE_DATA_SENDER_RECEIVER  or
     USE_DATA_SENDER_RECEIVER_AS_SERVICE this shall
     be generated as Rte_Read_DataServices_{Data}_ReadData where
     Data is equal to the shortname of the relevant container DcmDspData.
*/
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );
  #endif

  #if(DCM_SR_DATA_WRITE_CONFIGURED == STD_ON)

  /*
    Default value: NULL_PTR.
     If none of the DIDs referring to this data have write configured,
     pWriteData will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_SENDER_RECEIVER or
     USE_DATA_SENDER_RECEIVER_AS_SERVICE this shall
     be generated as Rte_Write_DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.

     pWriteData will be filled for all Data with DcmDspDataType other than
   uint8_dyn. If a data is of type uint8_dyn, pWriteData will be
   generated as NULL_PTR  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data
  );
  #endif
}Dcm_DspDidSendRecFuncs;

/* Design ID : DCM_SDD_6134 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidSendRecFuncs, DCM_CONST) Dcm_GaaDspDidSendRecFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*
    If DcmDspData->DcmDspDataUsePort is either USE_DATA_SYNCH_CLIENT_SERVER or
    USE_DATA_SYNCH_FNC, Dcm_GaaDspDidSyncFuncs shall be generated for
    that DcmDspData
*/

/**
  Name: Dcm_GaaDspDidSyncFuncs[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData->DcmDspDataUsePort, DcmDspDataReadFnc
  Generation Description: The array of structures contains function pointers
  to Read, ReadCheck, and other functions.


    This has to be only generated if any DcmDspDid with DcmDspDidUsed
  refers to this DcmDspData.
**/
#if(DCM_SYNC_DATA_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0950*/
typedef struct STag_Dcm_DspDidSyncFuncs
{

  #if(DCM_SYNC_DATA_READ_CONFIGURED == STD_ON)
  #if(DCM_DSP_READ_CONDITION_CONFIGURED == STD_ON)
  /* Pointer to Xxx_ConditionCheckRead.

   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pConditionCheckReadFnc will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER and
   DcmDspDataConditionCheckReadFncUsed is TRUE,
   be generated as Rte_Call_DataServices_{Data}_ConditionCheckRead() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in DcmDspDataConditionCheckReadFnc.

   If DcmDspDataConditionCheckReadFncUsed is FALSE, this shall be NULL_PTR.

 */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pConditionCheckReadFnc)
  (
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CODE) pErrorCode
  );
  #endif
  #endif

  #if(DCM_DYN_DATA_READ == STD_ON)
  /* Pointer to Xxx_ReadDataLength if the data type is uint8_dyn.

    Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadDataLength will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as Rte_Call_DataServices_{Data}_ReadDataLength() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in DcmDspDataReadDataLengthFnc.

     */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadDataLength)
  (
    P2VAR(uint16, AUTOMATIC, DCM_CODE) DataLength
  );
  #endif


  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_ReadData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
     name in DcmDspDataReadFnc. */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );
  #endif
  #endif

  #if(DCM_SYNC_DATA_WRITE_CONFIGURED == STD_ON)

  /*
       Default value: NULL_PTR.
   If none of the DIDs referring to this data have write configured,
   pWriteData will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
     name in DcmDspDataWriteFnc.

     pWriteData will be filled for all Data with DcmDspDataType other than
   uint8_dyn. If a data is of type uint8_dyn, pWriteData will be
   generated as NULL_PTR  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CODE) pErrorCode
  );

  #if(DCM_DYN_DATA_WRITE == STD_ON)
  /*
     Default value: NULL_PTR.
     If none of the DIDs referring to this data have write configured,
     pWriteDynData will be NULL_PTR.

     If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
     name in DcmDspDataWriteFnc.
     pWriteDynData will be filled for all Data with DcmDspDataType uint8_dyn.
     If a data is of type other than uint8_dyn, pWriteDynData will be
     generated as NULL_PTR  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteDynData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    uint16 DataLength,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CODE) pErrorCode
  );
  #endif

  #endif


  #if(DCM_DYN_DATA == STD_ON)
   /* If this is a dynamic signal i.e., DcmDspDataType is UINT8_DYN,
      DcmDspDataSize shall indicate the maximum size. usDynDataMaxLength should
      be equal to DcmDspDataSize in bytes i.e. (DcmDspDataSize)/8 should
      be generated here. This shall only be used for dynamic signals */
  uint16 usDynDataMaxLength;
  #endif

}Dcm_DspDidSyncFuncs;

/* Design ID : DCM_SDD_6136 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidSyncFuncs, DCM_CONST) Dcm_GaaDspDidSyncFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaDspDidAsyncFuncs[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData->DcmDspDataUsePort, DcmDspDataReadFnc
  Generation Description: The array of structures contains function pointers
  to Read, ReadCheck, and other functions.

  If a particular instance of DcmDspData is not referred to by any DcmDspDid,
  that instance of DcmDspData shall be ignored.

  This has to be only generated if any DcmDspDid with DcmDspDidUsed
  refers to this DcmDspData.

**/

/*
    If DcmDspData->DcmDspDataUsePort is either USE_DATA_ASYNCH_CLIENT_SERVER or
    USE_DATA_ASYNCH_FNC, Dcm_DspDidAsyncFuncs shall be generated for
    that DcmDspData.


*/
#if(DCM_ASYNC_DATA_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0952*/
typedef struct STag_Dcm_DspDidAsyncFuncs
{
  #if(DCM_ASYNC_DATA_READ_CONFIGURED == STD_ON)

  #if(DCM_DSP_READ_CONDITION_CONFIGURED == STD_ON)
 /* Pointer to Xxx_ConditionCheckRead.
    Default value: NULL_PTR.
   If none of the DIDs referring to this data, have read configured,
   pConditionCheckReadFnc will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER and
   DcmDspDataConditionCheckReadFncUsed is TRUE,
   be generated as Rte_Call_DataServices_{Data}_ConditionCheckRead() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC, it shall be the function
   name in DcmDspDataConditionCheckReadFnc.

   If DcmDspDataConditionCheckReadFncUsed is FALSE, this shall be NULL_PTR.



 */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pConditionCheckReadFnc)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CODE) pErrorCode
  );
  #endif
  #endif


  #if(DCM_DYN_DATA_READ == STD_ON)
  /*
   Default value: NULL_PTR.

   Pointer to Xxx_ReadDataLength if the data type is uint8_dyn.

   If none of the DIDs referring to this data, have read configured,
   pReadDataLength will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER this shall
   be generated as Rte_Call_DataServices_{Data}_ReadDataLength() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC, it shall be the function
   name in DcmDspDataReadDataLengthFnc.

     */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadDataLength)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint16, AUTOMATIC, DCM_CODE) DataLength
  );
  #endif

  /*

    Default value: NULL_PTR.
   If none of the DIDs referring to this data, have read configured,
   pReadDataLength will be NULL_PTR.


    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_ReadData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC, it shall be the function
     name in DcmDspDataReadFnc. */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadData)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );
  #endif
  #endif

  #if(DCM_ASYNC_DATA_WRITE_CONFIGURED == STD_ON)

  /*

   Default value: NULL_PTR.
   If none of the DIDs referring to this data have write configured,
   pReadDataLength will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC, it shall be the function
     name in DcmDspDataWriteFnc.

     pWriteData will be filled for all Data with DcmDspDataType other than
   uint8_dyn.
     If a data is of type uint8_dyn, pWriteData will be generated as NULL_PTR */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  #if(DCM_DYN_DATA_WRITE == STD_ON)
  /*
    Default value: NULL_PTR.
    If none of the DIDs referring to this data have write configured,
    pReadDataLength will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC, it shall be the function
     name in DcmDspDataWriteFnc.
     pWriteDynData will be filled for all Data with DcmDspDataType uint8_dyn.
     If a data is of type other than uint8_dyn, pWriteDynData will be
     generated as NULL_PTR  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteDynData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    uint16 DataLength,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );
  #endif

  #endif

  #if(DCM_ASYNC_DATA_READ_CONFIGURED == STD_ON)
  /*

  Default value: 0
  This mask will allocate bits according to the actions
  configured for this data.

  The possible actions are:
  a. CheckReadFunction i.e., the function generated in pConditionCheckReadFnc
  b. ReadDataLen i.e., the function generated in pReadDataLength
  c. ReadData i.e., the function generated in pReadData

  All 3 may or may not be present in a configuration.
  A bit will be allocated to each action. Bits won't be allocated if
  the action is not at all configured. For example, if only
  CheckReadFunction and ReadData are configured i.e., DCM_DYN_DATA_READ is
  STD_OFF only 2 bits are allocated. If both DCM_DYN_DATA_READ and
  DCM_DSP_READ_CONDITION_CONFIGURED are off only 1 bit will be allocated
  for every instance of Dcm_DspDidAsyncFuncs.

  Suppose there are 2 Dcm_DspDidAsyncFuncs instances,
  Dcm_GaaDspDidAsyncFuncs[0] and Dcm_GaaDspDidAsyncFuncs[1].

  Both DCM_DYN_DATA_READ and DCM_DSP_READ_CONDITION_CONFIGURED are STD_ON.
  Hence 3 bits will be allocated per Dcm_DspDidAsyncFuncs[].

  Suppose for Dcm_GaaDspDidAsyncFuncs[0].pConditionCheckReadFnc is not
  NULL_PTR. Hence the right-most i.e., least significant bit shall be high.

  Suppose also Dcm_GaaDspDidAsyncFuncs[0].pReadDataLength is NULL_PTR. Hence
  the 2nd bit from right shall be low.

  pReadData is not NULL_PTR. Hence the 3rd bit from the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[0].usReadPendingMask =
    00000000000000000000000000000101b

  The mask then moves left by 3 bits i.e.,
 Suppose for Dcm_GaaDspDidAsyncFuncs[1].pConditionCheckReadFnc is
  NULL_PTR. Hence the right-most i.e., least significant bit shall be low.

  Suppose also Dcm_GaaDspDidAsyncFuncs[0].pReadDataLength is not NULL_PTR. Hence
  the 2nd bit from right shall be high.

  pReadData is not NULL_PTR. Hence the 3rd bit from the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[1].usReadPendingMask =
    00000000000000000000000000110000b */
  uint32 usReadActionsReqd;

  /*
  Default value: 0

  This will have only one the first bit of the mask allocated to this
   instance as high.

   Suppose the mask is 3 bits wide.

   For example, if the mask is 00000000000000000000000000000110b
   usReadMaskBit shall be 0x01.

   If the mask is 00000000000000000000000000110000b
   usReadMaskBit shall be 00000000000000000000000000001000b.
*/
  uint32 usPendingReadActionMask;

  /*
    Default value: 0


    usReadPendingPos is used along with usReadPendingMask to access the
     pending actions in a DID in the global variable Dcm_GaaGenPendingVector.
     Since there are 32 bits in usReadPendingMask, usReadPendingPos will be
     incremented based on the number of bits allocated in  usReadPendingMask.

     Suppose 2 bits are allocated in usReadPendingMask, each
     Dcm_GaaGenPendingVector[] can hold 32/2 = 16 statuses.

     Hence usReadPendingPos is incremented every 16 instances of
     Dcm_DspDidAsyncFuncs.

     If 1 bit is allocated, usReadPendingPos is incremented every (32/1)
     i.e., 32 instances of Dcm_DspDidAsyncFuncs.

     If 3 bits are allocated, usReadPendingPos is incremented every (32/3)
     i.e., 10 instances of Dcm_DspDidAsyncFuncs. The last two bits will
     not be used.

     */
  uint32 usReadPendingPos;

  #endif

  #if(DCM_DYN_DATA == STD_ON)
   /*
      Default value: 0.

      If this is a dynamic signal i.e., DcmDspDataType is UINT8_DYN,
      DcmDspDataSize shall indicate the maximum size. usDynDataMaxLength should
      be equal to DcmDspDataSize in bytes i.e. (DcmDspDataSize)/8 should
      be generated here. This shall only be used for dynamic signals */
  uint16 usDynDataMaxLength;
  #endif

  }Dcm_DspDidAsyncFuncs;

/* Design ID : DCM_SDD_6125 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidAsyncFuncs, DCM_CONST) Dcm_GaaDspDidAsyncFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaDspDidAsyncErrorFuncs[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData->DcmDspDataUsePort, DcmDspDataReadFnc
  Generation Description: The array of structures contains function pointers
  to Read, ReadCheck, and other functions.

  This has to be only generated if any DcmDspDid with DcmDspDidUsed
  refers to this DcmDspData.

**/
/*
    If DcmDspData->DcmDspDataUsePort is either
  USE_DATA_ASYNCH_CLIENT_SERVER_ERROR or USE_DATA_ASYNCH_FNC_ERROR,
  Dcm_DspDidAsyncFuncs shall be generated for that DcmDspData
*/

#if(DCM_ASYNC_DATA_WITH_ERROR_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0953*/
typedef struct STag_Dcm_DspDidAsyncErrorFuncs
{
  #if(DCM_ASYNC_DATA_READ_WITH_ERROR_CONFIGURED == STD_ON)

  #if(DCM_DSP_READ_CONDITION_CONFIGURED == STD_ON)
 /* Pointer to Xxx_ConditionCheckRead.

   Default value: NULL_PTR.
   If none of the DIDs referring to this data, have read configured,
   pConditionCheckReadFnc will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER_ERROR and
   DcmDspDataConditionCheckReadFncUsed is TRUE,
   be generated as Rte_Call_DataServices_{Data}_ConditionCheckRead() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC_ERROR, it shall be the function
   name in DcmDspDataConditionCheckReadFnc.

   If DcmDspDataConditionCheckReadFncUsed is FALSE, this shall be NULL_PTR.

 */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pConditionCheckReadFnc)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CODE) pErrorCode
  );
  #endif
  #endif

  #if(DCM_DYN_DATA_READ == STD_ON)
  /* Pointer to Xxx_ReadDataLength if the data type is uint8_dyn.

   Default value: NULL_PTR.
   If none of the DIDs referring to this data, have read configured,
   pReadDataLength will be NULL_PTR.

   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
   be generated as Rte_Call_DataServices_{Data}_ReadDataLength() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC_ERROR, it shall be the function
   name in DcmDspDataReadDataLengthFnc.

     */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadDataLength)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint16, AUTOMATIC, DCM_CODE) DataLength
  );

  #endif


  /*
    Default value: NULL_PTR.
   If none of the DIDs referring to this data, have read configured,
   pReadData will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
     be generated as Rte_Call_DataServices_{Data}_ReadData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC_ERROR,
   it shall be the function name in DcmDspDataReadFnc. */
  #if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadData)
 (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );
  #endif
  #endif

  #if(DCM_ASYNC_DATA_WRITE_WITH_ERROR_CONFIGURED == STD_ON)

  /*

   Default value: NULL_PTR.
   If none of the DIDs referring to this data have write configured,
   pWriteData will be NULL_PTR.


    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC_ERROR, it shall be the
   function name in DcmDspDataWriteFnc.

     pWriteData will be filled for all Data with DcmDspDataType other than
   uint8_dyn.
     If a data is of type uint8_dyn, pWriteData will be generated as NULL_PTR */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  #if(DCM_DYN_DATA_WRITE == STD_ON)
  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have write configured,
   pWriteDynData will be NULL_PTR.

    If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
     be generated as DataServices_{Data}_WriteData() where
     Data is equal to the shortname of the relevant container DcmDspData.
     If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC_ERROR,
   it shall be the function name in DcmDspDataWriteFnc.
     pWriteDynData will be filled for all Data with DcmDspDataType uint8_dyn.
     If a data is of type other than uint8_dyn, pWriteDynData will be
     generated as NULL_PTR  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteDynData)
 (
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Data,
    uint16 DataLength,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );
  #endif


  #endif


  #if(DCM_ASYNC_DATA_READ_WITH_ERROR_CONFIGURED == STD_ON)
  /*

  This mask will allocate bits according to the actions
  configured for this data.

  The possible actions are:
  a. CheckReadFunction i.e., the function generated in pConditionCheckReadFnc
  b. ReadDataLen i.e., the function generated in pReadDataLength
  c. ReadData i.e., the function generated in pReadData

  All 3 may or may not be present in a configuration.
  A bit will be allocated to each action. Bits won't be allocated if
  the action is not at all configured. For example, if only
  CheckReadFunction and ReadData are configured i.e., DCM_DYN_DATA_READ is
  STD_OFF only 2 bits are allocated. If both DCM_DYN_DATA_READ and
  DCM_DSP_READ_CONDITION_CONFIGURED are off only 1 bit will be allocated
  for every instance of Dcm_DspDidAsyncFuncs.

  Suppose there are 2 Dcm_DspDidAsyncFuncs instances,
  Dcm_GaaDspDidAsyncFuncs[0] and Dcm_GaaDspDidAsyncFuncs[1].

  Both DCM_DYN_DATA_READ and DCM_DSP_READ_CONDITION_CONFIGURED are STD_ON.
  Hence 3 bits will be allocated per Dcm_DspDidAsyncFuncs[].

  Suppose for Dcm_GaaDspDidAsyncFuncs[0].pConditionCheckReadFnc is not
  NULL_PTR. Hence the right-most i.e., least significant bit shall be high.

  Suppose also Dcm_GaaDspDidAsyncFuncs[0].pReadDataLength is NULL_PTR. Hence
  the 2nd bit from right shall be low.

  pReadData is not NULL_PTR. Hence the 3rd bit from the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[0].usReadPendingMask =
    00000000000000000000000000000101b

  The mask then moves left by 3 bits i.e.,
 Suppose for Dcm_GaaDspDidAsyncFuncs[1].pConditionCheckReadFnc is
  NULL_PTR. Hence the right-most i.e., least significant bit shall be low.

  Suppose also Dcm_GaaDspDidAsyncFuncs[0].pReadDataLength is not NULL_PTR. Hence
  the 2nd bit from right shall be high.

  pReadData is not NULL_PTR. Hence the 3rd bit from the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[1].usReadPendingMask =
    00000000000000000000000000110000b */
  uint32 usReadActionsReqd;

   /* This will have only one the first bit of the mask allocated to this
     instance as high.

     Suppose the mask is 3 bits wide.

     For example, if the mask is 00000000000000000000000000000110b
     usReadMaskBit shall be 0x01.

     If the mask is 00000000000000000000000000110000b
     usReadMaskBit shall be 00000000000000000000000000001000b.
  */
  uint32 usPendingReadActionMask;

  /* usReadPendingPos is used along with usReadPendingMask to access the
     pending actions in a DID in the global variable Dcm_GaaGenPendingVector.
     Since there are 32 bits in usReadPendingMask, usReadPendingPos will be
     incremented based on the number of bits allocated in  usReadPendingMask.

     Suppose 2 bits are allocated in usReadPendingMask, each
     Dcm_GaaGenPendingVector[] can hold 32/2 = 16 statuses.

     Hence usReadPendingPos is incremented every 16 instances of
     Dcm_DspDidAsyncFuncs.

     If 1 bit is allocated, usReadPendingPos is incremented every (32/1)
     i.e., 32 instances of Dcm_DspDidAsyncFuncs.

     If 3 bits are allocated, usReadPendingPos is incremented every (32/3)
     i.e., 10 instances of Dcm_DspDidAsyncFuncs. The last two bits will
     not be used.

     */
  uint32 usReadPendingPos;

  #endif

  #if(DCM_DYN_DATA == STD_ON)
   /* If this is a dynamic signal i.e., DcmDspDataType is UINT8_DYN,
      DcmDspDataSize shall indicate the maximum size. usDynDataMaxLength should
      be equal to DcmDspDataSize in bytes i.e. (DcmDspDataSize)/8 should
      be generated here. This shall only be used for dynamic signals */
  uint16 usDynDataMaxLength;
  #endif
}Dcm_DspDidAsyncErrorFuncs;

/* Design ID : DCM_SDD_6124 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidAsyncErrorFuncs, DCM_CONST)
        Dcm_GaaDspDidAsyncErrorFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_ECU_SIGNAL_CONFIGURED == STD_ON)
/*
    If any DcmDspData->DcmDspDataUsePort is USE_ECU_SIGNAL,
    Dcm_DspDidEcuSignal shall be generated.

    This has to be only generated if any DcmDspDid with DcmDspDidUsed
    refers to this DcmDspData.
*/
#if((DCM_READ_DID_SERVICE == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
/*Design ID : DCM_SDD_0949*/
typedef struct STag_Dcm_DspDidEcuSignal
{
  /* The name of this function shall be derived from
     the function configured in DcmDspDataEcuSignal.
  */
  P2FUNC(void, DCM_APPL_CODE, pReadData)
 (
   P2VAR(uint8 , AUTOMATIC, DCM_VAR)Data
  );

}Dcm_DspDidEcuSignal;

/* Design ID : DCM_SDD_6126 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidEcuSignal, DCM_CONST) Dcm_GaaDspDidEcuSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif

/*
    If DcmDspData->DcmDspDataUsePort is USE_BLOCK_ID, Dcm_DspDidNvMBlock shall
    be generated.

    This has to be only generated if any DcmDspDid with DcmDspDidUsed
    refers to this DcmDspData.
*/
#if(DCM_NV_BLOCK_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0955*/
typedef struct STag_Dcm_DspDidNvMBlock
{
  /* This shall be generated as the block id referred in DcmDspDataBlockIdRef */
  NvM_BlockIdType ddNvMBlockId;

/*Design ID : DCM_SDD_5028*/
}Dcm_DspDidNvMBlock;

/* Design ID : DCM_SDD_6129 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidNvMBlock, DCM_CONST) Dcm_GaaDspDidNvMBlock[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if(DCM_DATA_READ_CONFIGURED == STD_ON)
/**
  Name: Dcm_GaaDspDidRead[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo->DcmDspDidRead, DcmDidUsed
  Generation Description: This shall be instantiated per instance of
  DcmDspDidRead, and shall be referred from Dcm_GaaDspDidInfo. Hence
  the sorting does not matter. DcmDidUsed applies here also.

**/
/*Design ID : DCM_SDD_0954*/
typedef struct STag_Dcm_DspDidRead
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidReadSessionRef, then this field will be set as
     00000000000000000000000010011000b i.e., 0x00000098.

     Note: If the field DcmDspDidReadSessionRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulReadDidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidReadSecurityLevelRef, then this field will be set as
     010000000001001000000000000000000b i.e., 0x40120000

     Note: If the field DcmDspDidReadSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulReadDidSecLevVector;

}Dcm_DspDidRead;

/* Design ID : DCM_SDD_6131 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidRead, DCM_CONST) Dcm_GaaDspDidRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if(DCM_DSP_IO_CONTROL == STD_ON)
/**
  Name: Dcm_GaaDspDidRead[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo->DcmDspDidRead, DcmDidUsed
  Generation Description: This shall be instantiated per instance of
  DcmDspDidRead, and shall be referred from Dcm_GaaDspDidInfo. Hence
  the sorting does not matter. DcmDidUsed applies here also.

**/
/*Design ID : DCM_SDD_5070*/
typedef struct STag_Dcm_DspIoControl
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidControlSessionRef, then this field will be set as
     00000000000000000000000000000111b i.e., 0x00000007.

     Note: If the field DcmDspDidControlSessionRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulIODidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidControlSecurityLevelRef, then this field will be set as
     00000000000000000000000000000111b i.e., 0x00000007

     Note: If the field DcmDspDidControlSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulIODidSecLevVector;
   /* If the ucIoCtrlModeRuleIndex is configured that
  rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucIoCtrlModeRuleIndex;
  #endif

  /* this element has to be generated as per the DcmDspDidControlMask
     the follwing vaues has to be generated for coressponding literals
      if DCM_CONTROLMASK_NO -  0x00
         DCM_CONTROLMASK_EXTERNAL -0x01
         DCM_CONTROLMASK_INTERNAL -0x02
     default value - 0x02   */
  uint8 ucDcmDspDidControlMask;

  /* the duplicate value of DcmDspDidControlMaskSize */
  uint8 DcmDspDidControlMaskSize;

  /* Mask of InputOutputControlParameter i.e.,
     first bit possition is for returnControlToECU this is mandatory for all
     signals it should be seted for all DID'S defautly.

     second bit position is for resetToDefault this bit to set only if
   DcmDspDidResetToDefault is set to true for the corresponding DID.

   third bit  postion is for freezeCurrentState this bit has to be set only if
     DcmDspDidFreezeCurrentState is set to true for the corresponding DID.

     fourth bit  postion is for shortTermAdjustment this bit has to be set only
     if DcmDspDidShortTermAdjustment is set to true for the corresponding DID.
     EX:
   in DcmDspDidInfo->DcmDspDidControl if the DcmDspDidFreezeCurrentState and
      DcmDspDidShortTermAdjustment both are set to trur then the mask has to be
     generated as 0x0D

   Default value:0x01
   */
    uint8 ucIOCtrlParameter;


}Dcm_DspIoControl;

/* Design ID : DCM_SDD_6128 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspIoControl, DCM_CONST) Dcm_GaaDspDidIoCtrl[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON))
/**
  Name: Dcm_GaaDspDidWrite[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo->DcmDspDidWrite, DcmDidUsed.
  Generation Description: This shall be instantiated per instance of
  DcmDspDidWrite, and shall be referred from Dcm_GaaDspDidInfo. Hence
  the sorting does not matter.

**/
/*Design ID : DCM_SDD_0957*/
typedef struct STag_Dcm_DspDidWrite
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidWriteSecurityLevelRef, then this field will be set as
     00000000000000000000000010011000b i.e., 0x00000098.

     Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulWriteDidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidWriteSecurityLevelRef, then this field will be set as
     010000000001001000000000000000000b i.e., 0x40120000

     Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulWriteDidSecLevVector;

}Dcm_DspDidWrite;

/* Design ID : DCM_SDD_6137 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidWrite, DCM_CONST) Dcm_GaaDspDidWrite[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif
/**
  Name: Dcm_GaaDspDidInfo[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo, DcmDidUsed.
  Generation Description: This shall be instantiated per instance of
  DcmDspDidInfo, and shall be referred from Dcm_GaaDspDid. Hence
  the sorting does not matter. DcmDidUsed applies here also.

**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
/*Design ID : DCM_SDD_0956*/
typedef struct STag_Dcm_DspDidInfo
{
      #if(DCM_DSP_IO_CONTROL == STD_ON)
      P2CONST(Dcm_DspIoControl, DCM_CONST, DCM_CONST) pIoControl;
      #endif

    #if(DCM_DATA_READ_CONFIGURED == STD_ON)
     /* Pointer to read structure i.e., the relevant instance of
     Dcm_GaaDspDidRead if DcmDspDid->DcmDspDidInfo->DcmDspDidRead is
     configured for a particular Did. If no DcmDspDidRead is configured,
     pDidRead shall be generated as NULL_PTR. The element also shall be
     generated only if  at least a single instance of
     DcmDspDid->DcmDspDidInfo->DcmDspDidRead is configured. */
    P2CONST(Dcm_DspDidRead, DCM_CONST, DCM_CONST) pDidRead;
    #endif

  #if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||(DCM_DID_RANGE_WRITE_CONFIGURED))
   /* Pointer to write structure. If DcmDspDid->DcmDspDidInfoRef->DcmDspDidWrite
     is configured for a particular Did. If no DcmDspDidWrite is configured,
     pDidRead shall be generated as NULL_PTR. The element also shall be
     generated only if  at least a single instance of
     DcmDspDid->DcmDspDidInfo->DcmDspDidWrite is configured. */
  P2CONST(Dcm_DspDidWrite, DCM_CONST, DCM_CONST) pDidWrite;

 /* If the DcmDspDidWriteModeRuleRef is configured that
  rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucWriteModeRuleIndex;
  #endif
  #endif

   #if(DCM_DATA_READ_CONFIGURED == STD_ON)
  /* If the DcmDspDidReadModeRuleRef is configured that
     rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucReadModeRuleIndex;
  #endif
  #endif
}Dcm_DspDidInfo;

/* Design ID : DCM_SDD_6127 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidInfo, DCM_CONST) Dcm_GaaDspDidInfo[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaDspDataRead[]
  Type: DcmDspData, DcmDspDidRange
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData, DcmDspDidRange, DcmDidUsed
  Generation Description: The array of structures contains information
  about all the instances of DspData i.e.,
  DcmDspData configured. For every instance of DcmDspData
  instance of this array is instantiated if at least one instance
  of DcmDspDidInfo->DcmDspDidRead with DcmDidUsed true is configured.
  Sorting: Sorting is independent of any structures


  Extended for DcmDspDidRange:
  For each DcmDspDidRange with DcmDspDidInfo->DcmDspDidRead configured, this
  Dcm_GaaDspDataRead[] shall be instantiated.

**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if(DCM_DATA_READ_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0959*/
typedef struct STag_Dcm_DspDataRead
{

  /*
     The read function can be of many types depending on DcmDspDataUsePort.
     If DcmDspDataUsePort is
     a. USE_BLOCK_ID, the function shall be NvM_BlockRead, and
        pReadDidFromSource will point to Dcm_GaaDspDidNvMBlock. ucSourceType
        shall be DCM_NVM_BLOCK_ID_DATA_READ.
     b. USE_DATA_ASYNCH_CLIENT_SERVER, USE_DATA_ASYNCH_FNC: pReadDidFromSource
        will point to Dcm_GaaDspDidAsyncFuncs. ucSourceType shall be
        DCM_ASYNC_DATA_READ.
     c. USE_DATA_ASYNCH_CLIENT_SERVER_ERROR, USE_DATA_ASYNCH_FNC_ERROR:
        pReadDidFromSource will point to Dcm_GaaDspDidAsyncErrorFuncs.
        ucSourceType shall be DCM_ASYNC_ERROR_DATA_READ.
     d. USE_DATA_SYNCH_CLIENT_SERVER, USE_DATA_SYNCH_FNC:
        pReadDidFromSource will point to Dcm_GaaDspDidSyncFuncs.
        ucSourceType shall be DCM_SYNC_DATA_READ.
     e. USE_ECU_SIGNAL: pReadDidFromSource shall point to
     Dcm_GaaDspDidEcuSignal. ucSourceType shall be DCM_ECU_SIGNAL.
     f. DcmDspDidRange: If this instance of Dcm_DspDataRead comes from a
     DcmDspDidRange and shall point to Dcm_GaaDspDidRange[], ucSourceType
     shall be DCM_DID_RANGE_READ.
     f. USE_DATA_SENDER_RECEIVER, USE_DATA_SENDER_RECEIVER_AS_SERVICE:
        pReadDidFromSource will point to Dcm_GaaDspDidSendRecFuncs.
        ucSourceType shall be DCM_SR_DATA_READ.

 */

  P2CONST(void, DCM_CONST, DCM_CONST) pReadDidFromSource;


  /* This element contains the type of source.

     Refer above for details */
  Dcm_DspSrcType  ucSourceType;

}Dcm_DspDataRead;

/* Design ID : DCM_SDD_6121 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDataRead, DCM_CONST) Dcm_GaaDspDataRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif
#if(DCM_DSP_MASK_SIZE_UINIT8 == STD_ON)

/* The  function ptr of Dcm_GaaDspIoCtrlMaskSizeOne has to generated for each
DIDsignal in DcmDspDid
   EX:
   if DcmDspDid have  DcmDspDidSignal_0,DcmDspDidSignal_1 and
   DcmDspDidSignal_2 are configured
   then three function pointers has to be generated as
   Dcm_DspIoControlUint8_0,Dcm_DspIoControlUint8_1 and
   Dcm_DspIoControlUint8_2
  More details will be Dcm_DspIoControlUint8_<Instance>
  */

/*Design ID : DCM_SDD_6061*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspMask8FuncPtrType, DCM_CONST) Dcm_GaaDspIoCtrlMaskSizeOne[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_MASK_SIZE_UINIT16 == STD_ON)

/* The  function ptr of Dcm_GaaDspIoCtrlMaskSizeOne has to generated for each
DIDsignal in DcmDspDid
   EX:
   if DcmDspDid have  DcmDspDidSignal_0,DcmDspDidSignal_1 and
   DcmDspDidSignal_2 are configured
   then three function pointers has to be generated as
   Dcm_DspIoControlUint16_0,Dcm_DspIoControlUint16_1 and
   Dcm_DspIoControlUint16_2

   More details will be Dcm_DspIoControlUint16_<Instance> */

/*Design ID : DCM_SDD_6059*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspMask16FuncPtrType, DCM_CONST) Dcm_GaaDspIoCtrlMaskSizeTwo[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_MASK_SIZE_UINIT32 == STD_ON)

/* The  function ptr of Dcm_GaaDspIoCtrlMaskSizeOne has to generated for each
DIDsignal in DcmDspDid
   EX:
   if DcmDspDid have  DcmDspDidSignal_0,DcmDspDidSignal_1 and
   DcmDspDidSignal_2 are configured
   then three function pointers has to be generated as
   Dcm_DspIoControlUint32_0,Dcm_DspIoControlUint32_1 and
   Dcm_DspIoControlUint32_2

   More details will be Dcm_DspIoControlUint32_<Instance>   */

/*Design ID : DCM_SDD_6060*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspMask32FuncPtrType, DCM_CONST)Dcm_GaaDspIoCtrlMaskSizeFour[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaDspDataWrite[]
  Type: DcmDspDataWrite
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspData, DcmDspDid->DcmDspDidUsed.
  Generation Description: The array of structures contains information
  about all the instances of DspData i.e.,
  DcmDspData configured. For every instance of DcmDspData
  instance of this array is instantiated if at least one instance
  of DcmDspDidInfo->DcmDspDidWrite is configured. As usual, DcmDspDidUsed
  should be true.
  Sorting: Sorting is independent of any structures
**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON))
/*Design ID : DCM_SDD_0958*/
typedef struct STag_Dcm_DspDataWrite
{

  /*
    Default value: Not necessary because if write is configured, there will
    be a valid reference to one of the below structures.


     The read function can be of many types depending on DcmDspDataUsePort.
     If DcmDspDataUsePort is
     a. USE_BLOCK_ID, the function shall be NvM_BlockRead, and pWriteDidToDest
        will point to Dcm_GaaDspDidNvMBlock. ucSourceType shall be
        DCM_NVM_BLOCK_ID_DATA_WRITE.
     b. USE_DATA_ASYNCH_CLIENT_SERVER, USE_DATA_ASYNCH_FNC: pWriteDidToDest
        will point to Dcm_GaaDspDidAsyncFuncs. ucSourceType shall be
        DCM_ASYNC_DATA_WRITE.
     c. USE_DATA_ASYNCH_CLIENT_SERVER_ERROR, USE_DATA_ASYNCH_FNC_ERROR:
        pWriteDidToDest will point to Dcm_GaaDspDidAsyncErrorFuncs.
        ucSourceType shall be DCM_ASYNC_ERROR_DATA_WRITE.
     d. USE_DATA_SYNCH_CLIENT_SERVER, USE_DATA_SYNCH_FNC:
        pWriteDidToDest will point to Dcm_GaaDspDidSyncFuncs.
        ucSourceType shall be DCM_SYNC_DATA_WRITE.
     f. DcmDspDidRange: If this instance of Dcm_DspDataWrite comes from a
     DcmDspDidRange and shall point to Dcm_GaaDspDidRange[], ucSourceType
     shall be DCM_DID_RANGE.

      Note: USE_ECU_SIGNAL cannot be configured for read.

 */

  P2CONST(void, DCM_CONST, DCM_CONST) pWriteDidToDest;


  /* This element contains the type of source.

     Refer above for details */
  Dcm_DspDestType  ucSourceType;

}Dcm_DspDataWrite;

/* Design ID : DCM_SDD_6122 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDataWrite, DCM_CONST) Dcm_GaaDspDataWrite[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif





/**
  Name: Dcm_GaaDspDidSignal[]
  Type: Dcm_DspDid->DcmDspDidSignal,
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDid, DcmDspDid->DcmDspDidSignal.
  Dcm_DspDid->DcmDspDidUsed
  Generation Description: The array of structures contains information
  about all the instances of Signals i.e.,
  DcmDspDidSignal configured. For every instance of DcmDspDidSignal
  instance of this array is instantiated.
  Sorting: The sorting of this array depends on Dcm_DspDid and its element
  pDspDidSignal. If for example, a DcmDspDid contains signals
  DcmDspDidSignal_1, DcmDspDidSignal_2, and DcmDspDidSignal_3, pDspDidSignal
  shall point to the instance of Dcm_GaaDspDidSignal[] belonging to
  DcmDspDidSignal_1 and ucNoOfDidSignals shall be 3. The instances for
  DcmDspDidSignal_2 and DcmDspDidSignal_2 shall be generated immediately
  following DcmDspDidSignal_1.

  For DcmDspDidRef signals maybe repeated.

  For example, DcmDspDid_2 contains DcmDspDidSignal_1, DcmDspDidSignal_2,
  and DcmDspDidSignal_3. DcmDspDid_2 is also referred by DcmDspDid_1.
  In that case, DcmDspDidSignal_1, DcmDspDidSignal_2, and DcmDspDidSignal_3
  may be repeated if DcmDspDid_1 refers to other Did's as well.

  Signals are generated in the ascending order of DcmDspDidDataPos for each
  Did or DidRef.

  Updated for DcmDspDidRange:
  An entry in Dcm_DspDidSignal shall be made for each instance of
  DcmDspDidRange.

  DcmDspDidRange itself does not have any signals. The signal type is always
  assumed to be uint8_n hence Dcm_TxPackType shall be generated accordingly
  for this "signal". No endianness conversion is required either.

  Dcm_DspDataRead shall also be instantiated for DcmDspDidRange.

  Note: This structure should not be instantiated if DcmDspDidUsed
  is false for this signal.

**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
/*Design ID : DCM_SDD_0947*/
typedef struct STag_Dcm_DspDidSignal
{

  /* This pointer shall be used for packing data into the response buffers.
     The type of pack shall depend on characteristics of DcmDspData and also,
     DcmDspDidDataPos. This shall be explained further in Dcm_TxPackType.
     This shall be NULL_PTR if pDspDataRead is also NULL_PTR. Similar conditions
     apply.

     pTxPack can also be NULL_PTR when no processing at all is required. Data
     can directly be copied into the response buffer.

     Processing is not required when the data
     a. Starts at byte boundaries
     b. Fits completely in full, discrete bytes: For example,
        all uint16 bytes that fit in complete 2 bytes and start on byte
        boundaries.
     c. Doesn't require endianness conversion

     All uint8_n, uint8_dyn data does not require any processing.

     For other data types it is necessary to consider the above 3 conditions.

   */
  #if((DCM_DATA_READ_PROCESSING_NECESSARY == STD_ON) && \
    (DCM_DATA_READ_CONFIGURED == STD_ON))
  P2CONST(Dcm_TxPackType, DCM_CONST, DCM_CONST) pTxPack;
  #endif

  #if(DCM_DATA_WRITE_PROCESSING_NECESSARY == STD_ON)
  P2CONST(Dcm_RxUnpackType, DCM_CONST, DCM_CONST) pRxUnpack;
  #endif

  #if(DCM_DATA_READ_CONFIGURED == STD_ON)
  /* Pointer to Dcm_DspDataRead allocated to the
    DcmDspDidSignal->DcmDspDidDataRef or DcmDspDidControl
  configured in this signal.

    pDspDataRead shall be NULL_PTR if the corresponding
    DcmDspDid->DcmDspDidInfo->DcmDspDidRead or DcmDspDid
  ->DcmDspDidInfo->DcmDspDidControl
  is not configured.

    A NULL_PTR means that for this Did, this data cannot be read. It may be read
    from another Did.
   */
  P2CONST(Dcm_DspDataRead, DCM_CONST, DCM_CONST) pDspDataRead;
  #endif

  #if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON))
  /* Pointer to Dcm_DspDataWrite allocated to the
    DcmDspDidSignal->DcmDspDidDataRef configured in this signal.

    This pointer can be NULL_PTR if for this Did,
    DcmDspDid->DcmDspDidInfo->DcmDspDidWrite is not
    configured.

    A NULL_PTR means that for this Did, this data cannot be written.
    It may be written from another Did.

  For DcmDspDidRange, this shall always be point to the relevant
  Dcm_DspDataWrite if write is configured. More details are provided in
  Dcm_DspDataWrite.
   */
  P2CONST(Dcm_DspDataWrite, DCM_CONST, DCM_CONST) pDspDataWrite;
  #endif
  #if(DCM_DSP_IO_CONTROL == STD_ON)
   /* This element has to be generated as based on the DcmDspDataType
      the value has to generated for each type of signal:
      UINT8  -0x01
      uint16 -0x02
      uint32 -0x03
      uint8_N - the Number of bytes configured.
      uint16_N - the Number of bytes configured
      uint32_N - the Number of bytes configured */

   uint32 UcBytes;

   /* This mask has to to be generated based on the DcmDspDidControlMaskSize
  1)if DcmDspDidControlMaskSize==1
  then ucControlMask has to set the bits  from 7 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 7 th position and 6 th position has
  to be set 0x000000B0
  2)if DcmDspDidControlMaskSize==2
  hen ucControlMask has to set the bits  from 15 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 15 th position and 14 th position
  has to be set 0x0000B000
  3)if DcmDspDidControlMaskSize>=3
  hen ucControlMask has to set the bits  from 15 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 15 th position and 14 th position
  has to be set 0xB00000000
    */
   uint32 ucControlMask;
  #endif

  #if(DCM_DSP_SCALINGSERVICE == STD_ON)
  P2CONST(Dcm_DspScalingInformation, DCM_CONST, DCM_CONST) pDspDataScalingFnc;
  #endif

   /* Starting position in the response in bytes.

   For LE data, this will equate to the lowest byte the signal is occupying
   i.e., DcmDspDidDataPos/8.

   For BE data, this will equate to the highest byte the signal is occupying
   in the frame

   For example, suppose an LE signal's DcmDspDidDataPos is 6 and it occupies 8
   bits, ddPosInBytes shall be 0.

   For example, suppose a BE signal's DcmDspDidDataPos is 13 and it occupies 8
   bits, ddPosInBytes shall be the highest byte the signal occupies i.e.,
   2.

   The above rules are an exception when the type is uint32_n, uint16_n,
   sint32_n, sint16_n. Even
   when these types BE endianness configured, ddPosInBytes shall be the lowest
   bytee i.e., DcmDspDidDataPos/8.

   For uint8_n signals which always have OPAQUE endianness,
   ddPosInBytes shall be the lowest byte i.e., DcmDspDidDataPos/8.

   For DcmDspDidRange, this shall always be 0x00.
   */

  PduLengthType ddPosInBytes;

  #if(DCM_DSP_IO_CONTROL == STD_ON)
    /*  ucIOCtrlIndex has to be  allocated to the if
    DcmDspDidSignal->DcmDspDidControl configured in this signal.

    This ucIOCtrlIndex can be 0xFFFF if for this Did,
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl is not
    configured.

    1.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeOne if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize is 0x01
    2.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeTwo if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize is 0x02
    3.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeFour if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize >= 0x03

    More details are provided in Dcm_GaaDspIoCtrlMaskSizeOne,
    Dcm_GaaDspIoCtrlMaskSizeTwo,Dcm_GaaDspIoCtrlMaskSizeFour.

   */
   uint16 ucIOCtrlIndex;
  #endif
}Dcm_DspDidSignal;

/* Design ID : DCM_SDD_6135 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidSignal, DCM_CONST) Dcm_GaaDspDidSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaDspDid[]
  Type: Dcm_DspDid
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDid, DcmDspDid->DcmDspDidUsed,
  DcmDspDidIdentifier, DcmDspDidRange
  Generation Description:

  The array of structures contains information
  about all the instances of Dids i.e., DcmDspDid and DcmDspDidRange
  configured. For DcmDspDid
  with DcmDspDidUsed as true one instance of this array is instantiated.

  Sorting: The sorting of this array depends on Dcm_GaaDidMapping[]. If for
  example, for a DcmDspDid with DcmDspDidIdentifier 0x0107, the
  Dcm_GaaDidMapping[] value 0x05, then the 5th element of Dcm_GaaDspDid
  shall belong to 0x0107th Did. The same logic shall be extended
  to DcmDspDidRange.


  This array shall exist only number of DIDs is greater than 0 i.e., at least
  one instance of DcmDspDid is configured.

**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
/*Design ID : DCM_SDD_0948*/
typedef struct STag_Dcm_DspDid
{
  /* Pointer to the structure Dcm_DspDidInfo allocate for the instance of
     Dcm_DspDidInfo referred by DcmDspDidInfoRef. This is a mandatory
     container hence this pointer shall never be NULL_PTR.

    If this instance of Dcm_GaaDspDid is for DcmDspDidRange, then the reference
    shall be derived from DcmDspDidRange->DcmDspDidRangeInfoRef */
  P2CONST(Dcm_DspDidInfo, DCM_CONST, DCM_CONST) pDidInfo;

  /*
     If DcmDspDidRef is not configured, DcmDspDidSignal instances
     contained in this Did are listed
     sequentially in the structure Dcm_DspDidSignal. This shall point to the
     first of those. DcmDspDidSignal is not a mandatory container.

     If DcmDspDidRef is configured, DcmDspDidSignal configuration
     will be omitted. In this scenario, pDspDidSignal shall point to
     all the signals that referred to by the Did's referred in DcmDspDidRef.

     For example if DcmDspDidRef for DcmDspDid_0 is configured as
     DcmDspDid_1, DcmDspDid_2, and DcmDspDid_3.

     DcmDspDid_1 contains signals DcmDspDidSignal_1, DcmDspDidSignal_2.
     DcmDspDid_2 contains signals DcmDspDidSignal_3, DcmDspDidSignal_4.
     DcmDspDid_3 contains signals DcmDspDidSignal_5, DcmDspDidSignal_6.

     The signals DcmDspDidSignal_1, DcmDspDidSignal_2, DcmDspDidSignal_3
     DcmDspDidSignal_4, and DcmDspDidSignal_6 shall be sequentially filled
     in structure Dcm_DspDidSignal and the starting address provided in
     pDspDidSignal here

     Updated for DcmDspDidRange:
     DcmDspDidRange has no signals. But this design shall be reused for
     DcmDspDidRanges as well. Just one instance of pDspDidSignal shall be
     created for use when a DcmDspDidRange is configured and referred in
     pDspDidSignal. How to generate this signal shall be described
     in Dcm_DspDidSignal. */
  P2CONST(Dcm_DspDidSignal, DCM_CONST, DCM_CONST) pDspDidSignal;

  /* The number of bytes the DcmDspDidSignal's configured for read
     in this DID occupy. This is based on
     DcmDspDidSignal->DcmDspDidDataPos and the
     characteristics of the signal like endianness and size

     Updated for DcmDspDidRange:
     For DcmDspDidRange, ddTotalSignalBytes shall come directly from
     ddTotalSignalBytes.

     */
  PduLengthType ddTotalSignalBytes;


      #if(DCM_DSP_IO_CONTROL  == STD_ON)
      /* This element has to be generated as based on the DcmDspDataType
    the value has to generated for each type of signal:
    UINT8  -0x01
    uint16 -0x02
    uint32 -0x03
    uint8_N - the Number of bytes configured.
    uint16_N - the Number of bytes configured
    uint32_N - the Number of bytes configured

    The total addition of values has to reflected in ucnoofbytes.
     EX: if signal_0 has uint8,signal_1 has uint16,signal_1 has uint32

     so the value of ucnoofbytes has to generated as 0x06
        */
    uint32 ucnoofbytes;

    /* the position of the  has to generated for the DID's
     DcmDspDid->DcmDspDidInfo->DcmDspDidControl
     else the value 0xFFFF has to generated.   */
  uint16 ucIoCtrlPos;

  #endif

    #if(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)
  /* This position has to be generated  as the dynamic Did
  configured which is in the range of 0xF300 to 0xF3FF
  */
  uint16 ucDcmDynPos;
  /* this element will be generated as DCM_TRUE if the configured DID is dynamic
     Did which is in the range of 0xF300 to 0xF3FF */
  uint8 ucDynamicallyDefined;

  /* this element is generated based on DcmDspDDDIDMaxElements configured for
  dynamic Did, if DID is not in the range of 0xF300 to 0xF3FF then default value
  0xFF will be generated */
  uint8 ucDspDDDIDMaxElements;
  #endif

  #if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
  /* the position of the DID has to generated which is in the range of
     F2000-F2FF else the value 0xFFFF has to generated.   */
  uint8 ucPeriodicPos;

  /* for each DID container if the  DcmDspDid->DcmDspDidControl->DcmDspData the
  parameter DcmDspDataType is configured as uint8_DYN then this element has to
  be generated as DCM_TRUE else DCM_FALSE */
  boolean ulReadLenCheck;
  #endif

      /* The number of instances of DcmDspDidSignal from this Did.

     For DcmDspDidRef, ucNoOfDidSignals shall be the total of all signals in
     the Did's referred via DcmDspDidRef.

     Updated for DcmDspDidRange:
     For DcmDspDidRange, ucNoOfDidSignals shall always be 0x01 since
     only one instance of pDspDidSignal is sufficient.
    */
    uint8 ucNoOfDidSignals;
  /*

    Configuration dependencies:
    DcmDspDid->DcmDspDidSignal->DcmDspDidDataRef->DcmDspDataType:
    DcmDspDid->DcmDspDidRef->DcmDspDidSignal->DcmDspDidDataRef->DcmDspDataType,
    DcmDspDidRange.


    If this instance of  Dcm_DspDid is instantiated for a DID  which is a
    normal DID without any dynamic signals i.e., none of
    the referred DcmDspDidDataRef have DcmDspDataType as uint8_dyn,
    ucDIDType should be generated as DCM_DID_STATIC. If there is at least one
    signal with DcmDspDidDataRef with DcmDspDataType as uint8_dyn
    ucDIDType should be generated as DCM_DID_DYNAMIC.

    If the Did refers to other DIDs via DcmDspDidRef, and if none of the
    referred DcmDspDidRef's have DcmDspDataType as uint8_dyn,
    ucDIDType should be generated as DCM_DID_STATIC. If at least one signal
    has DcmDspDataType as uint8_dyn, ucDIDType should be
    generated as DCM_DID_DYNAMIC.

    If the DID is instantiated for DcmDspDidRange, then ucDIDType shall
    be DCM_DID_RANGE.

  */
 #if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
 (DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON))
  uint8 ucDIDType;
  #endif
}Dcm_DspDid;

/* Design ID : DCM_SDD_6123 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDid, DCM_CONST) Dcm_GaaDspDid[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if((DCM_DID_RANGE_CONFIGURED == STD_ON)&&((DCM_DID_RANGE_READ_CONFIGURED == \
STD_ON)||(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)))
/*Design ID : DCM_SDD_0960*/
typedef struct STag_Dcm_DspDidRange
{
  /* DCM_DID_RANGES_HAVE_GAPS: This shall be generated as STD_ON if in any
     instance of DcmDspDidRangeHasGaps is TRUE. If it is FALSE in all instances
     then this shall be STD_OFF */
  #if(DCM_DID_RANGES_HAVE_GAPS == STD_ON)
 /* The function Xxx_IsDidAvailable. This is an optional function. It shall
    be generated as NULL_PTR if DcmDspDidRangeHasGaps is FALSE.

    If DcmDspDidRangeHasGaps is TRUE i.e., there are gaps in the range
    specified in the DcmDspDidRange, and a valid pIsDidAvailable shall be
    generated.

    Generation shall depend on DcmDspDidRangeUsePort. If DcmDspDidRangeUsePort
    is false, the function name shall be fetched directly from
    DcmDspDidRangeIsDidAvailableFnc. If DcmDspDidRangeUsePort is TRUE, then
    port shall be assumed to be a client-server port, and the function
    shall be derived as Rte_Call_DataServices_DIDRange_{Range}_IsDidAvailable()
    where {Range} is the short name of the DcmDspDidRange container.

    */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pIsDidAvailable)
  (
    uint16 DID,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_DidSupportedType, AUTOMATIC, DCM_VAR) Supported
  );
  #endif

  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  /* This is a function parameter which points to the relevant read function
     for this instance of DspDidRange.

     If DcmDspDidRangeUsePort is TRUE, the function shall point to a port
     interface whose name shall be derived as
     Rte_Call_DataServices_DIDRange_{Range}_ReadDidData()
     where {Range} is the short name of the DcmDspDidRange container.

     If  DcmDspDidRangeUsePort is FALSE, this shall be derived directly
     from DcmDspDidRangeReadDidFnc.

     This function can be NULL_PTR if DcmDspDidRange->DcmDspDidRangeInfoRef->
     DcmDspDidRead is not configured. This means that this Did range cannot
     be read */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadDidData)
  (
    uint16 DID,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    Dcm_OpStatusType OpStatus,
    uint16 DataLength,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  /*
     This is a function parameter which points to the relevant  function
     for this instance of DspDidRange which returns the data length for the
     the requested DID.

     If DcmDspDidRangeUsePort is TRUE, the function shall point to a port
     interface whose name shall be derived as
     Rte_Call_DataServices_DIDRange_{Range}_ReadDidRangeDataLength()
     where {Range} is the short name of the DcmDspDidRange container.

     If  DcmDspDidRangeUsePort is FALSE, this shall be derived directly
     from DcmDspDidRangeReadDataLengthFnc.

     This function can be NULL_PTR if DcmDspDidRange->DcmDspDidRangeInfoRef->
     DcmDspDidRead is not configured. This means that this Did range cannot
     be read, hence the length need not be read.
 */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadDidRangeDataLength)
  (
    uint16 DID,
    Dcm_OpStatusType OpStatus,
    P2VAR(uint16, AUTOMATIC, DCM_VAR) DataLength
  );
  #endif

  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  /* This is a function parameter which points to the relevant write function
     for this instance of DspDidRange.

     If DcmDspDidRangeUsePort is TRUE, the function shall point to a port
     interface whose name shall be derived as
     Rte_Call_DataServices_DIDRange_{Range}_WriteDidData()
     where {Range} is the short name of the DcmDspDidRange container.

     If  DcmDspDidRangeUsePort is FALSE, this shall be derived directly
     from DcmDspDidRangeWriteDidFnc.

     This function can be NULL_PTR if DcmDspDidRange->DcmDspDidRangeInfoRef->
     DcmDspDidWrite is not configured. This means that this Did range cannot
     be written to */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pWriteDidData)
  (
    uint16 DID,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    Dcm_OpStatusType OpStatus,
    uint16 DataLength,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  #endif


   #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)

 /* This mask will allocate bits according to the actions
  configured for this data.

  The possible actions are:
  a. IsDidAvailable i.e., the function generated in
     DcmDspDidRangeIsDidAvailableFnc
  b. RangeReadDataLength i.e., the function generated in pReadDataLength
  c. RangeRead i.e., the function generated in pReadData

  All 3 may or may not be present in a configuration.
  A bit will be allocated to each action. Bits won't be allocated if
  the action is not at all configured. For example, if only
  IsDidAvailable is not configured i.e., DCM_DID_RANGES_HAVE_GAPS is
  STD_OFF only 2 bits are allocated. In DId Range the default two will
  be reserved i.e., in range the length is mandatory.

  Suppose there are 2 Dcm_DspDidRange instances,
  Dcm_GaaDspDidRange[0] and Dcm_GaaDspDidRange[1] and .

  As the IsDidAvailable is configured only in one Range DID.
  Hence 3 bits will be allocated per Dcm_DspDidAsyncFuncs[].

  Suppose for Dcm_GaaDspDidRange[0].IsDidAvailable is not
  NULL_PTR. Hence the right-most i.e., least significant bit shall be high.

  pReadData and RangeReadDataLength is not NULL_PTR. Hence the 3rd bit from
  the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[0].usReadPendingMask =
    00000000000000000000000000000111b
  Suppose for Dcm_GaaDspDidRange[0].IsDidAvailable is  NULL_PTR. Hence the
  right-most i.e., least significant bit shall be high

  Dcm_GaaDspDidAsyncFuncs[1].usReadPendingMask =
    00000000000000000000000000110000b */
  uint32 usReadActionsReqd;

   /* This will have only one the first bit of the mask allocated to this
     instance as high.

     Suppose the mask is 3 bits wide.

     For example, if the mask is 00000000000000000000000000000110b
     usReadMaskBit shall be 0x01.

     If the mask is 00000000000000000000000000110000b
     usReadMaskBit shall be 00000000000000000000000000001000b.
  */
  uint32 usPendingReadActionMask;

  /* usReadPendingPos is used along with usReadPendingMask to access the
     pending actions in a DID in the global variable Dcm_GaaGenPendingVector.
     Since there are 32 bits in usReadPendingMask, usReadPendingPos will be
     incremented based on the number of bits allocated in  usReadPendingMask.

     Suppose 2 bits are allocated in usReadPendingMask, each
     Dcm_GaaGenPendingVector[] can hold 32/2 = 16 statuses.

     Hence usReadPendingPos is incremented every 16 instances of
     Dcm_DspDidAsyncFuncs.

     If 1 bit is allocated, usReadPendingPos is incremented every (32/1)
     i.e., 32 instances of Dcm_DspDidAsyncFuncs.

     If 3 bits are allocated, usReadPendingPos is incremented every (32/3)
     i.e., 10 instances of Dcm_DspDidAsyncFuncs. The last two bits will
     not be used.

     */
  uint32 usReadPendingPos;
  #endif
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  /* This mask will allocate bits according to the actions
  configured for this data.

  The possible actions are:
  a. IsDidAvailable i.e., the function generated in
     DcmDspDidRangeIsDidAvailableFnc
  b. Range write i.e., the function generated in pWriteDidData



  The IsDidAvailable may or may not present in a configuration but pWriteDidData
  is mandatory function.
  A bit will be allocated to each action. Bits won't be allocated if
  the action is not at all configured. For example, if only
  IsDidAvailable is not configured i.e., DCM_DID_RANGES_HAVE_GAPS is
  STD_OFF only 1 bit is allocated.

  Suppose there are 2 Dcm_DspDidRange instances,
  Dcm_GaaDspDidRange[0] and Dcm_GaaDspDidRange[1] and .

  As the IsDidAvailable is configured only in one Range DID.
  Hence 2 bits will be allocated per Dcm_DspDidAsyncFuncs[].

  Suppose for Dcm_GaaDspDidRange[0].IsDidAvailable is not
  NULL_PTR. Hence the right-most i.e., least significant bit shall be high.

  pWriteDidData  is not NULL_PTR. Hence the 2nd bit from
  the right shall be high.

  Dcm_GaaDspDidAsyncFuncs[0].usWriteActionsReqd =
    0000000000000000000000000000011b
  Suppose for Dcm_GaaDspDidRange[0].IsDidAvailable is  NULL_PTR. Hence the
  right-most i.e., least significant bit shall be high

  Dcm_GaaDspDidAsyncFuncs[1].usWriteActionsReqd =
    000000000000000000000000001000b */
  uint32 usWriteActionsReqd;

   /* This will have only one the first bit of the mask allocated to this
     instance as high.

     Suppose the mask is 2 bits wide.

     For example, if the mask is 00000000000000000000000000000110b
     usPendingWriteActionMask shall be 0x01.

     If the mask is 00000000000000000000000000110000b
     usPendingWriteActionMask shall be 00000000000000000000000000001000b.
  */
  uint32 usPendingWriteActionMask;

  /* usWritePendingPos is used along with usWriteActionsReqd to access the
     pending actions in a DID in the global variable Dcm_GaaGenPendingVector.
     Since there are 32 bits in usWriteActionsReqd, usWritePendingPos will be
     incremented based on the number of bits allocated in  usWriteActionsReqd.

     Suppose 2 bits are allocated in usWriteActionsReqd, each
     Dcm_GaaGenPendingVector[] can hold 32/2 = 16 statuses.

     Hence usWritePendingPos is incremented every 16 instances of
     Dcm_DspDidAsyncFuncs.

     If 1 bit is allocated, usWritePendingPos is incremented every (32/1)
     i.e., 32 instances of Dcm_DspDidAsyncFuncs.


     */
  uint32 usWritePendingPos;
  #endif
   #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
     /* The following field is equal to
     DcmDspDidRange->DcmDspDidRangeMaxDataLength */
    uint16 ddDidRangeMaxDataLength;
   #endif
}Dcm_DspDidRange;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/* Design ID : DCM_SDD_6130 */
extern CONST(Dcm_DspDidRange, DCM_CONST) Dcm_GaaDspDidRange[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif



typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DataSrcFuncType)
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);

/*Design ID : DCM_SDD_6070*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DataSrcFuncType, DCM_CONST) Dcm_GaaReadAndPackData[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_DATA_READ_CONFIGURED == STD_ON)
#if((DCM_NUM_OF_ASYNC_DIDS > 0)||\
(DCM_NV_BLOCK_READ_CONFIGURED == STD_ON))
/* Design ID : DCM_SDD_6091 */
/* Design ID : DCM_SDD_6161 */
#define DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspPendingDids, DCM_VAR)
Dcm_GaaPendingDid[DCM_NUM_OF_ASYNC_AND_BLOCKID_DIDS];
#define DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif

#if(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)
/*Design ID : DCM_SDD_5071*/
typedef struct STag_Dcm_DspDDDIDDataRead
{

  /* Indicated if DID is defined  */
  uint8  ucDyncdefined;

  /* Refer above for details */


  /* count of source element processed */
  uint8 ucSrcelementCount;

  /* DDID intial Status */
  uint8 ucintialDID;

  /* holds  Index of DDDID */
  uint16 ucIndex;

}Dcm_DspDDDIDDataRead;

/* Design ID : DCM_SDD_6163 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspDDDIDDataRead, DCM_VAR) Dcm_GddDspDDDIDDataRead;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*Design ID : DCM_SDD_6079*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSetDspProcessAllDIDMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

#if(DCM_DATA_READ_CONFIGURED == STD_ON)
typedef P2FUNC(uint8, DCM_CODE, Dcm_ProcessAllDid)
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#endif

#if(DCM_DATA_READ_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_7500*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ProcessAllDid, DCM_CONST) Dcm_GaaDspProcessAllDID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#if(DCM_DATA_READ_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint8, DCM_CODE) Dcm_ProcessInValidDID
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(boolean, DCM_CODE) Dcm_ValidateRequest
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspProcessReadDataByIDInd
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_ENABLEOBDMIRROR == STD_OFF)&&(DCM_READ_DID_SERVICE == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint8, DCM_CODE) Dcm_ProcessAvailInfoType
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(uint8, DCM_CODE) Dcm_ProcessAvailDID
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DIDS_PRESENT == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadECUSignalData
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPack0xF186
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackAsyncDataErr
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackAsyncData
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackNVData
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackDidRange
(
  uint16 ReqDid,
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif

  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackSyncData
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#if(DCM_SR_DATA_READ_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackSRData
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint32, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackDummy
(
  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  #if((DCM_DID_RANGE_READ_CONFIGURED == STD_ON) || \
  (DCM_DYN_DATA_READ == STD_ON))
  P2VAR(uint16, AUTOMATIC, DCM_VAR) VariableLengthDifference,
  #endif
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif/* DCM_DSPDidCONFIG_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
