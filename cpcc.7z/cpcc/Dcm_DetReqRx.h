/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DetReqRx.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To provide declarations of certain DET check functions        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By            Description                  **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_DETREQRX_H
#define DCM_DETREQRX_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#if(DCM_DEV_ERROR_DETECT == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/* Design ID :  DCM_SDD_5000 */
/* Design ID :  DCM_SDD_5005 */
extern FUNC(BufReq_ReturnType, DCM_CODE) Dcm_SoRxDetChecks
  (PduIdType DcmRxPduId,
  P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr);

extern FUNC(BufReq_ReturnType, DCM_CODE)Dcm_CpyRxDetChecks(PduIdType RxPduId,
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
  P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr);

extern FUNC(BufReq_ReturnType, DCM_CODE)Dcm_CpyTxDetChecks(PduIdType RxPduId,
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
  P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr);

extern FUNC(boolean, DCM_CODE) Dcm_TpRxIndDETChecks
(
  PduIdType DcmRxPduId
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
