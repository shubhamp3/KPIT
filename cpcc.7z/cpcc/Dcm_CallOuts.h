/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_CallOuts.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare callouts to be used by ECU Firmware                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By          Description                    **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_CALLOUTS_H
#define DCM_CALLOUTS_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#define DCM_START_SEC_CALLOUT_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SetProgConditions
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_ProgConditionsType, AUTOMATIC, DCM_VAR) ProgConditions
);

extern FUNC(Dcm_EcuStartModeType, DCM_CODE) Dcm_GetProgConditions
(
  P2VAR(Dcm_ProgConditionsType, AUTOMATIC, DCM_VAR) ProgConditions
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestDownload
(
  Dcm_OpStatusType OpStatus, uint8 DataFormatIdentifier, uint32 MemoryAddress,
  uint32 MemorySize, uint32* BlockLength,
  Dcm_NegativeResponseCodeType* ErrorCode
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestUpload
(
  Dcm_OpStatusType OpStatus, uint8 DataFormatIdentifier, uint32 MemoryAddress,
  uint32 MemorySize, uint32* BlockLength,
  Dcm_NegativeResponseCodeType* ErrorCode
);

extern FUNC(Dcm_ReturnWriteMemoryType, DCM_CODE) Dcm_WriteMemory
(
  Dcm_OpStatusType OpStatus, uint8 MemoryIdentifier, uint32 MemoryAddress,
  uint32 MemorySize, uint8* MemoryData, Dcm_NegativeResponseCodeType* ErrorCode
);

extern FUNC(Dcm_ReturnReadMemoryType, DCM_CODE) Dcm_ReadMemory
(
  Dcm_OpStatusType OpStatus, uint8 MemoryIdentifier, uint32 MemoryAddress,
  uint32 MemorySize, uint8* MemoryData, Dcm_NegativeResponseCodeType* ErrorCode
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestTransferExit
(
 Dcm_OpStatusType OpStatus, uint8* transferRequestParameterRecord,
 uint32 transferRequestParameterRecordSize,
 uint8* transferResponseParameterRecord,
 uint32* transferResponseParameterRecordSize,
 Dcm_NegativeResponseCodeType* ErrorCode
);

#if(DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestAddFile
(Dcm_OpStatusType OpStatus,uint16 filePathAndNameLength,
const uint8* filePathAndName,
uint8 dataFormatIdentifier,uint32 fileSizeUncompressed,
uint32 fileSizeCompressed,
uint32* maxNumberOfBlockLength, Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_WriteFile
(Dcm_OpStatusType OpStatus,
  uint32 DataLength, P2CONST(uint8, AUTOMATIC,DCM_CONST) pWriteData,
  Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestDeleteFile
(Dcm_OpStatusType OpStatus,uint16 filePathAndNameLength,
const uint8* filePathAndName,
Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestReplaceFile
(Dcm_OpStatusType OpStatus,uint16 filePathAndNameLength,
const uint8* filePathAndName,
uint8 dataFormatIdentifier,uint32 fileSizeUncompressed,
uint32 fileSizeCompressed,
uint32* maxNumberOfBlockLength, Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestReadFile
(Dcm_OpStatusType OpStatus,uint16 filePathAndNameLength,
const uint8* filePathAndName,
uint8 dataFormatIdentifier,uint32* fileSizeUncompressed,
uint32* fileSizeCompressed,
uint32* maxNumberOfBlockLength, Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessRequestReadDir
(Dcm_OpStatusType OpStatus,uint16 filePathAndNameLength,
const uint8* filePathAndName,
uint32* dirInfoLength,
uint32* maxNumberOfBlockLength, Dcm_NegativeResponseCodeType* ErrorCode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ReadFileOrDir
(Dcm_OpStatusType OpStatus,uint32 DataLength,
uint8* Data,Dcm_NegativeResponseCodeType* ErrorCode);
#endif

#define DCM_STOP_SEC_CALLOUT_CODE
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
