/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_ROEConfig.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of ROE Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_ROECONFIG_H
#define DCM_ROECONFIG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "Dcm_Types.h"
#include "Dcm_DspDidConfig.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_NvmROE.h"
#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
/*******************************************************************************
**                                Macros                                      **
**                        Design ID : DCM_SDD_0908                            **
*******************************************************************************/
/* SWS_Dcm_00951: If DcmDspRoeInitialEventStatus is DCM_ROE_STOPPED, the status
of this event at every initialization will be DCM_ROE_STOPPED, no matter
what happened in the previous session. */


#define DCM_ROE_EVENT_WINDOW_INFINITE                          0x02u
#define DCM_ROE_EVENT_WINDOW_CURRENT_AND_FOLLOWING_CYCLE       0x04u
#define DCM_ROE_EVENT_WINDOW_CURRENT_CYCLE                     0x03u
#define DCM_EVENT_ON_CHANGE_OF_DID                             0x03u
#define DCM_EVENT_ON_DTC_STATUS_CHANGE                         0x01u
#define DCM_ROE_STARTED                                        0x00u
#define DCM_ROE_STOPPED                                        0x01u
#define DCM_ROE_CLEARED                                        0x02u
#define DCM_ROE_NO_TRANSMISSION_PENDING                        0x00u
#define DCM_EVENT_STARTED_IN_DEF_SES                           0x01u
#define DCM_EVENT_TO_RESTART_IN_DEF_SES                        0x02u
#define DCM_EVENT_STARTED_IN_NONDEF_SES                        0x03u
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*
SWS note, page 69.
Note : The Dcm does not directly inform the SW-C about activation of
ResponseOnEvent. The SW-C has to watch the change of the corresponding
ModeDeclarationGroup DcmResponseOnEvent_<RoeEventID> and start reporting
data identifier changes to the Dcm if the Mode is �ROE started�

*/
/* Design ID : DCM_SDD_6097 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblRoeInitialWriteStatus;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"


typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_ResponseOnEventSwitch)
(
  uint8 RoeMode
);
/**
  Name: Dcm_GaaDspEventConfig[]
  Type: Dcm_DspEventConfig
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoe->DcmDspRoeEvent
  Generation Description: The array of structures contains information
  about all the instances of ROE events i.e.,
  DcmDspRoeEvent configured. For every instance of DcmDspRoeEvent
  instance of this array is instantiated.
  Sorting: Sorting shall depend on DcmDspRoeEventId. DcmDspRoeEventId as per
  ECUC_Dcm_00976 shall start from 0 and be sequential.

**/

/*Design ID : DCM_SDD_5088*/
typedef struct STag_Dcm_DspEventConfig
{

  /* Pointer to RAM holding all details about the event. The name of the
     array is  Dcm_GaaEventSetupDetails. Number of bytes to be allocate for
     each event is:
     SavedEventStatus: 1 byte
     ROEEventStartConnectionIndex: 1 byte
     EventType: 1 byte
     eventWindowTime: 1 byte
     eventTypeRecord[]: Maximum of 2 bytes for onChangeOfDataIdentifier
     ServiceToRespondTo[] : 3bytes always
     EWTCount: 1 bytes
     Hence a total of 10 bytes per event.

     Suppose there are 3 events, each will occupy 10 bytes.
     The size of Dcm_GaaEventSetupDetails[] shall be 30 bytes.

     FOr the 1st event, pEventSetupDetails shall be Dcm_GaaEventSetupDetails[0]
     FOr the 2nd event, pEventSetupDetails shall be Dcm_GaaEventSetupDetails[10]
     FOr the 2nd event, pEventSetupDetails shall be Dcm_GaaEventSetupDetails[20]
     and so on.
     */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pEventSetupDetails;

  /*
    [SWS_Dcm_00933] ?ModeSwitchInterface
    SchM_Switch_<bsnp>_DcmResponseOnEvent_<RoeEventId>
    { isService = true; RoeMode currentMode; };?() */
  /* Function name shall be generated as:
     SchM_Switch_Dcm_DcmResponseOnEvent_<RoeEventId> */
  Dcm_ResponseOnEventSwitch pRoeSchMSwitch;

    /* If for this event, DcmDspRoeEventProperties is
     DcmDspRoeOnChangeOfDataIdentifier, this pointer shall
     contain the corresponding Did pointed by DcmDspDid i.e., it shall contain
     DcmDspDid->DcmDspDidIdentifier. If this event has the other choice
     container  i.e., DcmDspRoeOnDTCStatusChange then this shall be
     DCM_INVALID_DID */
  uint16 usROEDidIdentifier;

  /* This element shall be derived from DcmDspRoeInitialEventStatus. If
    DcmDspRoeInitialEventStatus is DCM_ROE_STOPPED, this element shall be
    DCM_ROE_STOPPED. If it is DCM_ROE_CLEARED, this element shall be
    DCM_ROE_CLEARED. */
  uint8 ucInitialEventStatus;

   /* The type of event configured. If the choice container is
      DcmDspRoeOnChangeOfDataIdentifier, then this element shall be
      DCM_EVENT_ON_CHANGE_OF_DID. If the choice container is
      DcmDspRoeOnDTCStatusChange, this element shall be
      DCM_EVENT_ON_DTC_STATUS_CHANGE. */
  uint8 ucEventType;

}Dcm_DspEventConfig;


/* Design ID : DCM_SDD_6138 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspEventConfig, DCM_CONST) Dcm_GaaDspEventConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*
  Name: Dcm_GaaEventWindowTime[]
  Type: Dcm_EventWindowTime
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoeEventWindowTime
  Generation Description: The array contains information
  about all the instances of ROE event window timers.
  The symbolic value of DcmDspRoeEventWindowTime shall be reproduced here.
  If the string is DCM_ROE_EVENT_WINDOW_CURRENT_CYCLE, then that
  shall be reproduced and so on.
  They are organized with
  DcmDspRoeEventWindowTime->DcmDspRoeStorageState as DCM_FALSE
  appearing before DcmDspRoeStorageState as DCM_TRUE.
  For every instance of DcmDspRoeEventWindowTime
  instance of this array is instantiated.

  Sorting: See above.  DcmDspRoeStorageState DCM_FALSE, followed by
  DCM_TRUE.
*/
/*Design ID : DCM_SDD_6197*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaEventWindowTime[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/* #define DCM_START_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h"
extern  VAR(uint8, DCM_SAVED_ZONE) Dcm_GaaEventSetupDetails
[DCM_ROE_NUM_OF_EVENTS * DCM_NINE];
#define DCM_STOP_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h" */

/* Design ID : DCM_SDD_6102 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR) Dcm_GucfinalResponse;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6101 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR) DCM_GucfinalResIndex;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6103 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR)
DCM_GucnumOfIdentifiedEvents[DCM_ROE_NUM_OF_EVENTS];
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6099 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblRoeWriteStatus;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"


/* Design ID : DCM_SDD_6089 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GaaFinalIndex[DCM_ROE_NUM_OF_EVENTS];
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6093 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEARED) Dcm_GaaPendingROETransmissions
[DCM_ROE_NUM_OF_EVENTS + DCM_ONE_U8];
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6109 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEARED) Dcm_GucROEReadIndex;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6110 */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEARED) Dcm_GucROEWriteIndex;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6108 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GucRoeNumOfEventsActive;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6076*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaROELength[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/* SWS_Dcm_00871: Current status holds the EventStatus of all the pre-configured
  events. These are recovered from non-volatile memory from
  Dcm_GaaSavedEventStatus */
/* SWS_Dcm_00872: All events shall be initialized to DCM_ROE_CLEARED in
   Dcm_Init() because
Implicitly satisfied because Dcm_GaaCurrentEventDetails[] is cleared at init.
Later, we load it with whatever is the higher state, Dcm_GaaSavedEventStatus[]
or DcmDspRoeInitialEventStatus

SWS_Dcm_00951: If DcmDspRoeInitialEventStatus is DCM_ROE_STOPPED, it
shall be intialized accordingly in Dcm_Init via the function
Dcm_InitializeEventStatus()

SWS_Dcm_00954: This is also satisfied by the above method suggested. The
higher state shall be loaded when updating Dcm_GaaSavedEventStatus[] either
DcmDspRoeInitialEventStatus or Dcm_GaaCurrentEventDetails[].
*/

/*Design ID : DCM_SDD_5089*/
typedef struct STag_Dcm_ROECurrentEventDetails
{
  uint8 ucEventStatus;
  /* This will have the following values:
     DCM_EVENT_STARTED_IN_NONDEF_SES
     DCM_EVENT_STARTED_IN_DEF_SES
     DCM_EVENT_TO_RESTART_IN_DEF_SES
  */
  uint8 ucRestartInDefSes;
}Dcm_ROECurrentEventDetails;

typedef P2FUNC(void, DCM_CODE, Dcm_ROESwitchType)
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

/* Design ID : DCM_SDD_6159 */
#define DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
/* This variable stores the details of all the events and their states. It
   is initialized with  DCM_ROE_CLEARED as per SWS_Dcm_00872, and then it
   shall be initialized based on a comparison between the configuration
   parameter DcmDspRoeInitialEventStatus or  Dcm_GaaSavedEventStatus[],
   whichever is greater DCM_ROE_CLEARED being lowest and DCM_ROE_STARTED
   being highest.  */
extern VAR(Dcm_ROECurrentEventDetails, DCM_VAR)
             Dcm_GaaCurrentEventDetails[DCM_ROE_NUM_OF_EVENTS];
#define DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslROESimulate(uint8 EventId);

extern FUNC(void, DCM_CODE) Dcm_AddToROEQueue(uint8 EventId);

extern FUNC(void, DCM_CODE) Dcm_ROEAssembleSetupControlResponse(
    P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);

extern FUNC(uint8, DCM_CODE) Dcm_PreConfigurationSearch(
    P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);

extern FUNC(void, DCM_CODE) Dcm_DspFinalResponse(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_TriggerServiceToRespondTo
(
  void
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_InitializeEventStatus(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
