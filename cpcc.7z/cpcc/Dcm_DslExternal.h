/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DslExternal.h                                             **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To provide Dsl routine declarations to other components       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/
/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSLEXTERNAL_H
#define DCM_DSLEXTERNAL_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_InternalTypes.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/*******************************************************************************
                   Transmission Type Macros
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*******************************************************************************
            Internally Used Enumerations
*******************************************************************************/
/* This type shall be used for defining the addressing types of Rx PDU's within
Dcm_RxPduIdTableType. It is also used to pass the same data from DSL to DSD */
typedef enum
{
  DCM_PHYSICAL_TYPE = DCM_ZERO,
  DCM_FUNCTIONAL_TYPE
}Dcm_DslAddressType;

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
/*******************************************************************************
**            Functions Used by Other DCM Components                          **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslMainFunction(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dsl_DsdTransmitMainConn
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) ResponseData,
  uint16 ResponseLength
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5032*/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) DslInternal_SetSesCtrlType
(Dcm_SesCtrlType SesCtrlType);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dsl_CloseRequest(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslResponsePendingTransmit(uint8 TxType);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DSP_DIAG_SESSION_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslP2TimerReset(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

/*Design ID : DCM_SDD_5031*/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) DslInternal_SetSecurityLevel
(Dcm_SecLevelType SecLevel);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslTriggerPosResp(uint8 ProtocolIndex,
  uint8 ConnectionIndex);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dsl_DsdperiodicTransmitMainConn(
P2VAR(uint8, AUTOMATIC, DCM_VAR) ResponseData, uint16 ResponseLength);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
