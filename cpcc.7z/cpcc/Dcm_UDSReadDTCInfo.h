/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_UDSReadDTCInfo.h                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of  published structure definitions                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/* Design ID : DCM_SDD_5138                                                   **
*******************************************************************************/
#ifndef DCM_UDSREADDTCINFO_H
#define DCM_UDSREADDTCINFO_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#if(DCM_DSP_READ_DTC == STD_ON)
#define DCM_E_DTC_MASK_ZERO 0x02u

/* This is just a dummy value */
/* Since only 3 bytes are used, this value uses all 4 */
#define DCM_INVALID_DTC (uint32) 0xFFFFFFFFu

/*Value required to compose DID (2 bytes) from PID value (1 byte)*/
#define DCM_PID_TO_DID  0xF4u

/*
 Notes on pending status storage:
 For both DTCNumbers and DTCListInfo sub-functions:
 The first uint32 bits are used to store pending statuses
 The second byte store the number of DTCs for some of the services.
 The same byte can be used to store the DTC itself in some if the other
 services.

 */

#define DCM_DTC_NUMBER_STORE_POS 0x01u
#define DCM_DTC_STORE_POS 0x01u
#define DCM_DTC_NUM_FFS 0x02u
#define DCM_DTC_FF_REC_NUM 0x03u
#define DCM_DTC_ORIGIN_POS 0x04u

#define DCM_DTC_USER_DEF_MEM_SEL 0x02u
#define DCM_DTC_NUM_EXT_RECS 0x03u
#define DCM_DTC_EXT_REC_NUM 0x04u


/* Sub-function 0x42 supports FunctionalGroupIdentifier */
#define DCM_FUNCTIONAL_GROUP_IDENTIFIER 0x33u

/* DTC Number and DTC Status that work similarly */
#define DCM_REPORT_NUMBER_OF_DTCS_BY_STATUSMASK 0x01u
#define DCM_REPORT_DTC_BY_STATUSMASK 0x02u
#define DCM_REPORT_NUMBER_OF_DTC_BY_SEVERITY_MASK_RECORD 0x07u
#define DCM_REPORT_DTC_BY_SEVERITY_MASK_RECORD 0x08u

#define DCM_REPORT_NUMBER_OF_MIRROR_DTC_BY_STATUSMASK 0x11u
#define DCM_REPORT_MIRROR_DTCS_BY_STATUSMASK 0x0Fu
#define DCM_REPORT_NUMBER_OF_EMISSIONS_DTC_BY_STATUSMASK 0x12u
#define DCM_REPORT_EMISSIONS_DTCS_BY_STATUSMASK 0x13u

#define DCM_REPORT_USER_DEFINED_MEM_DTCS 0x17u

#define DCM_REPORT_EXTDATARECORD_BY_DTCNUMBER 0x06u
#define DCM_REPORT_MIRRORMEMORY_EXTDATARECORD_BY_DTCNUMBER 0x10u

/* Subfunctions that fetch DTC data by occurrence time */
#define DCM_REPORT_FIRST_FAILED_DTC 0x0Bu

/* Subfunction that fetches Snapshot Records for a particular DTC using
 a the Snapshot Identifier returned by reportDTCSnapshotRecordByDTCNumber */
#define DCM_REPORT_DTC_SNAPSHOT_RECORD_BY_DTC_NUMBER 0x04u
#define DCM_REPORT_USER_DEF_MEM_DTC_SNAPSHOT_RECORD_BY_DTC_NUMBER 0x18u

/* Subfunction that fetches Extended records i.e., */
#define DCM_REPORT_USER_DEF_MEM_EXT_DATA_REC_BY_DTC 0x19u

/* To fetch DTCs and their respective fault detection counters */
#define DCM_REPORT_DTC_FAULT_DETECTION_COUNTER 0x14u

/* Sub-functions that fetch list of WWH-OBD DTCs from a functional group */
#define DCM_REPORT_WWH_OBD_DTC_BY_MASK_RECORD 0x42u

/* value used for mapping reportWWHOBDDTCByMaskRecord */
#define DCM_REPORT_WWH_OBD_DTC_MAPPING  0x1Au

#define DCM_DTC_NUMBER_REQD (boolean)0x00
#define DCM_DTC_LIST_REQD (boolean)0x01

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/



typedef uint8 Dcm_FetchDTCNumberRetType;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONSTP2VAR(uint32, AUTOMATIC, DCM_CONST) Dcm_GpDTCSubFnsStatus;
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_7507*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSetDTCFiltDTCMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_0967*/
/*Design ID : DCM_SDD_5012*/
/*Design ID : DCM_SDD_5013*/
typedef struct STag_Dcm_SetDTCFiltDTCInputs
{
  Dem_UdsStatusByteType DTCStatusMask;
  Dem_DTCKindType DTCKind;
  Dem_DTCFormatType DTCFormat;
  Dem_DTCOriginType DTCOrigin;
  boolean FilterWithSeverity;
  Dem_DTCSeverityType DTCSeverityMask;
  boolean FilterForFaultDetectionCounter;
  boolean blZeroMaskValid;
}Dcm_SetDTCFiltDTCInputs;

typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DTCInfoSwitchType)
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);

/* Design ID : DCM_SDD_6151 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_SetDTCFiltDTCInputs, DCM_CONST) Dcm_GaaSetDTCFiltDTCInputs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6069*/
/*Design ID : DCM_SDD_5014*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dem_DTCRequestType, DCM_CONST) Dcm_GaaOccTimeReqType[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6073*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DTCInfoSwitchType, DCM_CONST) Dcm_GaaReadDTCInfoSwitch[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6173*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaReadDTCInfoSwitchMap[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6072*/
#define DCM_START_SEC_CONST_16
#include "Dcm_MemMap.h"
extern CONST(uint16, DCM_CONST) Dcm_GaaReadDTCInfoLength[];
#define DCM_STOP_SEC_CONST_16
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackDTC
(
  uint32 DTC,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pResData
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ExtendedDataRecOfDTC(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SeverityInfoOfDTC(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Dem_ReturnSetFilterType, DCM_CODE) Dcm_SetVariousFilters(
P2CONST(Dcm_SetDTCFiltDTCInputs, AUTOMATIC, DCM_CONST) LpSetFilterInputs
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_FetchDTCList(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_FetchDTCWithFDC(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_FetchSeverityList(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCByOccurrenceTime(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Dcm_FetchDTCNumberRetType, DCM_CODE) Dcm_FetchDTCNumberInfo(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus,
boolean NumberOrList
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCNumberInfo(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCListInfo(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCSeverityListInfo(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCWithFDC(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCSnapshotRecords(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DTCSnapshotIDs(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if (DCM_RDTCREADOBDFF_DATA == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SnapshotDataByRecordNum
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif /*End of if (RDTCREADOBDFF_DATA == STD_ON)*/

#endif
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
