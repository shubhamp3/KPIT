/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Cbk.h                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Declarations of callbacks to lower modules                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By            Description                  **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_CBK_H
#define DCM_CBK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "ComStack_Types.h"
#include "Dcm_Types.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"

extern FUNC(BufReq_ReturnType, DCM_CODE) Dcm_StartOfReception
(PduIdType DcmRxPduId,
P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
PduLengthType TpSduLength,
P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr);

extern FUNC(BufReq_ReturnType, DCM_CODE) Dcm_CopyRxData
(
  PduIdType RxPduId,
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
  P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr
);

extern FUNC(void, DCM_CODE) Dcm_TpRxIndication
(
 PduIdType DcmRxPduId,
 Std_ReturnType Result
);

extern FUNC(BufReq_ReturnType, DCM_CODE) Dcm_CopyTxData
(
  PduIdType TxPduId,
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
  P2VAR(RetryInfoType, AUTOMATIC, DCM_VAR) retry,
  PduLengthType* availableDataPtr
);

extern FUNC(void, DCM_CODE) Dcm_TpTxConfirmation
(
  PduIdType TxConfId,
  Std_ReturnType result
);
extern FUNC(void, DCM_CODE) Dcm_TxConfirmation(PduIdType TxPduId);

extern FUNC(void, DCM_CODE)Dcm_ComM_FullComModeEntered(uint8 NetworkId);

extern FUNC(void, DCM_CODE)Dcm_ComM_NoComModeEntered(uint8 NetworkId);

extern FUNC(void, DCM_CODE)Dcm_ComM_SilentComModeEntered(uint8 NetworkId);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
