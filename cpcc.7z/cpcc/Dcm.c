/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm.c                                                         **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Definition of module's public functions                       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/
/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              As per CR #493                **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/** Design ID : DCM_SDD_9652                                                  */
/*******************************************************************************
**                   MISRA-C:2012 violations Section                          **
*******************************************************************************/
/**
* #page misra_violations MISRA-C:2012 violations
*
* #section Dcm_c_REF_QAC_1
* Violates MISRA 2012 Advisory Rule 20.1. This statement has no side-effect.
* #include statements in a file should only be preceded by other
* preprocessor directives or comments.
*
* #section Dcm_c_REF_QAC_2
* Violates MISRA 2012 Required Rule 2.2. This statement has no side-effect.
* All non-null statements shall either (i) have at least one side-effect
* however executed, or (ii) cause control flow to change.
*
* #section Dcm_c_REF_QAC_4
* Violates MISRA 2012 Message Number 2211. This part of code has verified
* manually and has no side-effect.
* Variable is not aligned with the previously declared identifier.
*
* #section Dcm_c_REF_QAC_6
* Violates MISRA 2012 Required Rule 8.13. This part of code has verified
* manually and has no side-effect.
* This function parameter is a pointer which is never used to modify the data
* which it addresses. In other words, it is an "input" parameter. It would
* therefore improve clarity to declare it as a pointer to a const qualified
* type.
*
* #section Dcm_c_REF_QAC_7
* Violates MISRA 2012 Advisory Rule 18.4. This statement has no side-effect.
* An addition or subtraction operation is being performed on an expression of
* pointer type.
*
* #section Dcm_c_REF_QAC_8
* Violates MISRA 2012 Advisory Rule 19.2. This statement has no side-effect.
* The union keyword should not be used.
*
* #section Dcm_c_REF_QAC_9
* Violates MISRA 2012 Required Rule 11.3. This part of code has verified
* manually and has no side-effect. During unit testing boundary checks are
* performed to ensure to there is no invalid pointer access
*
* #section Dcm_c_REF_QAC_10
* Violates MISRA 2012 Advisory Rule 11.5. This part of code has verified
* manually and has no side-effect. During unit testing boundary checks are
* performed to ensure to there is no invalid pointer access
*
* #section Dcm_c_REF_QAC_11
* Violates MISRA 2012 Advisory Rule 19.2. We have analyzed the side effects
* of usage of union and found no issues.
*******************************************************************************/
/* PRQA S 5087 EOF */
/* PRQA S 0488 EOF */
/* PRQA S 3112 EOF */
/* PRQA S 3673 EOF */
/* PRQA S 0310 EOF */
/* PRQA S 0316 EOF */
/* PRQA S 0759 EOF */
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm.h"
#include "Dcm_Cbk.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DspUDSServices.h"
#include "Dcm_DsdExternal.h"
#include "Dcm_DspDidConfig.h"

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON)||\
    (DCM_DSP_OBDVEHINFO==STD_ON)||\
    (DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON)||\
    (DCM_DSP_REQONBOARDMONITORTEST == STD_ON))
#include "Dcm_DspPidConfig.h"
#endif

#if((DCM_DSP_OBDVEHINFO == STD_ON)&&(DCM_DSP_ENABLEOBDMIRROR == STD_ON)&&\
    (DCM_READ_DID_SERVICE == STD_ON))
#include "Dcm_DspVehInfoConfig.h"
#endif

#include "Dcm_ROEConfig.h"
#include "Dcm_InternalRoutines.h"

#if(DCM_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

#include "PduR_Dcm.h"
#include "ComM_Dcm.h"
/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
VAR(boolean, DCM_VAR_INIT) Dcm_GblInitStatus = DCM_UNINITIALISED;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
VAR(boolean, DCM_VAR_INIT)Dcm_GblDiagBootJump = DCM_FALSE;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
/*Global boolean variable to check status of Request processing in
Dcm_MainFunction*/
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_Init                                            **
**                                                                            **
** Service ID           : 0x01                                                **
**                                                                            **
** Description          : Service for basic initialization of DCM module.     **
**                                                                            **
** Sync/Async           : Synchronous                                         **
**                                                                            **
** Re-entrancy          : Non Reentrant                                       **
**                                                                            **
** Input Parameters     : ConfigPtr                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dcm_GblInitStatus,            **
**                                              Dcm_GaaProtocolInfo,          **
**                                              Dcm_GstCurrentProtocolInfo,   **
**                                              Dcm_GddCurrentSession         **
**                                              Dcm_GddConcTpRxPduId          **
**                        Function(s) invoked : Dsp_AttemptCounterInit        **
**                                              Dcm_DspBLOrJumpFromBL         **
** Design ID            : DCM_SDD_3114                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_Init(
  P2CONST(Dcm_ConfigType, AUTOMATIC, DCM_CONST) ConfigPtr
)
{
  VAR(uint8_least, AUTOMATIC) LucCount;
  /* Set Dcm_GblInitStatus to indicate that Dcm is now initialised */
  Dcm_GblInitStatus = DCM_INITIALISED;
  if(NULL_PTR != ConfigPtr)

  {
    /* Report to DET */
    (void)Det_ReportError(DCM_MODULE_ID, DCM_INSTANCE_ID,
                    DCM_GET_VERSION_INFO_SID, DCM_E_INIT_FAILED);
  }
  else

  {
    {
      LucCount = DCM_ZERO_U32;

      {
        Dcm_GaaProtocolInfo[LucCount].ucProtocolTxRxStatus
                      = DCM_PROTOCOL_DISENGAGED;
        Dcm_GaaProtocolInfo[LucCount].ddBytesCopied = DCM_ZERO;
      }
      /* Initialized to indicate that any protocol is yet to be started */
      Dcm_GstCurrentProtocolInfo.ucReqProcessingStatus =
        DCM_PROTOCOL_IDLE_AND_AVAILABLE;
      Dcm_GstCurrentProtocolInfo.ucRespPendingCounter =
      DCM_ZERO_U8;
      Dcm_GucServiceProcessingType = DCM_INTERNAL_PROCESSING;
      /* What protocol should you start with? */
      Dcm_GstCurrentProtocolInfo.ucCurrentProtocolIndex = DCM_PROTOCOL_NONE;
      /* In default session */
      Dcm_GddCurrentSession = DCM_DEFAULT_SESSION;
      /* initialize to Invalid SID */
      Dsd_GstMessageInfo.ucSID = DCM_INVALID_SID;
      /*Initialize the Opstatus to DCM_PENDING *
       * Reference Requirement Id's SWS_Dcm_00530
       * SWS_Dcm_00529   */


      Dsd_GstMessageInfo.ddOpstatus = DCM_PENDING;
      Dsd_GstMessageInfo.ucProcessPendingReq = DCM_SCHEDULED_IN_PROGRESS;
      Dcm_GddConcTpRxPduId = DCM_INVALID_RECEIVE_ID;
      /* Jump from BL */
      Dcm_DspBLOrJumpFromBL();
      Dcm_GblDiagBootJump = DCM_FALSE;
      Dcm_GblReqProcessingStatus = DCM_FALSE;
      /* Assign to default value*/
      Dcm_GstCurrentProtocolInfo.ucGenrConn = DCM_FALSE;

      DCM_UNUSED(ConfigPtr);

    }
  }
}/*End of Dcm_Init*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_GetVersionInfo                                  **
**                                                                            **
** Service ID           : 0x24                                                **
**                                                                            **
** Description          : Returns the version information of this module.     **
**                                                                            **
** Sync/Async           : Synchronous                                         **
**                                                                            **
** Re-entrancy          : Reentrant                                           **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : versionInfo                                         **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dcm_GblInitStatus             **
**                        Function(s) invoked : Det_ReportError               **
** Design ID            : DCM_SDD_3115                                        **
*******************************************************************************/

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_GetVersionInfo(
  P2VAR(Std_VersionInfoType, AUTOMATIC, DCM_APPL_DATA) versioninfo
)
{

  if (DCM_UNINITIALISED == Dcm_GblInitStatus)
  {
    /* Report to DET */
    (void)Det_ReportError (DCM_MODULE_ID, DCM_INSTANCE_ID,
    DCM_GET_VERSION_INFO_SID, DCM_E_UNINIT);
  }
  else if(NULL_PTR == versioninfo)
  {
    /* Report Error to DET */
    (void)Det_ReportError(DCM_MODULE_ID, DCM_INSTANCE_ID,
      DCM_GET_VERSION_INFO_SID, DCM_E_PARAM_POINTER);
  }
  else

  {
    /* Copy the vendor Id */
    versioninfo->vendorID = DCM_VENDOR_ID;
    /* Copy the module Id */
    versioninfo->moduleID = DCM_MODULE_ID;
    /* Copy Software Major Version */
    versioninfo->sw_major_version = (uint8)DCM_SW_MAJOR_VERSION;
    /* Copy Software Minor Version */
    versioninfo->sw_minor_version = (uint8)DCM_SW_MINOR_VERSION;
    /* Copy Software Patch Version */
    versioninfo->sw_patch_version = (uint8)DCM_SW_PATCH_VERSION;
  }
}/*End of Dcm_GetVersionInfo*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_PduRReturnCheck                                 **
**                                                                            **
** Service ID           : NA                                                  **
**                                                                            **
** Description          : Checks the return value of PduR_DcmTransmit.        **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dcm_GaaProtocolInfo           **
**                                              Dcm_GstCurrentProtocolInfo    **
**                                              Dcm_GucRepeatRequest          **
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
**                                                                            **
** Design ID            : DCM_SDD_XXXX                                        **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_DslReponseMainFunctionNRC                       **
**                                                                            **
** Service ID           : NA                                                  **
**                                                                            **
** Description          : DSL Response main function.                         **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dcm_GddResponseMainFunction   **
**                                              Dcm_GaaConnection             **
**                                              Dcm_GaaComMMapping            **
**                                              Dcm_GaaComMMode               **
**                                              Dcm_GaaProtocolInfo           **
**                                              Dcm_GstCurrentProtocolInfo    **
**                                              Dcm_GucRepeatRequest          **
**                                              Dcm_GucS3ServerTimeStatus     **
**
**                        Function(s) invoked : ComM_DCM_InactiveDiagnostic   **
**                                              PduR_DcmTransmit              **
**                                              Dsd_CloseRequest              **
** Design ID            : DCM_SDD_3116                                        **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_MainFunction                                    **
**                                                                            **
** Service ID           : 0x25                                                **
**                                                                            **
** Description          : This service is used for processing the tasks of    **
**                        the main loop.                                      **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked :  Dcm_DslScheduled             **
**                                               Dcm_DsdScheduled             **
**                                                Dcm_DspScheduled            **
** Design ID            : DCM_SDD_3117                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_MainFunction(void)
{
  /* Check whether the module is Initialized */
  if (DCM_UNINITIALISED != Dcm_GblInitStatus)
  {
    Dcm_DspScheduled();
    {
      Dcm_DsdScheduled();
    }
    Dcm_DslScheduled();
    /* Nothing yet */
    /* This doesn't exist. The right function is called from Dcm_DsdScheduled */
  }

  else
  {
    /* Report to DET */
    (void)Det_ReportError (DCM_MODULE_ID, DCM_INSTANCE_ID,
    DCM_MAIN_FUNCTION_SID, DCM_E_UNINIT);
  }

}/*End of Dcm_MainFunction*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_UnpackDTC                                       **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Unpack The DTC                                      **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pReqData                                            **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : DTC                                                 **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3119                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_UnpackDTC(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pReqData,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) DTC
)
{
  VAR(uint32, AUTOMATIC) LulDTC;
  VAR(uint8, AUTOMATIC) LucDTCBytes;
  /* Get the lower end of the byte */
  LucDTCBytes = *pReqData;
  LulDTC = ((uint32) LucDTCBytes) << DCM_0x10_U32;
  /* Get the next byte */
  LucDTCBytes = *(pReqData + DCM_ONE);
  LulDTC |= ((uint32) LucDTCBytes) << DCM_EIGHT_U32;
  /* Get the next byte */
  LucDTCBytes = *(pReqData + DCM_TWO);
  LulDTC |= ((uint32) LucDTCBytes);
  *DTC = LulDTC;
}/*End of Dcm_UnpackDTC*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_BinarySearch                                    **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Binary Search                                       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : ID(DID Value or RID Value, LucSize , Data           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : Index Of the  ID                                    **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3120                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(VAR(uint16, DCM_VAR),DCM_CODE)Dcm_BinarySearch(
uint16 ID,
uint16 LusSize,
P2CONST(uint16, AUTOMATIC, DCM_CONST)Data)
{
  VAR(uint16, AUTOMATIC) LusRetval;
  VAR(uint16_least, AUTOMATIC) LusLow;
  VAR(uint16, AUTOMATIC) LusMid;
  LusRetval = DCM_INVALID_DID;
  /* Initialize LusLow variable with one */
  LusLow = (uint16_least)DCM_ZERO;
  if (*(Data+DCM_ZERO) != ID)
  {
    do
    {
      /* Get the middle index number */
      LusMid = (uint16)(((uint16_least)LusSize + LusLow) >> DCM_ONE);
      if( *(Data+LusMid) == ID )
      {
        LusRetval = LusMid;
        /* Set LusSize to zero to break the loop */
        LusSize = DCM_ZERO;
      }
      else
      {
        /* Compare Data  Value with the requested one */
        if (*(Data+LusMid) < ID)
        {
          LusLow = ((uint16_least)LusMid + (uint16_least)DCM_ONE_U16);
        }
        else
        {
          /* If the priority is higher, update LusLow */
          LusSize = (LusMid - DCM_ONE_U16);
        }
      }
    }while (LusLow <= (uint16_least)LusSize);
  }
  else
  {
    /*Update the LucRetvalue to Zero*/
    LusRetval = (uint16)DCM_ZERO;
  }
  return (LusRetval);
}/* End of Dcm_BinarySearch */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_ResetToDefaultSession                           **
**                                                                            **
** Service ID           : 0x2A                                                **
**                                                                            **
** Description          : The call to this function allows the application    **
**                          to reset the current session to Default session   **
**                                                                            **
** Sync/Async           : Synchronous                                         **
**                                                                            **
** Re-entrancy          : Reentrant                                           **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : Std_ReturnType                                      **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : DslInternal_SetSesCtrlType    **
** Design ID            : DCM_SDD_3122                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(Std_ReturnType,DCM_CODE)Dcm_ResetToDefaultSession(void)
{
  /* Set to default Session as per SWS_Dcm_00520 */
  DslInternal_SetSesCtrlType(DCM_DEFAULT_SESSION);
  return(E_OK);
}/*End of Dcm_ResetToDefaultSession*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DspConvUint8                                    **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API Converts unit16 and unit32 into uint8           **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : Src , Type                                          **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : Dest                                                **
**                                                                            **
** Return parameter     : void                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3124                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_DspConvUint8(
P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8 ByteNo, uint8 *Dest)
{
  VAR(uint8_least, AUTOMATIC) LucCount;
  LucCount = (uint8_least)ByteNo;
  #if (CPU_BYTE_ORDER == LOW_BYTE_FIRST)
  Src = Src + (ByteNo - 0x01u);
  #endif
  do
  {
    *Dest = *Src;
    #if (CPU_BYTE_ORDER == LOW_BYTE_FIRST)
    Src--;
    #else
    Src++;
    #endif
    Dest++;
    LucCount--;
  }while(DCM_ZERO_U32 != LucCount);
}/*End of Dcm_DspConvUint8*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DspConvUint8WithoutEnd                          **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API Converts unit16 and unit32 into uint8           **
**                         without considering Endiness                       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : Src , Type                                          **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : Dest                                                **
**                                                                            **
** Return parameter     : void                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3125                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_DspConvUint8WithoutEnd(
P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8 ByteNo, uint8 *Dest)
{
  VAR(uint8_least, AUTOMATIC) LucCount;
  LucCount = (uint8_least)ByteNo;
  do
  {
    *Dest = *Src;
    Src++;
    Dest++;
    LucCount--;
  }while(DCM_ZERO_U32 != LucCount);
}/*End of Dcm_DspConvUint8WithoutEnd*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_MemCpyByteByByte                                **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Copy the byte by byte data if source and            **
**                        destination buffer is same                          **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : Src , Length                                        **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : Dest                                                **
**                                                                            **
** Return parameter     : void                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3127                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_MemCpyByteByByte(
  P2CONST(uint8, AUTOMATIC, DCM_CONST) Src,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Dest,
  Dcm_MsgLenType Length
)
{
  while(Length != DCM_ZERO_U32)
  {
    /* Copy data */
    *Dest = *Src;
    /* Increment Destination Pointer */
    Dest++;
    /* Increment Source Pointer */
    Src++;
    /* Decrement the length */
    Length--;
  }
}/*End of Dcm_MemCpyByteByByte*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_InternalMemCpy                                  **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Modifying Dcm_InternalMemCpy to be able to handle   **
**                        overlapping areas of memory. To be able to achieve  **
**                        this, we copy from the highest address instead of   **
**                        the lowest.                                         **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : Src,Length                                          **
**                                                                            **
** Output Parameters    : Dest                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3128                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_InternalMemCpy(
  P2CONST(uint8, AUTOMATIC, DCM_CONST) Src,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Dest,
  Dcm_MsgLenType Length
)
{
  Src = (Src + Length)- DCM_ONE;
  Dest = (Dest + Length) - DCM_ONE;
  while(Length != DCM_ZERO_U32)
  {
    /* Copy data */
    *Dest = *Src;
    /* Increment Destination Pointer */
    Dest--;
    /* Increment Source Pointer */
    Src--;
    /* Decrement the length */
    Length--;
  }
}/*End of Dcm_InternalMemCpy*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_ByteTo32BitWordConversion                       **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Byte to Double Word conversion                      **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pUsDataU8                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : pUsDataU32                                          **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3129                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_ByteTo32BitWordConversion(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) pUsDataU32
)
{
  VAR(Dcm_MIdWord_Access, AUTOMATIC) LunData;
  #if (CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
  LunData.byte_val.MS_Byte = *pUsDataU8;
  LunData.byte_val.MS_Mid_Byte = *(pUsDataU8 + 0x01u);
  LunData.byte_val.LS_Mid_Byte = *(pUsDataU8 + 0x02u);
  LunData.byte_val.LS_Byte = *(pUsDataU8 + 0x03u);
  *pUsDataU32 = (LunData.whole_dword);
  #else
  LunData.byte_val.LS_Byte = *pUsDataU8;
  LunData.byte_val.LS_Mid_Byte = *(pUsDataU8 + 0x01u);
  LunData.byte_val.MS_Mid_Byte = *(pUsDataU8 + 0x02u);
  LunData.byte_val.MS_Byte = *(pUsDataU8 + 0x03u);
  *pUsDataU32 = (LunData.whole_dword);
  #endif
}/*End of Dcm_ByteTo32BitWordConversion*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_ByteTo16Conversion                              **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Byte to Double Word conversion with Endianess       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pUsDataU8                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : pUsDataU16                                          **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3131                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_ByteTo16Conversion(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
)
{
  VAR(Dcm_MIWord_Access, AUTOMATIC) LunData;
  #if (CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
  LunData.byte_val.MS_Byte = *pUsDataU8;
  LunData.byte_val.LS_Byte = *(pUsDataU8 + 0x01u);
  *pUsDataU16 = (LunData.whole_word);
  #else
  LunData.byte_val.LS_Byte = *pUsDataU8;
  LunData.byte_val.MS_Byte = *(pUsDataU8 + 0x01u);
  *pUsDataU16 = (LunData.whole_word);
  #endif
}/*End of Dcm_ByteTo16Conversion*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_TesterPresentByteConversion                     **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : To convert the TesterPresent Byte Order conversion  **
**                        based on the Endianness.                            **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pUsDataU8                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : pUsDataU16                                          **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3114                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_TesterPresentByteConversion(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
)
{
  VAR(Dcm_MIWord_Access, AUTOMATIC) LunData;
  LunData.byte_val.MS_Byte = *pUsDataU8;
  LunData.byte_val.LS_Byte = *(pUsDataU8 + DCM_ONE);
  *pUsDataU16 = (LunData.whole_word);
}/*End of Dcm_TesterPresentByteConversion*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_ByteTo32BitWordConversionUnpack                 **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Byte to 32bit word conversion with for Unpack       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pUsDataU8                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : pUsDataU32                                          **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3132                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_ByteTo32BitWordConversionUnpack(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) pUsDataU32
)
{
  VAR(Dcm_MIdWord_Access, AUTOMATIC) LunData;
  #if (CPU_BYTE_ORDER == LOW_BYTE_FIRST)
  LunData.byte_val.MS_Byte = *pUsDataU8;
  LunData.byte_val.MS_Mid_Byte = *(pUsDataU8 + 0x01u);
  LunData.byte_val.LS_Mid_Byte = *(pUsDataU8 + 0x02u);
  LunData.byte_val.LS_Byte = *(pUsDataU8 + 0x03u);
  *pUsDataU32 = (LunData.whole_dword);
  #else
  LunData.byte_val.LS_Byte = *pUsDataU8;
  LunData.byte_val.LS_Mid_Byte = *(pUsDataU8 + 0x01u);
  LunData.byte_val.MS_Mid_Byte = *(pUsDataU8 + 0x02u);
  LunData.byte_val.MS_Byte = *(pUsDataU8 + 0x03u);
  *pUsDataU32 = (LunData.whole_dword);
  #endif
}/*End of Dcm_ByteTo32BitWordConversionUnpack*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_ByteTo16ConversionUnpack                        **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Byte to 16bit word conversion or Unpack             **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pUsDataU8                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : pUsDataU16                                          **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : None                          **
**                        Function(s) invoked : None                          **
** Design ID            : DCM_SDD_3133                                        **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE)Dcm_ByteTo16ConversionUnpack(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
)
{
  VAR(Dcm_MIWord_Access, AUTOMATIC) LunData;
  #if (CPU_BYTE_ORDER == LOW_BYTE_FIRST)
  LunData.byte_val.MS_Byte = *pUsDataU8;
  LunData.byte_val.LS_Byte = *(pUsDataU8 + 0x01u);
  *pUsDataU16 = (LunData.whole_word);
  #else
  LunData.byte_val.LS_Byte = *pUsDataU8;
  LunData.byte_val.MS_Byte = *(pUsDataU8 + 0x01u);
  *pUsDataU16 = (LunData.whole_word);
  #endif
}/*End of Dcm_ByteTo16ConversionUnpack*/
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
