/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspVehInfoConfig.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**              Request VehicleInformation Data(0x09)                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By            Description                  **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPVEHINFOCONFIG_H
#define DCM_DSPVEHINFOCONFIG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DspPidConfig.h"

/**
If OBD Service 0x09 configured across any serviceTable under DSD and If atleat
one DcmDspVehInfo configured then this macro shall be swithced to STD_ON
otherwise this macro switched to STD_OFF.
Default Value for this macro is STD_OFF
**/
 #if(DCM_DSP_OBDVEHINFO == STD_ON)

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*Dcm_GaaVehInfoId consist of all vehicleInfoType Id's which are present in
Configuration file.*/
/*Design ID : DCM_SDD_6049*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST)Dcm_GaaVehInfoId[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6390*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyVehInfo[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/**
  Name: Dcm_GaaDspVehInfoData[]
  Type: Dcm_DspVehInfo->Dcm_GaaDspVehInfoData,
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspVehInfo, DcmDspVehInfo->DcmDspVehInfoData.
  Generation Description: The array of structures contains information
  about all the instances of DcmDspVehInfoData i.e.,
  DcmDspVehInfoData configured. For every instance of DcmDspVehInfoData
  instance of this array is instantiated.
  Sorting: The sorting of this array depends on DcmDspVehInfo and its elements
  DcmDspVehInfoData and DcmDspVehInfoDataOrder.
  If for example, a DcmDspVehInfo contains DataElements
  DcmDspVehInfoData_1,DcmDspVehInfoData_2, DcmDspVehInfoData_3  pDspVehInfoData
  shall point to the instance of Dcm_GaaDspVehInfoData[] belonging to
  DcmDspVehInfoData_1 and ucNoOfVehInfoDatas shall be 3. The instances for
  DcmDspVehInfoData_2 and DcmDspVehInfoData_3 shall be generated immediately
  following DcmDspVehInfoData_1.
**/
/*Design ID : DCM_SDD_5058*/
typedef struct STag_Dcm_DspVehInfoData
{
/**
Starting position in the response in bytes.

ToolGenerated: Yes
Dependencies: DcmDspVehInfoDataSize,DcmDspVehInfoDataOrder
Generation:
for every instance of DcmDspVehInfo ddVehInfoPosInBytes starts from zero
for the first DataItem and respective DataItems it will be
DcmDspVehInfoDataOrder+DcmDspVehInfoDataSize
Exmaple:
DcmDspVehInfo contains three DataElements like
DcmDspVehInfoData DcmDspVehInfoDataOrder DcmDspVehInfoDataSize
                                                            ddVehInfoPosInBytes

DcmDspVehInfoData_1          0                     1Byte            0

DcmDspVehInfoData_2          1                     2Bytes           1(0+1Byte)

DcmDspVehInfoData_3          2                     3Bytes           3(1+2Bytes)
**/
  uint32 ddVehInfoPosInBytes;

  /**
Pointer to a Function where Dcm shall calcualte the number of DataItems
configured for DcmDspVehInfo
container. **/
  #if(DCM_DSP_VEHINFO_NODIPRORESP_OFF == STD_ON)
  P2FUNC(Std_ReturnType, DCM_CODE, pVehNoDiProvResOffuncs)(
  VAR(Dcm_OpStatusType, DCM_VAR) Opstatus,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pVehReadData);
  #endif

 /**
 Pointer to a Function where Data provider (Dem or Application)
 shall calcualte the number of DataItems
 configured for DcmDspVehInfo container. **/
  #if(DCM_DSP_VEHINFO_NODIPRORESP_ON == STD_ON)
  P2FUNC(Std_ReturnType, DCM_CODE, pVehNoDiProvResOnfuncs)(
  VAR(Dcm_OpStatusType, DCM_VAR) Opstatus,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pVehReadData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pVehBufferSize);
  #endif


}Dcm_DspVehInfoData;

/*Design ID : DCM_SDD_6056*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspVehInfoData, DCM_CONST) Dcm_GaaDspVehInfoData[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5059*/
typedef struct STag_Dcm_DspVehInfo
{
/* pVehInfoData points to one of the instance of Dcm_GaaDspVehInfoData[]
    Mapping done by comparing shortname of the signal names*/
P2CONST(Dcm_DspVehInfoData,
                DCM_CONST, DCM_CONST) pVehInfoData;

/* The number of instances of DcmDspVehInfoData for a single DcmDspVehInfo
Instance*/
VAR(VehInfoSignalType, DCM_VAR) ddNoOfVehInfoDatas;

/*ddTotalSignalBytes shall define all vehinfosignal how many bytes occupied*/
uint32  ddTotalSignalBytes;

/*If Dcm calculating Number of DataItems configured for DcmDspVehInfo then value
 become DCM_FALSE if Provider responsible for Data Calculation then
 switched to DCM_TRUE*/
VAR(boolean, DCM_VAR) blNoDIProviderResponse;

}Dcm_DspVehInfo;

/*Design ID : DCM_SDD_6055*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspVehInfo, DCM_CONST) Dcm_GaaDspVehInfo[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"


#if((DCM_DSP_OBDVEHINFO == STD_ON)&&(DCM_DSP_ENABLEOBDMIRROR == STD_ON)&&\
    (DCM_READ_DID_SERVICE == STD_ON))

/* to hold count of number of infotypes that are pending when requested
 via UDS interface */
 /*Design ID : DCM_SDD_6051*/
 /*Design ID : DCM_SDD_6104*/
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR)  Dcm_GucNumPendingInfoTypes;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
/*Design ID : DCM_SDD_5057*/
/*Design ID : DCM_SDD_5085*/
typedef struct STag_Dcm_DspPendingInfoTypes
{
  uint8 ddInfoType;
  uint32 ddInfoTypePosInResp;
}Dcm_DspPendingInfoTypes;


/*Design ID : DCM_SDD_6542*/
/*Design ID : DCM_SDD_6092*/
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspPendingInfoTypes, DCM_VAR_NO_INIT)
  Dcm_GaaPendingInfoTypes[DCM_DSP_OBD_TOTALNUMBEROF_VINS];
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspScheduledProcessOBDInfoType
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint8, DCM_CODE) Dcm_ProcessOBDInfoType
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyVehInfo(
    P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspProcessNonAvialiabilityVIN(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif/* DCM_DSPVEHINFOCONFIG_H */

#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
