/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_NvmDDDID.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare RAM and ROM structures to be used by NVM           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_NVMDDDID_H
#define DCM_NVMDDDID_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Std_Types.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#if(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)
/*
Details of Dcm_GaaDDDIDDefDetails contents
Dcm_GaaDDDIDDefDetails[DCM_DDDID_ARRAY_SIZE]:

for one src element def is explained below
position 0,1: DDDID,

position 2: number of source elements count,

position 3: combination of source elements
   ie, 0x01= only DID
       0x02= only Memory,
       0x03= both memory and DID

position 4: holding AddressAndLengthFormatIdentifier
   ie, if 0x01= followed element is DID
       other than 0x01= followed element is memory
position 5: memory address contain memid or not
   ie, 0x01: followed memory contains memid and 7th byte is invalid
       0x10: followed memory does not contains memid and 7th byte is valid
       0x00: there is no memid  and 7th byte is invalid
position 6: memid if address is > 4byte
position 7,8,9,10: memory/DID
position 11: positionInSourceDataRecord used only for DID
position 12,13,14,15: memorySize used for both memory and DID
*/
/* Design ID : DCM_SDD_7505 */
#define DCM_START_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_SAVED_ZONE)
Dcm_GaaDDDIDDefDetails[DCM_DDDID_ARRAY_SIZE];
#define DCM_STOP_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaROMDDDIDDefDetails[DCM_DDDID_ARRAY_SIZE];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
