/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_UDSDDDID.h                                                **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare services DynamicallyDefineDataIdentifier (0x2C)    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By             Description                 **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_UDSDDDID_H
#define DCM_UDSDDDID_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_NvmDDDID.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaUDSDDDIDsubfnclength[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"


/* used to store the memid present or not while validating memory */
/* generated DCM_DID_MAX_ELEMENTS  used to  loop through all
DcmDspDDDIDMaxElements configured */
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR) DCM_GucMemidstatus[DCM_DID_MAX_ELEMENTS];
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"


typedef P2FUNC(void, DCM_CODE, Dcm_DDDIDSubfunc)
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DDDIDSubfunc, DCM_CONST) Dcm_GaaSubfuncSwitch[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ProcessDefineById
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ProcessDefineByMemAddr
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ProcessclearDynamicallyDifineDID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(boolean, DCM_CODE) Dcm_ValidateDDDID
(
  uint16 ReqDDDID,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspReadDataByIDDynInd
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  uint16 LusDID
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if (DCM_DSP_CHECK_SOURCE_PER_ID == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SrcDIDValidation
(
 P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
  uint16 LusSourceDID
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessScrDID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  uint16 LusIndex,
  uint16 DDDIDIndex,
  uint8 LucSrcelementprocessed,
  uint16 LusSourceDID,
  uint8 LucCount,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_MemoryValidation
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  uint16 LusIndex,
  uint8 LucSrcelementprocessed,
  uint8 LucValidationOrprocess
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
