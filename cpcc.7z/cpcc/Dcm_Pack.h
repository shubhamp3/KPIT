/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Pack.h                                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager                      **
**                                                                            **
**  PURPOSE   : Function and structure definitions for packing frames         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC fix           **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_PACK_H
#define DCM_PACK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspDidConfig.h"
#include "ComStack_Types.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif
#include "Dcm_DspInternalTypes.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#define DCM_SIG_SIZE_MASK_VALUE (uint8)0xF0
#define DCM_SIG_BYTE_MASK_VALUE (uint8)0x0F

#define DCM_SIZE_8 (uint8)0x10
#define DCM_SIZE_16 (uint8)0x20
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
typedef P2FUNC(void, DCM_CODE, Dcm_PackFunction)
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_PackFunction, DCM_CONST) Dcm_GaaPackFunction[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackOneByte
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackBytes
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackFiveBytes
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackByteOrdering
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackFiveByteOrdering
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_PackNBytesOrdering
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_Pack2NBytesOrdering
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_Pack4NBytesOrdering
(
  P2CONST(Dcm_TxPackType, AUTOMATIC, DCM_CONST) pTxPack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pDidData,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
