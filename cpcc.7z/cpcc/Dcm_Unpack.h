/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Unpack.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Function and structure definitions for unpacking frames       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_UNPACK_H
#define DCM_UNPACK_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspDidConfig.h"
#include "Dcm_Pack.h"
#include "ComStack_Types.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#define DCM_TYPE_8                          (uint8)0x00
#define DCM_TYPE_16                         (uint8)0x01
#define DCM_TYPE_24                         (uint8)0x02
#define DCM_SIGN_EXTENSION                  (uint8)0xff
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
typedef P2FUNC(void, DCM_CODE, Dcm_UnpackFuncType)
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

#if ((DCM_RIDS_PRESENT == STD_ON)||\
    (DCM_DATA_WRITE_PROCESSING_NECESSARY == STD_ON))
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_UnpackFuncType, DCM_CONST) Dcm_GaaUnpackFunction[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_UnpackOneByte
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_UnpackBytes
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_UnpackFiveBytes
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
 );

extern FUNC(void, DCM_CODE) Dcm_UnpackByteOrdering
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_UnpackFiveByteOrdering
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_UnpackNBytes
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_Unpack2NBytes
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

extern FUNC(void, DCM_CODE) Dcm_Unpack4NBytes
(
  P2CONST(Dcm_RxUnpackType, AUTOMATIC, DCM_CONST) LpRxUnpack,
  /* Destination buffer i.e., LpSigDataPtr */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpDidData,
  /* Source buffer  i.e., (LpRxUnpack->pRdBuffer) */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) LpCurrentDidFrame
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif


/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
