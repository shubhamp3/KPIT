/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspMIDConfig.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**              Request Current PowerTrainData(0x01)                          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPMIDCONFIG_H
#define DCM_DSPMIDCONFIG_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#if(DCM_DSP_REQONBOARDMONITORTEST == STD_ON)
/*Design ID : DCM_SDD_6191*/
/*Design ID : DCM_SDD_0919*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ReqIdValidate, DCM_CONST) Dcm_GaaDspProcessMID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#if(DCM_DSP_REQONBOARDMONITORTEST == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyMID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspProcessNonAvialiabilityMID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if((DCM_DSP_REQONBOARDMONITORTEST == STD_ON)&& \
    (DCM_READ_DID_SERVICE == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint8, DCM_CODE) Dcm_ProcessOBDMID
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#endif
#endif/* DCM_DSPMIDCONFIG_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
