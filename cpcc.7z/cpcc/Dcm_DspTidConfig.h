/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspTidConfig.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**        Request Control of On-Board System, Test or Component(0x08)         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPTIDCONFIG_H
#define DCM_DSPTIDCONFIG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DspPidConfig.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

#if(DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON)
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*Design ID : DCM_SDD_6048*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST)Dcm_GaaTID[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6053*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyTID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6052*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucTIDValidation;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5056*/
typedef struct STag_Dcm_OBDRequestControlConfigType
{

  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReqControlFnc)
  (P2VAR(uint8, AUTOMATIC, DCM_APPL_DATA) OutBuffer,
  P2VAR(uint8, AUTOMATIC, DCM_APPL_DATA) InBuffer);

  /* request control  in buffer Size */
  uint8 ucRequestControlInBufferSize;

   /* request control out buffer Size */
  uint8 ucRequestControlOutBufferSize;

  /* buffer for control option */
  uint8 ucRequestControlTestId;

  #if ((STD_ON == DCM_DSP_ENABLEOBDMIRROR)&&(DCM_RIDS_PRESENT == STD_ON))
  /*To get DcmDspRequestControlInfoByte byte value for OBD interface*/
  uint8 ucRequestControlInfoByte;
  #endif

}Dcm_OBDRequestControlConfigType;

/*Design ID : DCM_SDD_6057*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/* Array of structures for RequestControl Service for TIDS */
extern CONST(Dcm_OBDRequestControlConfigType, DCM_CONST)
    Dcm_GaaOBDRequestControlConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"


/*Design ID : DCM_SDD_6045*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ReqIdValidate, DCM_CONST) Dcm_GaaDspProcessTID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyTID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspProcessNonAvialiabilityTID
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_TIDSetNegResponse(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif/* DCM_DSPDidCONFIG_H */
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
