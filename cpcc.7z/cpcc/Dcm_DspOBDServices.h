/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspOBDServices.h                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsl Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPOBDSERVICE_H
#define DCM_DSPOBDSERVICE_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#if(DCM_OBD_CLEAR_EMISSION_RELATED_DTC == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDClearEmissionDTCInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspOBDDemClearDTC
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);

extern FUNC(void, DCM_CODE)Dcm_DspOBDClearEmissionDTCScheduled
(Dcm_MsgContextType* pMsgContext,
 Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspOBDClearEmissionDTCRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDClearEmissionDTCConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_OBD_READ_EMISSION_RELATED_DTC == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDReadEmissionDTCInfoInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDReadEmissionDTCInfoScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDReadEmissionDTCInfoConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDReadEmissionDTCInfoRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReadDataByPIDInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDataByPIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDataByPIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDataByPIDScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

 #if(DCM_DSP_OBDVEHINFO == STD_ON)
/*exten declaration for Obd service 0x09 (Request Vehicle Information)*/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_OBDReadVehInfoDataScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

extern FUNC(void, DCM_CODE) Dcm_OBDReadVehInfoDataRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_OBDReadVehInfoDataConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_OBDReadVehInfoDataInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#if(DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspOBDRequestCtrlCompInfoScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDRequestCtrlCompInfoRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDRequestCtrlCompInfoConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDRequestCtrlCompInfoInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDPowerTrainFFDataInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspOBDPowerTrainFFDataConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
extern FUNC(void, DCM_CODE) Dcm_DspOBDPowerTrainFFDataRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);
extern FUNC(void, DCM_CODE) Dcm_DspOBDPowerTrainFFDataScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_REQONBOARDMONITORTEST == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReqOnBoardMonitorTestInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspReqOnBoardMonitorTestRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspReqOnBoardMonitorTestConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspReqOnBoardMonitorTestScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
