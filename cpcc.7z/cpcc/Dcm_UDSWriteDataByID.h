/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_UDSWriteDataByID.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of  published structure definitions                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By            Description                  **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Removed unused macros         **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/* Design ID : DCM_SDD_5139                                                   **
*******************************************************************************/
#ifndef DCM_UDSWRITEDATABYID_H
#define DCM_UDSWRITEDATABYID_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DslInternalTypes.h"
#include "Dcm_DspDidConfig.h"
#include "Dcm_InternalTypes.h"
#include "Dcm_InternalRoutines.h"
#include "Dcm_DsdExternal.h"
#include "Dcm_DspUDSServices.h"
#include "Dcm_Unpack.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#if((DCM_DATA_WRITE_CONFIGURED == STD_ON)||\
(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON))
#if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)

/* Design ID : DCM_SDD_0014 */
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteDidRange
(
  uint16 ReqDid,
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif



#if(DCM_ASYNC_DATA_WRITE_WITH_ERROR_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteAsyncDataErr
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif



#if(DCM_ASYNC_DATA_WRITE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteAsyncData
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteDummyData
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#if(DCM_SR_DATA_WRITE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteSRData
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_SYNC_DATA_WRITE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteSyncData
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_NV_BLOCK_WRITE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_WriteNVData
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_DataDestFuncType)
(
  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  uint16 ReqDid,
  #endif
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

#endif

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
