/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspRequestFileTransfer.h                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**        Request File transfer                                               **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPFILETRANSFER_H
#define DCM_DSPFILETRANSFER_H

#if(DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#define DCM_ADD_FILE                         0x01u
#define DCM_DELETE_FILE                      0x02u
#define DCM_REPLACE_FILE                     0x03u
#define DCM_READ_FILE                        0x04u
#define DCM_READ_DIR                         0x05u

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/* Structure to hold callout input values to provide to callouts */
/*Design ID : DCM_SDD_5084*/
typedef struct STag_Dcm_FileTransfer
{

  /* Total validated request length */
  uint32 GulReqLength;

  /* Holds the size of the uncompressed file*/
  uint32 GulFileSizeUncompressed;

  /* Holds the size of the compressed file*/
  uint32 GulFileSizecompressed;

  /* Holds the Block length value provided by callout */
  uint32 GulMaxNumberOfBlockLength;

  /* pointer the hold FilePathAndName address */
  P2VAR(uint8, AUTOMATIC, DCM_VAR) GpDcmFilePathAndName;

  /* Holds the FilePathAndNameLength length value provided in request */
  uint16 GusFilePathAndNameLength;

  /* Hold the DataFormatIdentifier value */
  uint8 GucDataFormatIdentifier;

  /* Holds the FileSizeParameterLength*/
  uint8 GucFileSizeParameterLength;

  /* Status value indicates whether or not RequestFileTransfer service
    is active
  */
  uint8 GucFileTransferActive;

  /* Status value indicates whether or not mode Add/Replace file is active */
  uint8 GucWriteFileActive;

  /* Status value indicates whether or not mode Read/ReadDir file is active */
  uint8 GucReadFileActive;

}Dcm_DspFileTransfer;

/* Design ID : DCM_SDD_6165 */

#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspFileTransfer, DCM_VAR_NO_INIT) Dcm_GddFile;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
