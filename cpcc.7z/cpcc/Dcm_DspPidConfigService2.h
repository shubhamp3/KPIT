/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspPidConfigService2.h                                    **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**              Request Power Train FreezeFrame Data(0x02)                    **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPPIDCONFIGSERVICE2_H
#define DCM_DSPPIDCONFIGSERVICE2_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

#if(DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON)
/* indicates if request for service 02 has requested and the order
of validating mixture of availaiblity and non availaiblity PID differs
in API Dcm_DspOBDPIDValidation */

/*Design ID : DCM_SDD_6190*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucPowerTrainFFSet;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
/*Design ID : DCM_SDD_6999*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyPID_Two[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#else

#define DCM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyPID_Two[];
#define DCM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyPTPID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspProcessNonAvialiabilityPTPID
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif/* DCM_DSPPIDCONFIGSERVICE2_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
