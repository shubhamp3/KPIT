def cfg_info(file):
  count=0
  with open(file,'r+') as fx:
     for line in fx:
       count=count+1
       if ' Common Published Information' in line:
         return count+1
  fx.close()


def linex(selectfile):
  count=0
  with open(selectfile,'r+')as fx:
   for line in fx:
      count=count+1
      if 'Include Section'  in line:
            return count
            break
   fx.close()


def liney(selectfile):
     count1=0
     with open(selectfile,'r+')as fx:
      fx.seek(0)
      for line in fx:
        count1=count1+1
        if 'Include Section'  in line:
            for line in fx:
                count1=count1+1
                if 'Global Data' in line:
                    return count1
                elif 'Function Definitions' in line:
                    return count1
                elif 'End of File' in line:
                    return count1
                else:
                    continue

      fx.close()            



