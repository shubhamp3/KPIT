/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspMemory.h                                               **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of DSP memory  Structure definitions                **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By          Description                    **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC fix           **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/*******************************************************************************
**                         Macros                                             **
** Design ID: DCM_SDD_5136                                                    **
** Design ID : DCM_SDD_9876                                                   **
*******************************************************************************/

#ifndef DCM_DSPMEMORY_H
#define DCM_DSPMEMORY_H

#define DCM_DSP_MEMORY_ADD_MASK_VALUE (uint8)0x0F
#define DCM_DSP_MEMORY_SIZE_MASK_VALUE (uint8)0xF0

#define DCM_DSP_MEMORY_ADD_MASK_VALUE_U8 (uint8)0x0F
#define DCM_DSP_MEMORY_SIZE_MASK_VALUE_U8 (uint8)0xF0

#define DCM_MAX_BLOCK_SEQUENCE_COUNTER (uint8)0xFF


#define DCM_DSP_MEMORYWRITE (uint8)0x01
#define DCM_DSP_MEMORYWRITE_REQDWLD (uint8) 0x02
#define DCM_DSP_MEMORYWRITE_REQUPLD (uint8) 0x04
#define DCM_DSP_MEMORYREAD  (uint8)0x03


#define DCM_INVALID_ADR_LEN_MEM_ID (uint8)0xFF
#define DCM_INVALID_MEM_ID (uint16)0xFFFF
#define DCM_INVALID_MEM_ADDR 0xFFFFu


#define DCM_ONE_BYTE_UINT32    (uint32)0x000000FF
#define DCM_TWO_BYTE_UINT32    0x0000FFFFu
#define DCM_THREE_BYTE_UINT32  (uint32)0x00FFFFFF
#define DCM_FOUR_BYTE_UINT32   0xFFFFFFFFu

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*Design ID : DCM_SDD_0969*/
typedef struct STag_Dcm_MemoryServices
{

 #if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)
 uint32 Dcm_DspSecVector;
 #endif

 uint32 Dcm_DspSesVector;

 /* To store the Requested Memory address*/
 uint32 usMemoryAddress;

 /* To store the Requested Memory Size */
 uint32 usMemorySize;

 #if((DCM_DSP_REQ_DOWNLOAD == STD_ON)||\
 (DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)||(DCM_DSP_REQ_UPLOAD == STD_ON))

  /* Block Length of Sequence is stored */
 uint32 usBlocklength;

 #endif


  #if(DCM_DSP_MODE_RULE == STD_ON)
 uint16 Dcm_DspMemRule;
 #endif

 #if((DCM_DSP_REQ_DOWNLOAD == STD_ON)||\
 (DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)||(DCM_DSP_REQ_UPLOAD == STD_ON))

 uint8 Dcm_DspUpLoadActive;

 /*
  E_OK: if Request is processed
  DCM_E_PENDING: if the request is in Pending
  E_NOT_OK:if the request is not accepted
 */
 uint8 Dcm_DspDownLoadActive;
 #endif
  /* To store the Requested Memory Identifier */
 uint8 Dcm_DspMemIdentifier;

 /* Used to store the number of address bytes provided in the WMBA request.
    variable used for updating message length and in scheduled functions.
 */
 uint8 Dcm_DspMemoryAdressbytes;

 /* Used to store the number of size bytes provided in the WMBA request.
    variable used for updating message length and in scheduled functions.
 */
 uint8 Dcm_DspMemorysizebytes;

 uint8 Dcm_MemInfoArrayIndex;

}Dcm_DspMemoryServices;

#if ((DCM_DSP_REQ_DOWNLOAD == STD_ON)||\
(DCM_DSP_REQ_UPLOAD == STD_ON)||\
(DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)||\
(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)||\
(DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)||\
(DCM_DSP_READ_MEMORY_BY_ADD == STD_ON))
/* Design ID : DCM_SDD_6168 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspMemoryServices,DCM_VAR_NO_INIT)Dcm_GddMemoryServices;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_REQ_DOWNLOAD == STD_ON) ||\
    (DCM_DSP_REQ_UPLOAD == STD_ON) ||\
   (DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)||\
   (DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)||\
     (DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON))

#if(DCM_DSP_READ_MEM_RANGE_INFO == STD_ON)
/*Design ID : DCM_SDD_0961*/
typedef struct STag_Dcm_DspMemReadRangeInfo
{
  /* duplicate of DcmDspReadMemoryRangeHigh */
  uint32 usReadMemoryRangeHigh;

  /* duplicate of DcmDspReadMemoryRangeLow */
  uint32 usReadMemoryRangeLow;

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspReadMemoryRangeSessionLevelRef, then this field will be set as
     00000000000000000000000010011000b i.e., 0x00000098.

     Note: If the field DcmDspReadMemoryRangeSessionLevelRef is empty, the
     default value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 usReadMemoryRangeSessionLevel;

  /*
    There can only be 32 security levels in one DCM. Hence the following is a
    mask containing if the Service is configured for this service.
    If for example, if security levels 10, 13 and 30 are referred through
    DcmDspDidWriteSecurityLevelRef, then this field will be set as
    010000000001001000000000000000000b i.e., 0x40120000

    Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
    value is all bits set i.e., 0xFFFFFFFF
  */
  #if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)
  uint32 usReadMemoryRangeSecurityLevel;
  #endif
  /* If the DcmDspReadMemoryRangeModeRuleRef is configured that
    rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucReadMemoryModeRuleIndex;
  #endif
}Dcm_DspMemReadRangeInfo;

/* Design ID : DCM_SDD_6153 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspMemReadRangeInfo,DCM_CONST)
  Dcm_GddMemReadRange[DCM_MEM_READ_RANGE_NUM];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

#if(DCM_DSP_WRITE_MEM_RANGE_INFO == STD_ON)
typedef struct STag_Dcm_DspMemWriteRangeInfo
{
/* duplicate of DcmDspWriteMemoryRangeHigh */
uint32 usWriteMemoryRangeHigh;

/* duplicate of DcmDspWriteMemoryRangeLow */
uint32 usWriteMemoryRangeLow;

/*
   There can only be 32 Sessions in one DCM. Hence the following is a
   mask containing if the Service is configured for this service.
   If for example, if sessions 3, 4 and 7 are referred through
   DcmDspWriteMemoryRangeSessionLevelRef, then this field will be set as
   00000000000000000000000010011000b i.e., 0x00000098.

   Note: If the field DcmDspWriteMemoryRangeSessionLevelRef is empty, the
   default value is all bits set i.e., 0xFFFFFFFF
*/
uint32 usWriteMemoryRangeSessionLevel;

/*
  There can only be 32 security levels in one DCM. Hence the following is a
  mask containing if the Service is configured for this service.
  If for example, if security levels 10, 13 and 30 are referred through
  DcmDspDidWriteSecurityLevelRef, then this field will be set as
  010000000001001000000000000000000b i.e., 0x40120000

  Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
  value is all bits set i.e., 0xFFFFFFFF
*/
#if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)
uint32 usWriteMemoryRangeSecurityLevel;
#endif

#if(DCM_DSP_MODE_RULE == STD_ON)
uint16 ucWriteMemoryModeRuleIndex;
#endif

}Dcm_DspMemWriteRangeInfo;
/* this array instances should be should be sorted as per the
  Dcm_GaaMemidinfo  */

/* Design ID : DCM_SDD_6155 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspMemWriteRangeInfo,DCM_CONST)
  Dcm_GddMemWriteRange[DCM_MEM_WRITE_RANGE_NUM];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

#if(\
(((DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)||\
  (DCM_DSP_REQ_DOWNLOAD == STD_ON))&&\
  (DCM_DSP_WRITE_MEM_RANGE_INFO == STD_ON))||\
((DCM_DSP_READ_MEM_RANGE_INFO == STD_ON) &&\
    ((DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)||(DCM_DSP_REQ_UPLOAD == STD_ON)\
    || (DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON))))

/*Design ID : DCM_SDD_0960*/
typedef struct STag_Dcm_DspMemoryIdInfo
{
    #if(((DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)||\
    (DCM_DSP_REQ_DOWNLOAD == STD_ON))&&\
    (DCM_DSP_WRITE_MEM_RANGE_INFO == STD_ON))
    /* The starting index of Dcm_GddMemWriteRange of that particular instance
    of DcmDspMemoryIdInfo */
    P2CONST(Dcm_DspMemWriteRangeInfo, AUTOMATIC, DCM_CONST)pMemWriteRangeinfo;
    #endif


    #if((DCM_DSP_READ_MEM_RANGE_INFO == STD_ON) &&\
    ((DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)||(DCM_DSP_REQ_UPLOAD == STD_ON) ||\
    (DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)))
    /* The starting index of Dcm_GddMemWriteRange of that particular instance
    of DcmDspMemoryIdInfo */
    P2CONST(Dcm_DspMemReadRangeInfo, AUTOMATIC, DCM_CONST)pMemReadRangeinfo;
    #endif

    #if(((DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)||\
    (DCM_DSP_REQ_DOWNLOAD == STD_ON))&&\
    (DCM_DSP_WRITE_MEM_RANGE_INFO == STD_ON))
    /* The number of write DcmDspWriteMemoryRangeInfo container configured
    under that particular DcmDspMemoryIdValue */
    uint8 ucNoWriteRangeinfo;
    /* If the DcmDspWriteMemoryRangeModeRuleRef is configured that
    rule index needs be generated else 0XFFFF needs to generated  */
    #endif

    #if((DCM_DSP_READ_MEM_RANGE_INFO == STD_ON) &&\
    ((DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)||(DCM_DSP_REQ_UPLOAD == STD_ON) ||\
    (DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)))
    /* The number of write DcmDspWriteMemoryRangeInfo container configured
    under that particular DcmDspMemoryIdValue */
    uint8 ucNoReadRangeinfo;
    #endif
}Dcm_DspMemoryIdInfo;

/* Design ID : DCM_SDD_6156 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
 extern CONST(Dcm_DspMemoryIdInfo,DCM_CONST)
  Dcm_GddMemoryinfoconfig[DCM_MEM_INFO_CONFIG_NUM];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if (DCM_DSP_ADD_LEN_FORM_ID == STD_ON)
/* Design ID : DCM_SDD_6087 */
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8,DCM_CONST)Dcm_GaaAddLenFormID[DCM_ADDR_LEN_FORMAT_LEN];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_MEMORY_INFO == STD_ON)||(DCM_DSP_MEM_IDS_ONLY == STD_ON))
/*Design ID : DCM_SDD_6067*/
#define DCM_START_SEC_CONST_16
#include "Dcm_MemMap.h"
extern CONST(uint16, DCM_CONST)Dcm_GaaMemoryIdList[DCM_MEM_ID_LIST_SIZE];
#define DCM_STOP_SEC_CONST_16
#include "Dcm_MemMap.h"
#endif

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif
/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
