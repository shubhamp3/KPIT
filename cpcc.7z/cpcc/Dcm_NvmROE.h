/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_NvmROE.h                                                  **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare RAM and ROM structures to be used by NVM           **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_NVMROE_H
#define DCM_NVMROE_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Std_Types.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif

#define DCM_TEN_ROE 0x0A

#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#define DCM_START_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_SAVED_ZONE)
Dcm_GaaEventSetupDetails[DCM_ROE_NUM_OF_EVENTS
  * DCM_TEN_ROE];
#define DCM_STOP_SEC_VAR_SAVED_ZONE_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaEventROMSetupDetails[DCM_ROE_NUM_OF_EVENTS
  * DCM_TEN_ROE];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

#endif
#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
