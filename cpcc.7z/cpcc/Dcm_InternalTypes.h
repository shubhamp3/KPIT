/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_InternalTypes.h                                           **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsl Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC               **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_INTERNALTYPES_H
#define DCM_INTERNALTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "ComStack_Types.h"
#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif

/*******************************************************************************
**                      Macro Definitions                                     **
**                      Design ID : DCM_SDD_0903                              **
*******************************************************************************/
/*******************************************************************************
**                      GENERAL MACROS                                        **
*******************************************************************************/
/* Macro for Unused parameter */
#define DCM_UNUSED(x) (void)(x)
#define DCM_INVALID_U8                              0x00u
/* Possible values of Dcm_GblInitStatus */
#define DCM_INITIALISED                           (boolean)0x01
#define DCM_UNINITIALISED                         (boolean)0x00

/* Common integer values */
#define DCM_ZERO_S8                                0x00
#define DCM_ZERO                                   0x00u
#define DCM_ONE                                    0x01u
#define DCM_TWO                                    0x02u
#define DCM_THREE                                  0x03u
#define DCM_FOUR                                   0x04u
#define DCM_FIVE                                   0x05u
#define DCM_SIX                                    0x06u
#define DCM_SEVEN                                  0x07u
#define DCM_EIGHT                                  0x08u
#define DCM_NINE                                   0x09u
#define DCM_TEN                                    0x0Au
#define DCM_FOURTEEN                               0x0Eu
#define DCM_0x10_U8                                0x10u
#define DCM_0x20_U8                                0x20u

/* Common boolean values */
#define DCM_TRUE                                  (boolean)0x01
#define DCM_FALSE                                 (boolean)0x00

/* Common uint8 values */
#define DCM_ZERO_U8                               (uint8)0x00
#define DCM_ONE_U8                                (uint8)0x01
#define DCM_TWO_U8                                (uint8)0x02
#define DCM_THREE_U8                              (uint8)0x03
#define DCM_FOUR_U8                               (uint8)0x04
#define DCM_SIX_U8                                (uint8)0x06
#define DCM_SEVEN_U8                              (uint8)0x07
#define DCM_EIGHT_U8                              (uint8)0x08
#define DCM_0x0B_U8                               (uint8)0x0B
#define DCM_0x0C_U8                               (uint8)0x0C
#define DCM_0xFF_U8                               (uint8)0xFF
#define DCM_0xFF_U16                              0xFFFFu
#define DCM_0xEF_U8                               (uint8)0xEF
#define DCM_0xFE_U8                               (uint8)0xFE
#define DCM_0x60_U8                               (uint8)0x60
#define DCM_0x90_U8                               (uint8)0x90
/* Pending NRC's*/
#define DCM_NO_NRC_PENDING                        (uint8)0x00
#define DCM_NRC_PENDING                           (uint8)0x01
#define DCM_DSP_PERIODIC_SID                      (uint8)0x2A

/* Common uint16 values */
#define DCM_ZERO_U16                              (uint16)0x0000
#define DCM_ONE_U16                               (uint16)0x01
#define DCM_TWO_U16                               (uint16)0x02
#define DCM_THREE_U16                             (uint16)0x03
#define DCM_FOUR_U16                              (uint16)0x04
#define DCM_FIVE_U16                              (uint16)0x05
#define DCM_SIX_U16                               (uint16)0x06
#define DCM_SEVEN_U16                             (uint16)0x07
#define DCM_EIGHT_U16                             (uint16)0x08
#define DCM_0x0B_U16                              (uint16)0x0B
#define DCM_0x0C_U16                              (uint16)0x0C

#define DCM_FF_U16                                (uint16)0xFF
#define DCM_INVALID_U16                           (uint16)0xFFFFu

/* Common uint32 values */
#define DCM_ZERO_U32                              (uint32)0x00
#define DCM_ONE_U32                               (uint32)0x01
#define DCM_TWO_U32                               (uint32)0x02
#define DCM_THREE_U32                             (uint32)0x03
#define DCM_FOUR_U32                              (uint32)0x04
#define DCM_FIVE_U32                              (uint32)0x05
#define DCM_SIX_U32                               (uint32)0x06
#define DCM_EIGHT_U32                             (uint32)0x08
#define DCM_TEN_U32                               (uint32)0x0A
#define DCM_0x10_U32                              (uint32)0x10
#define DCM_0x20_U32                              (uint32)0x20
#define DCM_24_U32                                (uint32)0x18
#define DCM_0x00FF0000_U32                        (uint32)0x00FF0000
#define DCM_0x0000FF00_U32                        0x0000FF00u
#define DCM_INSTANCE_ID                           (uint8)0x01
#define DCM_0x0C_U32                              (uint32)0x0C
/* Common masks */
#define  DCM_SUPPRESS_POS_RESP_MASK               (uint8)0x80
#define  DCM_RESPONSE_SID_MASK                    (uint8)0x40

#define DCM_FUNCTIONAL_ADDRESSING                 (uint8)0x01

/* Common NRC Macros */
#define DCM_NR_SID                                (uint8)0x7F
#define DCM_NR_LENGTH                             (uint8)0x03

#define DCM_REQUEST_PENDING                       (uint8)0x01
#define DCM_SCHEDULED_IN_PROGRESS                 (uint8)0x02

/* 8 bit masks */
#define DCM_LOWER_SIX_BITS_MASKED                  0x3Fu

/* The following macros are for comparison of SIDs in the range of
   diagnostic response identifiers. They are used when DCM_RESPOND_ALL_REQUEST
   is STD_OFF */
#define DCM_0x40_U8                                0x40u
#define DCM_0x7F_U8                                0x7Fu
#define DCM_0xC0_U8                                0xC0u


/* The SubFunction-0x03 of 0x28 service*/
#define DCM_COMMCTRL_DISABLE_RX_TX                        (uint8)0x03
/* The SubFunction-0x04 of 0x28 service*/
#define DCM_COMMCTRL_ENABLERX_DISABLETX_ENHAN_ADRESS      (uint8)0x04

/* Values of Dcm_GucPagedBufferingStatus */
#define DCM_NEW_PAGE_READY                          (uint8)0x01
#define DCM_PAGE_UPDATE_PENDING                     (uint8)0x03
#define DCM_NO_PAGED_BUFFERING                      (uint8)0x02
#define DCM_PAGE_LOCK_BUFFER                        (uint8)0x04
#define DCM_PAGE_BUFFERING_CANCELLED                (uint8)0x05
#define DCM_PAGE_BUFFERING_COMPLETED                (uint8)0x06
#define DCM_PAGE_TP_TO_COPY                         (uint8)0x07
#define DCM_PAGE_RESPONSE_TOO_LONG                  (uint8)0x08

/* Service ID for ROE */
#define DCM_ROE_SID                                 (uint8)0x86
#define DCM_ROE_INTERMESSAGETIMER_IDLE              (uint8)0x00
#define DCM_ROE_INTERMESSAGETIMER_BUSY              (uint8)0x01
#define DCM_EXTERNAL_PROCESSING                     (uint8)0x00
#define DCM_INTERNAL_PROCESSING                     (uint8)0x01

/* service RDBI for OBD UDS Interface */
#define DCM_0x0F_U16                                (uint16)0x0F
#define DCM_0x0E_U16                                (uint16)0x0E
#define DCM_0x12_U16                                (uint16)0x12
#define DCM_0x24_U16                                (uint16)0x24
#define DCM_0x48_U16                                (uint16)0x48
#define DCM_MASK_HIGHER_NIBBLE_U16                  (uint16)0xF0
#define DCM_OBD_PID_LOWER_RANGE                     0xF400u
#define DCM_OBD_PID_HIGHER_RANGE                    0xF4FFu
#define DCM_OBDMID_LOWER_RANGE                      0xF600u
#define DCM_OBDMID_HIGHER_RANGE                     0xF6FFu
#define DCM_INFOTYPE_LOWER_RANGE                    0xF800u
#define DCM_INFOTYPE_HIGHER_RANGE                   0xF8FFu
#define DCM_MSB_LOWER_NIBBLE                        0x0F00u

/*******************************************************************************
**            SIDs for Functions provided to BSW modules and to SW-Cs         **
*******************************************************************************/

/* Service Id of Dcm_GetSecurityLevel */
#define DCM_GET_SECURITY_LEVEL_SID                                 (uint8)0x0D

/* Service Id of Dcm_GetSesCtrlType */
#define DCM_GET_SES_CTRL_TYPE_SID                                  (uint8)0x06

/* Service Id of Dcm_GetVersionInfo */
#define DCM_GET_VERSION_INFO_SID                                   (uint8)0x24

/*******************************************************************************
**                    SIDs for Callback Notifications                         **
*******************************************************************************/

/* Service Id of Dcm_StartOfReception */
#define DCM_START_OF_RECEPTION_SID                                  (uint8)0x46

/* Service Id of Dcm_CopyRxData */
#define DCM_COPY_RXDATA_SID                                         (uint8)0x44

/* Service Id of Dcm_TpRxIndication */
#define DCM_TP_RX_INDICATION_SID                                    (uint8)0x45

/* Service Id of Dcm_CopyTxData */
#define DCM_COPY_TXDATA_SID                                         (uint8)0x43

/* Service Id of Dcm_TpTxConfirmation */
#define DCM_TX_CONFIRMATION_SID                                     (uint8)0x48

/* Service Id of Dcm_ComM_NoComModeEntered */
#define DCM_COMM_NO_COM_MODE_ENTERED_SID                            (uint8)0x21

/* Service Id of Dcm_ComM_SilentComModeEntered */
#define DCM_COMM_SILENT_COM_MODE_ENTERED_SID                        (uint8)0x22

/* Service Id of Dcm_ComM_FullComModeEntered */
#define DCM_COMM_FULL_COM_MODE_ENTERED_SID                          (uint8)0x23

/*******************************************************************************
**                     SIDs for Callout Definitions                           **
*******************************************************************************/

/*******************************************************************************
**                     SIDs for Scheduled Functions                           **
*******************************************************************************/
/* Service Id of Dcm_MainFunction */
#define DCM_MAIN_FUNCTION_SID                                       (uint8)0x25
/*******************************************************************************
**                      MACROS RELATED TO COM STACK                           **
*******************************************************************************/
#define DCM_ZERO_PDU_LENGTH                           (PduLengthType)0x00
#define DCM_ONE_PDU_LENGTH                            (PduLengthType)0x01
#define DCM_TWO_PDU_LENGTH                            (PduLengthType)0x02
#define DCM_THREE_PDU_LENGTH                          (PduLengthType)0x03
#define DCM_FOUR_PDU_LENGTH                           (PduLengthType)0x04
#define DCM_FIVE_PDU_LENGTH                           (PduLengthType)0x05
#define DCM_SIX_PDU_LENGTH                            (PduLengthType)0x06

#define DCM_0x0F_U32                                  (uint32)0x0F
#define DCM_0x0E_U32                                  (uint32)0x0E
#define DCM_FIVE_U8                                   (uint8)0x05
#define DCM_FIFTEEN                                   (uint8)0x0F
#define DCM_0x0F_U8                                   (uint8)0x0F
#define DCM_MASK_HIGHER_NIBBLE                        (uint8)0xF0
#define DCM_SID_ROUTINE_CONTROL                       (uint8)0x31
#define DCM_OBD_RID                                   (uint8)0xE0
#define DCM_SID_RDBI                                  (uint8)0x22
/* #define DCM_VEHMANUFACTURERSPECMIN                    (uint8)0x40
 #define DCM_VEHMANUFACTURERSPECMAX                    (uint8)0x5F
 #define DCM_SYSSUPPLIERSPECMIN                        (uint8)0x60
 #define DCM_SYSSUPPLIERSPECMAX                        (uint8)0x7E */


/* Dcm protocol used */
#if (DCM_PRE_COMPILE_SINGLE == STD_ON)
#define DCM_PROTOCOL_USED(LpProtocolConfig, LucProtocolIndex)\
          LpProtocolConfig = (&Dcm_GaaProtocolConfig[LucProtocolIndex])
#else
#define DCM_PROTOCOL_USED(LpProtocolConfig, LucProtocolIndex)\
 LpProtocolConfig =\
         Dcm_GpConfigPtr->pProtocolRowUsedRef[LucProtocolIndex].pProtocolconfig;
#endif

/*
 * IdContext is used to determine the relation between request and response
 * confirmation
 */
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*Strcture to be used for Responsefrom MainFunction functionality*/
#if(DCM_RESPONSE_FROM_MAINFUNC_ENABLED == STD_ON)
/*Design ID : DCM_SDD_5086*/
typedef struct STag_ResponseFromMainFunction
{
  uint8 ucConnectionIndex;
  PduInfoType ddPduInfo;
}Dcm_ResponseMainFunction;
#endif

/*******************************************************************************
**                      Internal RAM Types                                    **
*******************************************************************************/

/* Defined for the array  Dcm_GaaComMMode[] */
typedef enum
{
  DCM_FULL_COMMUNICATION=0,
  DCM_SILENT_COMMUNICATION,
  DCM_NO_COMMUNICATION
}Dcm_ComMModeType;

/*      Additional information on message request */

/*******************************************************************************
                      Static RAM
*******************************************************************************/
/* Design ID : DCM_SDD_6096 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblInitStatus;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6200 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT)Dcm_GblDiagBootJump;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR_INIT) Dcm_GaaGenPendingVector[];
#define DCM_STOP_SEC_VAR_INIT_32
#include "Dcm_MemMap.h"

#if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
/*Design ID : DCM_SDD_6007*/
/*Design ID : DCM_SDD_6105*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucPagedBufferingStatus;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
#endif

/* Design ID : DCM_SDD_6106 */
#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucRoeInterMessageTimerStatus;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6098 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblRoeInterMessageTimer;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6112 */
#define DCM_START_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"
extern VAR(uint16, DCM_VAR_NO_INIT) Dcm_GusRoeInterMessageTimerValue;
#define DCM_STOP_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"
#endif

/* Design ID : DCM_SDD_6111 */
#define DCM_START_SEC_VAR_CLEARED_16
#include "Dcm_MemMap.h"
extern VAR(uint16, DCM_VAR) Dcm_GusCurrentDidIndex;
#define DCM_STOP_SEC_VAR_CLEARED_16
#include "Dcm_MemMap.h"

/*******************************************************************************
                      Tool Generated Data
*******************************************************************************/
typedef enum
{
  DCM_NO_BOOT = 0x00,
  DCM_OEM_BOOT,
  DCM_OEM_BOOT_RESPAPP,
  DCM_SYS_BOOT,
  DCM_SYS_BOOT_RESPAPP
}Dcm_DspSessionBootType;

#if(DCM_DSP_DIAG_SESSION_SERVICE == STD_ON)
/**
  Name: Dcm_GaaSessionMapping
  Type: A Mapping Array
  Configuration Dependencies: DcmDspSessionRow->DcmDspSessionLevel
  Generation Description: This array maps DcmDspSessionLevel to the right
  index of Dcm_GaaSessionMapping. For example, if DcmDspSessionRow with
  DcmDspSessionLevel equal to 0x07 is the 3rd element of Dcm_GaaSessionMapping,
  the 0x07th element of Dcm_GaaSessionMapping shall be 0x03.
  If the DcmDspSessionLevel is not configured, DCM_INVALID_SESSION
  shall be generated.
**/
/*Design ID : DCM_SDD_6078*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSessionMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/**
  Name: Dcm_GaaDspSessionRow
  Type: A Mapping Array
  Configuration Dependencies: DcmDspSessionRow
  Generation Description: This structure is instantiated per
  DcmDspSessionRow configured
**/
/*Design ID : DCM_SDD_5087*/
typedef struct STag_Dcm_DspSessionRow
{
  /* This shall be a duplicate of the parameter D
     DcmDspSessionRow->DcmDspSessionForBoot */
  Dcm_DspSessionBootType ddSessionForBoot;

  /*  DcmDspSessionP2ServerMax*1000 */
  uint16 usDspSesP2ServerMax;

  /* DcmDspSessionP2StarServerMax*1000 */
  uint16 usDspSesP2StarServerMax;

  /* DcmDspSessionP2ServerMax in ticks i.e.,
     DcmDspSessionP2ServerMax/DcmTaskTime */
  uint16 usDspSesP2ServerMaxCyc;

    /* DcmDspSessionP2StarServerMax in ticks i.e.,
     DcmDspSessionP2StarServerMax/DcmTaskTime */
  uint16 usDspSesP2StarServerMaxCyc;

}Dcm_DspSessionRowType;

typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_ModeFuncPtrType)
        (Dcm_NegativeResponseCodeType *LddNRC);

/* Design ID : DCM_SDD_6144 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspSessionRowType, DCM_CONST) Dcm_GaaDspSessionRow[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6095 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblBLPosResponse;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

#endif /* DCM_DSP_DIAGNOSTICSERVICE == STD_ON */

#if(DCM_DSP_DIAG_SESSION_SERVICE == STD_ON)
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblProgSessionSetFlag;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
#endif
/* Design ID : DCM_SDD_6094 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GaaTempReadData[];
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

#if(DCM_DSP_MODE_RULE == STD_ON)
/*Design ID : DCM_SDD_6077*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ModeFuncPtrType, DCM_CONST) DCM_GaaRuleFunc[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_RESPONSE_FROM_MAINFUNC_ENABLED == STD_ON)
/*Design ID : DCM_SDD_6081*/
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT)Dcm_GblResponsefromMainFunc;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6080*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT)Dcm_GucNegativeResponse;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6169 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_ResponseMainFunction, DCM_VAR_INIT) Dcm_GddResponseMainFunction;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#if((DCM_ROE_SERVICE_CONFIGURED == STD_ON)&&\
  (DCM_RESPONSE_FROM_MAINFUNC_ENABLED == STD_ON))
/*Design ID : DCM_SDD_6082*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT)Dcm_GucROEFinalResponse;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
#endif

#endif
#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
