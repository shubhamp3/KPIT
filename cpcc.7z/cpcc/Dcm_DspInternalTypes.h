/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspInternalTypes.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC fix           **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPINTERNALTYPES_H
#define DCM_DSPINTERNALTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_InternalTypes.h"
#include "SchM_Dcm.h"
#include "Dcm_DslInternalTypes.h"

/*******************************************************************************
**                      Macro Definitions                                     **
**                 Design ID : DCM_SDD_5135                                   **
*******************************************************************************/
/*******************************************************************************
                    Internal Macros (not tool-generated)
*******************************************************************************/

#define DCM_8L (uint16)0x0008


/* Possible values of ucAttemptDelayTimerStatus */
#define DCM_DSP_START_ATTEMPT_DELAY_TIMER (uint8)0x01
#define DCM_DSP_START_ATTEMPT_DELAY_ACTIVE (uint8)0x02
#define DCM_DSP_ATTEMPT_DELAY_TIMER_INACTIVE (uint8)0x00
/*******************************************************************************
                    Security Access: Data
*******************************************************************************/

/* Macros related to SecurityAccess Service */
#define DCM_ATTEMPT_COUNTER_INIT_PENDING (uint8) 0xFF

#define DCM_ATLEAST_ONE_COUNTER_INIT_PENDING (boolean) 0x01
#define DCM_NO_COUNTER_INIT_PENDING (boolean) 0x00

#define DCM_E_PAGED_BUFFERING 0x0Cu
#define DCM_E_PAGED_BUFFERING_NOK 0x0Du
#define DCM_E_BUFFER_TOO_SMALL   0X0Eu

/*******************************************************************************
                    Security Access: Data
*******************************************************************************/
#define DCM_DSP_READ_PERIODIC_DATA_BY_IDENTIFIER (uint16) 0xF200u
#define DCM_DSP_READ_DYN_DATA_BY_IDENTIFIER      (uint16) 0xF3FFu
#define DCM_DSP_READ_PERIODIC_DATA               (uint8) 0xF2

#define DCM_INVAILD_DID                           (uint8)0xFF
#define DCM_DSP_PID_NO_REQUEST                    (uint8)0x00

#define DCM_DSP_PDID_RESPONSE_TRIGGERED           (uint8)0x01
#define DCM_DSP_PDID_ACCEP_TIMER_LODING           (uint8)0x02
#define DCM_DSP_PDID_RESPONSE_CONF                (uint8)0x03

#define DCM_DSP_PDID_ACCEPTED                     (uint8)0x01
#define DCM_DSP_PDID_TIMER_IN_PROGRESS            (uint8)0x02
#define DCM_DSP_PDID_TIMER_LODED                  (uint8)0x03
#define DCM_DSP_PDID_TIMER                        (uint8)0x04
#define DCM_DSP_PDID_ACCEPTED_NOT_CONFIRMED       (uint8)0x05

#define DCM_DSP_MULTIPLE_PID_NO_REQUEST           (uint8)0x00
#define DCM_DSP_MILTIPLE_TRIGGERED                (uint8)0x01
#define DCM_DSP_MULTIPLE_DID_ACCEPTED             (uint8)0x02


/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/* This array is used a common for WDBI,RDBI,ROC and ROE services.
   So the service which has the maximum generated mask words that should be size
   of   Dcm_GaaGenPendingVector.

   The each service will have its own algorithm for the calculation of size
   of Size will be updated  below
   RDBI:The maximum size of usReadPendingPos
   WDBI:The maximum size of usWritePendingPos
 EX: for RDBI  Across all RDBI Mask structures the maximum value generated for
     the usReadPendingPos  is 0x12 then the size for RDBI is 0x12.
     For the WDBI  Across all WDBI Mask structures the maximum value generated
     for the usWritePendingPos  is 0x12 then the size for RDBI is 0x14.
     For Transfer Data size should always be generated as 1
     So the Size of  Dcm_GaaCommonRamArea is 0x14    */

/* Design ID : DCM_SDD_6088 */
#define DCM_START_SEC_VAR_CLEARED_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR) Dcm_GaaCommonRamArea[];
#define DCM_STOP_SEC_VAR_CLEARED_32
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6090 */
#define DCM_START_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR_NO_INIT) Dcm_GaaOBDCommonRamArea[];
#define DCM_STOP_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"

#if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)
/**
  Name: Dcm_GaaSecurityLevMapping
  Type: Mapping array
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow,
  DcmDspSecurityRow->DcmDspSecurityLevel
  Description: This array shall contain a mapping between DcmDspSecurityLevel
  and the array Dcm_DspSecurityAccess. For example, if the DcmDspSecurityRow
  with DcmDspSecurityLevel 0x02, is the 0th element of Dcm_GaaSecurityAccess,
  then the 2nd element of Dcm_GaaSecurityLevMapping shall be 0x00.
  If the nth session level doesn't exist, then the nth element shall be
  DCM_INVALID_SECURITY_LEVEL
**/

/*Design ID : DCM_SDD_6177*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSecurityLevMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"


/**
  Name: Dcm_GaaDspSecurityAccessAttempts
  Type: Array of Structures
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow,
  DcmDspSecurityAttemptCounterEnabled,
  Description: Dcm_GaaDspSecurityAccessAttempts[] contains configuration related
  to attempt timer. It shall be sorted as follows:
  For all  DcmDspSecurityRows with DcmDspSecurityAttemptCounterEnabled TRUE,
  the corresponding Dcm_GaaDspSecurityAccessAttempts[] will be generated
  first i.e., before the DcmDspSecurityRows with
  DcmDspSecurityAttemptCounterEnabled as FALSE. Then all the FALSE rows
  will be generated.

**/
/*Design ID : DCM_SDD_5073*/
typedef struct STag_Dcm_DspAttemptConfig
{
  #if(DCM_NUM_SECROWS_WITH_ATTEMPT_CNTR_EXT_STR > DCM_ZERO)
  /*
    Default Value: NULL_PTR
    This pointer should be
     generated as NULL_PTR if DcmDspSecurityAttemptCounterEnabled is false.

    This is a function pointer asking the relevant SW-C for a seed. If
     DcmDspSecurityUsePort is USE_ASYNCH_FNC, this shall be generated using
     the parameter DcmDspSecurityGetAttemptCounterFnc i.e., if
     DcmDspSecurityGetAttemptCounterFnc is 'GetAttemptCounterFnc_1',
   this element shall be '&GetAttemptCounterFnc_1'. If DcmDspSecurityUsePort
   is USE_ASYNCH_CLIENT_SERVER instead, the port name shall be
   Rte_Call_SecurityAccess_{SecurityLevel} where SecurityLevel is the name of
   the container DcmDspSecurityRow, and function name shall be
   SecurityAccess_{SecurityLevel}_GetSecurityAttemptCounter. For example,
     if the shortname is SecLevel1, the CompareKey function shall be
     '&SecurityAccess_SecLevel1_GetSecurityAttemptCounter'.  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pGetSecurityAttemptCounter)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR)AttemptCounter
  );

   /*
      Default Value: NULL_PTR
    This pointer should be
     generated as NULL_PTR if DcmDspSecurityAttemptCounterEnabled is false.

    This is a function pointer asking the relevant SW-C for a seed. If
     DcmDspSecurityUsePort is USE_ASYNCH_FNC, this shall be generated using
     the parameter DcmDspSecuritySetAttemptCounterFnc i.e., if
     DcmDspSecuritySetAttemptCounterFnc is 'SetAttemptCounterFnc_1',
   this element shall be '&SetAttemptCounterFnc_1'. If DcmDspSecurityUsePort
   is USE_ASYNCH_CLIENT_SERVER instead, the port name shall be
   Rte_Call_SecurityAccess_{SecurityLevel} where
     SecurityLevel is the name of the container DcmDspSecurityRow, and function
     name shall be SecurityAccess_{SecurityLevel}_SetSecurityAttemptCounter.
   For example, if the shortname is SecLevel1, the CompareKey function
   shall be '&SecurityAccess_SecLevel1_SetSecurityAttemptCounter'.
  */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSetSecurityAttemptCounter)
  (
    Dcm_OpStatusType OpStatus,
    uint8 AttemptCounter
  );
  #endif

  /* This element is equal to ticks DcmDspSecurityDelayTime/DcmTaskTime. This is
     an optional parameter. Hence, if it is not configured, the value of
    usSecDelayTime shall be DCM_SEC_ATT_TIMER_ABSENT */
  uint32 usSecDelayTime;

  /* This element is directly equal to DcmDspSecurityNumAttDelay. This is
     an optional parameter. Hence, if it is not configured, the value of
    ucSecurityNumAttDelay shall be DCM_SEC_ATT_COUNTER_ABSENT */
  uint8 ucSecurityNumAttDelay;
}Dcm_DspAttemptConfig;

/* Design ID : DCM_SDD_6115 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAttemptConfig, DCM_CONST) Dcm_GaaAttemptConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

typedef P2FUNC(Std_ReturnType, DCM_APPL_CODE, Dcm_GetSeedNoADR)
  (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Seed,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode
  );

  typedef P2FUNC(Std_ReturnType, DCM_APPL_CODE, Dcm_GetSeedWithADR)
  (
    P2CONST(uint8, AUTOMATIC, DCM_CONST)SecurityAccessDataRecord,
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR)Seed,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode
  );

#if(DCM_DSP_SECURITYROW_WITHOUT_ADR == STD_ON)
  /**
  Name: Dcm_GaaGetSeedNoADR
  Type: Array of function pointers
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow, DcmDspSecurityUsePort,
  DcmDspSecurityGetSeedFnc, DcmDspSecurityADRSize
  Description: This array points to functions Xxx_GetSeed for which
  DcmDspSecurityADRSize is not
  configured.

  The generation will be based on the rules set
  for client server interfaces, if DcmDspSecurityUsePort is configured as
  USE_ASYNCH_CLIENT_SERVER. It shall be equal to
  Rte_Call_SecurityAccess_{SecurityLevel}_GetSeed where
  SecurityLevel is the shortname of the DcmDspSecurityRow container.

  If configured as USE_ASYNCH_FNC, it shall be
  the copy of DcmDspSecurityGetSeedFnc.

**/
/*Design ID : DCM_SDD_6065*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_GetSeedNoADR, DCM_CONST) Dcm_GaaGetSeedNoADR[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_SECURITY_ADR == STD_ON)
/**
  Name: Dcm_GaaGetSeedWithADR
  Type: Array of function pointers
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow, DcmDspSecurityUsePort,
  DcmDspSecurityGetSeedFnc, DcmDspSecurityADRSize
  Description: This array points to functions Xxx_GetSeed for all
  DcmDspSecurityRows in which DcmDspSecurityADRSize is configured.

  The generation will be based on the rules set
  for client server interfaces, if DcmDspSecurityUsePort is configured as
  USE_ASYNCH_CLIENT_SERVER. It shall be equal to
   Rte_Call_SecurityAccess_{SecurityLevel}_GetSeed  where
  SecurityLevel is the shortname of the DcmDspSecurityRow container.

  If configured as USE_ASYNCH_FNC, it shall be
  the copy of DcmDspSecurityGetSeedFnc.

**/
/*Design ID : DCM_SDD_6066*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_GetSeedWithADR, DCM_CONST) Dcm_GaaGetSeedWithADR[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/**
  Name: Dcm_GaaSecurityRow
  Type: Array of Structures
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow
  Description:
**/
/*Design ID : DCM_SDD_5074*/
typedef struct STag_Dcm_DspSecurityRow
{

  /* This is a function pointer asking the relevant SW-C for a seed. If
     DcmDspSecurityUsePort is USE_ASYNCH_FNC, this shall be generated using
     the parameter DcmDspSecurityCompareKeyFnc i.e., if
     DcmDspSecurityCompareKeyFnc is 'CompareKeyFnc_1', this element shall be
     '&CompareKeyFnc_1'.
   If DcmDspSecurityUsePort is USE_ASYNCH_CLIENT_SERVER instead,
     the port name shall be Rte_Call_SecurityAccess_{SecurityLevel} where
     SecurityLevel is the name of the container DcmDspSecurityRow, and function
     name shall be SecurityAccess_{SecurityLevel}_CompareKey. For example,
     if the shortname is SecLevel1, the CompareKey function shall be
     '&SecurityAccess_SecLevel1_CompareKey'. */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pCompareKey)
  (
    P2CONST(uint8, AUTOMATIC, DCM_CONST)Key,
    Dcm_OpStatusType OpStatus,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR)ErrorCode
  );

  /* Seed size. This element is directly equal to DcmDspSecuritySeedSize */
  uint32 ulSecuritySeedSize;

  /* Key size. This element is directly equal to DcmDspSecurityKeySize */
  uint32 ulSecurityKeySize;

  #if(DCM_DSP_SECURITY_ADR == STD_ON)
  /* This element is equal to DcmDspSecurityRow->DcmDspSecurityADRSize, if it
     is configured. If not, is shall be 0x0000000000000000 */
  uint32 ulSecurityADRSize;
  #endif

  /* This element is equal to ticks DcmDspSecurityDelayTimeOnBoot/DcmTaskTime */
  uint16 usSecurityDelayTimeOnBoot;

  /* This shall be an index to the relevant Dcm_GaaAttemptConfig[] */
  uint8 ucAttemptCounterIndex;

  /* If DcmDspSecurityADRSize is greater than 0, this parameter shall be
   the instance of Dcm_GaaGetSeedWithADR[] which corresponds to this
   DcmDspSecurityRow. If DcmDspSecurityADRSize is 0 or omitted, this
   parameter shall be the instance of Dcm_GaaGetSeedNoADR[] which
   corresponds to this DcmDspSecurityRow. */
   uint8 ucGetSeedFncIndex;

}Dcm_DspSecurityRow;

/* Design ID : DCM_SDD_6150 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspSecurityRow, DCM_CONST) Dcm_GaaSecurityRow[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/**
  Name: Dsp_GaaAttemptData
  Type:
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspSecurityRow
  Description: Variable to hold runtime details of Security Attempts for
  allocate SecurityRows. One element of Dsp_GaaAttemptData shall be
  allocated per session row. Note that this allocation should be in the
  same order as Dcm_GaaAttemptConfig i.e., the same ucAttemptCounterIndex
  will be used to access Dcm_GaaAttemptConfig[] and Dsp_GaaAttemptData[],
  and they must correspond.

  The initialization of this array shall be done by the tool. Initialization
  description is provided for each element.


**/
/*Design ID : DCM_SDD_5075*/
typedef struct STag_Dsp_AttemptData
{
  /* Storing for every SecurityAccessType, for which attempt timer is
  configured, the current number of failed access attempts

    Initialization: If for this SecurityRow, DcmDspSecurityAttemptCounterEnabled
    is true, the ucNoOfFailedAttempts shall be initialized as
    DCM_ATTEMPT_COUNTER_INIT_PENDING, else it shall be initialized as
    DCM_ZERO_U8*/
  uint8 ucNoOfFailedAttempts;
  /*
    ucAttemptDelayTimerStatus can have the following values:
     a. DCM_DSP_ATTEMPT_DELAY_TIMER_INACTIVE: The timer is not running currently
     b. DCM_DSP_START_ATTEMPT_DELAY_TIMER: Start the timer in the next main
     c. DCM_DSP_START_ATTEMPT_DELAY_ACTIVE: The timer is active currently

     Initialization: This shall always be initialized as
     DCM_DSP_ATTEMPT_DELAY_TIMER_INACTIVE
 */
  uint8 ucAttemptDelayTimerStatus;

  boolean AttemCountEnabled;

  /* This holds the time for attempt delay.

  Initialization: This shall always be initialized as DCM_ZERO_U16 */
  uint32 usAttemptDelayTimer;
}Dsp_AttemptData;

/* Example for generating Dsp_GaaAttemptData:
If two DcmDspSessionRow's are configured, SessionRow1, and SessionRow2. For
SessionRow1, DcmDspSecurityAttemptCounterEnabled is TRUE and for SessionRow2, it
is FALSE. Dsp_GaaAttemptData is generated as:

VAR(Dsp_AttemptData, DCM_VAR_INIT)
  Dsp_GaaAttemptData[] =
{
  For  SessionRow1
  {

    DCM_ATTEMPT_COUNTER_INIT_PENDING,
    DCM_ZERO_U16,
    DCM_DSP_ATTEMPT_DELAY_TIMER_INACTIVE
  },
  For SessionRow2
  {
    DCM_ZERO_U8,
    DCM_ZERO_U16,
    DCM_DSP_ATTEMPT_DELAY_TIMER_INACTIVE
  }
};
*/
/* Variable holding the boot delay time for security access */

/* Design ID : DCM_SDD_6157 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dsp_AttemptData, DCM_VAR_INIT) Dsp_GaaAttemptData[];
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif /* if DCM_DSP_SECURITY_ACCESS_SERVICE */

#if(DCM_DSP_COMM_CTRL_SERVICE == STD_ON)
/*Design ID : DCM_SDD_5077*/
typedef struct STag_Dcm_CommunicationControlinfo
{
  /* the subnetbyte is separated from Communication type */
  uint8 ucsubnetbyte;
  /* the sub-function of request*/
  uint8 ucsubfunction;

  /* this element give the type of message is requested
   0x01 -Normal Communication Message
   0x02 - Network management Message
   0x03 - Normal and Network Communication Messages */
  uint8 ucCommunicationMode;

  /*This element stores the subnet Result */
  uint8 ucComCtrlCount;

  /*The sub-node id current request is stored */
  uint16 ussubnodeid;

  /*This element stores the Sub node Id Count */
  uint16 usSubnodeCount;
}Dcm_CommunicationControlinfo;

/* this Static ram array which hold 0x28 service info*/
/* Design ID : DCM_SDD_6162 */
#define DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_CommunicationControlinfo, DCM_VAR_CLEARED)Dcm_GddComCtrlInfo;
#define DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"



#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
/*Design ID : DCM_SDD_5076*/
/*Design ID : DCM_SDD_5002*/
typedef struct STag_Dcm_DspCommControlspecificType
{
  /*This function Pointer should generate as
    &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
    should be fetched from DcmDspSpecificComMChannelRef */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchCommModeSpecFunc)
  (Dcm_CommunicationModeType CommunicationType);

   /* This shall be a duplicate of the parameter DcmDspSubnetNumber*/
   uint16 usSubNetNumber;

   /* This element should generate the channel id configured under
      DcmDspSpecificComMChannelRef */
   NetworkHandleType ucComCtrlSepcChaneel;
  #if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
   /*DcmDspComControlSpecificChannelUsed parameter(TRUE/FALSE) */
   boolean LblSpecChannelUsed ;
  #endif

}Dcm_DspCommControlspecificType;

#if(DCM_DSP_COMMCTRL_SPEC_CHANNEL > DCM_ZERO)
/* Design ID : DCM_SDD_6117 */


#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspCommControlspecificType, DCM_CONST)
           Dcm_GaaComCtrlConfig[DCM_DSP_COMMCTRL_SPEC_CHANNEL];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif


/*Design ID : DCM_SDD_5078*/
typedef struct STag_Dcm_DspComControlSubNode
{
  /*This function Pointer should generate as
  &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
  should be fetched from DcmDspComControlSubNodeComMChannelRef */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchSubnodeComMChaneelFunc)
  (Dcm_CommunicationModeType CommunicationType);

  /*This shall be a duplicate of the parameter DcmDspComControlSubNodeId */
  uint16 usDcmDspComCtrlSubNodeId;

  /* This element should generate the channel id configured under
      DcmDspComControlSubNodeComMChannelRef */
  NetworkHandleType ucComCtrlSubChaneel;

  #if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
  /*DcmDspComControlSpecificChannelUsed parameter(TRUE/FALSE) */
  boolean LblSubNodeUsed ;
  #endif

}Dcm_DspComControlSubNode;

#if(DCM_DSP_COM_CTRL_SUBNODE == STD_ON)
/* Design ID : DCM_SDD_6118 */
/* Design ID : DCM_SDD_6314 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspComControlSubNode, DCM_CONST)
       Dcm_GaaComCtrlSubNodeConfig[DCM_DSP_COMCTRL_SUBNODE];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"


#endif

/*Design ID : DCM_SDD_5079*/
typedef struct STag_Dcm_DspComCtrlAllChaneel
{
  /*This function Pointer should generate as
    &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
    should be fetched from DcmDspComControlAllChannel */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchAllChaneelFunc)
  (Dcm_CommunicationModeType CommunicationType);

   /*This element should generate the ComMchannel id configured under
      DcmDspComControlAllChannel  */
   NetworkHandleType ucAllComMChaneelId;

}Dcm_DspComCtrlAllChaneel;

#if(DCM_DSP_COM_CTRL_ALLCHANNEL > DCM_ZERO)
/* Design ID : DCM_SDD_6116 */
/* Design ID : DCM_SDD_6318 */

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspComCtrlAllChaneel, DCM_CONST)
       Dcm_GaaComCtrlAllChanConfig[DCM_DSP_COM_CTRL_ALLCHANNEL];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"


#endif
#endif
/**

  Name: Dcm_GaacommunicationType
  Type: uint8
  Configuration Dependencies: DcmDsdService->DcmDsdSidTabServiceId,
  DcmDsdSubService->DcmDsdSubServiceId
  Generation Description:This is common array for 0x28 service Across the Table
  Row: Fixed to four
  column:if the DcmDsdSidTabServiceId is configured as 0x28 the  maximum
  sub-function value plus one configured under DcmDsdSubServiceId should be
  generated.

**/
/**
Example:
In this array the first row is always DCM_INVALID_SID
Dcm_GaacommunicationType[DCM_FOUR][DCM_SIX] =
{ {DCM_INVALID_SID,DCM_INVALID_SID,DCM_INVALID_SID,DCM_INVALID_SID,
   DCM_INVALID_SID,DCM_INVALID_SID},

 {DCM_ENABLE_RX_TX_NORM, DCM_ENABLE_RX_DISABLE_TX_NORM,
   DCM_DISABLE_RX_ENABLE_TX_NORM, DCM_DISABLE_RX_TX_NORM,
   DCM_ENABLE_RX_DISABLE_TX_ENAHANCED_ADDR_INFO_NORM,
   DCM_ENABLE_RX_TX_ENAHANCED_ADDR_INFO_NORM},

 {DCM_ENABLE_RX_TX_NM, DCM_ENABLE_RX_DISABLE_TX_NM, DCM_DISABLE_RX_ENABLE_TX_NM,
  DCM_DISABLE_RX_TX_NM,DCM_ENABLE_RX_DISABLE_TX_ENAHANCED_ADDR_INFO_NM,
  DCM_ENABLE_RX_TX_ENAHANCED_ADDR_INFO_NM},

 {DCM_ENABLE_RX_TX_NORM_NM, DCM_ENABLE_RX_DISABLE_TX_NORM_NM,
 DCM_DISABLE_RX_ENABLE_TX_NORM_NM, DCM_DISABLE_RX_TX_NORM_NM,
 DCM_ENABLE_RX_DISABLE_TX_ENAHANCED_ADDR_INFO_NORM_NM,
 DCM_ENABLE_RX_TX_ENAHANCED_ADDR_INFO_NORM_NM},
}
**/

/*Design ID : DCM_SDD_6062*/
/*Design ID : DCM_SDD_0918*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_CommunicationModeType, DCM_CONST)
  Dcm_GaacommunicationType[DCM_FOUR][DCM_DSP_COMM_CTRL_SUBFUNCTIONS];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
/*Design ID : DCM_SDD_5080*/
typedef struct STag_Dcm_DspPerDIDStatus
{
 /* The timer value of that PDid */
  uint8 ucPDidTimerValue;

 /* Store the current PDid after every Scheduling */
  uint8 ucTimer;

 /* Status of the PDid
   DCM_DSP_PID_NO_REQUEST
   DCM_DSP_PDID_ACCEPTED
   DCM_DSP_PDID_TIMER_IN_PROGRESS
   DCM_DSP_PDID_TIMER_LODED
   */
  uint8 ucPDidStatus;
  uint8 ucDDIDStatus;

  /* If the ReadDataLength is configured
    that particular DID size has to stored */
  uint8 ucPDidReadDataLength;

  uint8 ucTransMode;

  /* Store the DID index */
  uint16 ucDidIndex;

  /* Default should have INVALID  else DID
      value should be stored*/
  uint16 DIDValue;
}Dcm_DspPerDIDStatus;

/* Design ID : DCM_SDD_6157 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspPerDIDStatus, DCM_VAR_NO_INIT)
  Dcm_GaaDspPerdDidStatus[DCM_DSP_PERIODIC_DIDS];
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6085 */
#define DCM_START_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"
extern VAR(uint16, DCM_VAR_NO_INIT)Dcm_GaaDspPerdIntBuf[DCM_DSP_PERIODIC_DIDS];
#define DCM_STOP_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"


/* Design ID : DCM_SDD_6084 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT)Dcm_GaaDspIntDidindex[DCM_DSP_PERIODIC_DIDS];
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"


/* Design ID : DCM_SDD_6086 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT)Dcm_GaaDspPerdLocBuf[DCM_DSP_PERIODIC_DIDS];
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6086 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean,DCM_VAR)
Dcm_GaaPeriodicConfirmStatus[DCM_DSP_PERIODIC_MAX_PDUIDS];
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR) Dcm_GucPeriodicRxpduId;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5081*/
typedef struct STag_Dcm_DspPerDatalen
{
/* condition for read data length */
 uint8 ucDIDind;

 /*the current  DID data length will be stored*/
 uint8 ucReadLenSize;

 uint8 ucNumDids;
 /*PDid Status:
   DCM_DSP_PID_NO_REQUEST
   DCM_DSP_PDID_RESPONSE_TRIGGERED
   DCM_DSP_PDID_ACCEP_TIMER_LODING
   DCM_DSP_PDID_RESPONSE_CONF
    */
 uint8 ucPDidStatus;

 /*PDid Status:
   DCM_DSP_MULTIPLE_PID_NO_REQUEST
   DCM_DSP_MILTIPLE_TRIGGERED
   DCM_DSP_Multipe_DID_ACCEPTED */
 uint8 ucRequSatus;

 uint8 ucTxPudis;

 /* This will be true if it is multiple request comes */
 boolean blMulRequest;

 P2CONST(Dcm_PerdTxPduIdTable, DCM_CONST, DCM_CONST)pTxPerPduIdTable;

}Dcm_DspPerData;

/* Design ID : DCM_SDD_6158 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_DspPerData, DCM_VAR_NO_INIT) Dcm_GstDspPerdReadData;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#if(DCM_DSP_IO_CONTROL == STD_ON)
/*Design ID : DCM_SDD_5082*/
typedef struct STag_Dcm_DspOpstatusIOCtrl
{
  /* This element for  status for Io control Callback */
  uint8 ucDcmDspIoOpStatus;
  /* This element for  status for Read data Callback */
  uint8 ucDcmDspReadOpStatus;
}Dcm_DspOpstatusIOCtrl;

#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
/* initialize the global variables with Default value */
extern VAR(Dcm_DspOpstatusIOCtrl, DCM_VAR_INIT) Dsp_GaaDspOpstatusIOCtrl;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5083*/
typedef struct STag_Dcm_DspSesTrnsIOCtrl
{
  /* This element for  status for DID */
  uint16  usDId;
  /* This element for  status for DID index*/
  uint16 usDidindex;
  /* status for DID */
  boolean ucDidStatus;
}Dcm_DspSesTrnsIOCtrl;

/* Design ID : DCM_SDD_6160 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
/* initialize the global variables with Default value */
extern VAR(Dcm_DspSesTrnsIOCtrl, DCM_VAR_NO_INIT)
Dcm_GaaDspSesTrnsIOCtrl[DCM_DSP_IOCRL_DIDS];
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/* Union for 16 bit CPU byte order */
/* Design ID : DCM_SDD_6298 */
typedef union
{
  struct
  {
      /*  If the processor is Big Endian */
      #if(CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
      uint8 MS_Byte;                 /* MS Byte */
      uint8 LS_Byte;                 /* LS Byte */
      /* If the processor is Little Endian */
      #else
      uint8 LS_Byte;                 /* LS Byte */
      uint8 MS_Byte;                 /* MS Byte */
      #endif
  }byte_val;
  uint16 whole_word;
}Dcm_MIWord_Access;

/* Union for 32 bit CPU byte order */
/* Design ID : DCM_SDD_6297 */
typedef union
{
  struct
  {
      /* If the processor is Big Endian */
      #if(CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
      uint8 MS_Byte;                 /* MS Byte */
      uint8 MS_Mid_Byte;             /* MS Mid Byte */
      uint8 LS_Mid_Byte;             /* LS Mid Byte */
      uint8 LS_Byte;                 /* LS Byte */
      /* If the processor is Little Endian */
      #else
      uint8 LS_Byte;                 /* LS Byte */
      uint8 LS_Mid_Byte;             /* LS Mid Byte */
      uint8 MS_Mid_Byte;             /* MS Mid Byte */
      uint8 MS_Byte;                 /* MS Byte */
      #endif
  }byte_val;
  struct
  {
      /* If the processor is Big Endian */
      #if(CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
      uint16 MS_Word;                /* MS Word */
      uint16 LS_Word;                /* LS Word */
      /* If the processor is Little Endian */
      #else
      uint16 LS_Word;                /* LS Word */
      uint16 MS_Word;                /* MS Word */
      #endif
  }word_val;
  uint32 whole_dword;
}Dcm_MIdWord_Access;

/* Union for 32 bit CPU byte order */
/* Design ID : DCM_SDD_6296 */
typedef union
{
  struct
  {
      /* If the processor is Big Endian */
      #if(CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
      uint8 *MS_Byte;                 /* MS Byte */
      uint8 *MS_Mid_Byte;             /* MS Mid Byte */
      uint8 *LS_Mid_Byte;             /* LS Mid Byte */
      uint8 *LS_Byte;                 /* LS Byte */
      /* If the processor is Little Endian */
      #else
      uint8 *LS_Byte;                 /* LS Byte */
      uint8 *LS_Mid_Byte;             /* LS Mid Byte */
      uint8 *MS_Mid_Byte;             /* MS Mid Byte */
      uint8 *MS_Byte;                 /* MS Byte */
      #endif
  }byte_val_ptr;
  struct
  {
      /* If the processor is Big Endian */
      #if(CPU_BYTE_ORDER == HIGH_BYTE_FIRST)
      uint16 *MS_Word;                /* MS Word */
      uint16 *LS_Word;                /* LS Word */
      /* If the processor is Little Endian */
      #else
      uint16 *LS_Word;                /* LS Word */
      uint16 *MS_Word;                /* MS Word */
      #endif
  }word_val_ptr;
  uint32 *whole_dword_ptr;
}Dcm_MIdWord_Access_ptr;


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ByteToWordConversion
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
);

extern FUNC(void, DCM_CODE) Dcm_ByteTo32BitWordConversion
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) pUsDataU32
);

extern FUNC(void, DCM_CODE)Dcm_DspConvUint8WithoutEnd
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8 ByteNo, uint8 *Dest
);

extern FUNC(void, DCM_CODE)Dcm_DspConvUint8
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8 ByteNo, uint8 *Dest
);

extern FUNC(void, DCM_CODE) Dcm_ByteTo16Conversion
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
);

extern FUNC(void, DCM_CODE) Dcm_TesterPresentByteConversion
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
);

extern FUNC(void, DCM_CODE) Dcm_ByteTo32BitWordConversionUnpack
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) pUsDataU32
);

extern FUNC(void, DCM_CODE) Dcm_ByteTo16ConversionUnpack
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pUsDataU8,
  P2VAR(uint16, AUTOMATIC, DCM_VAR) pUsDataU16
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif /* ifndef DCM_DSPINTERNALTYPES_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
