/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_OBDReadEmissionDTC.h                                      **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare services Request emission-related diagnostic       **
**              trouble codes($03, $07, $0A)                                  **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By          Description                    **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_OBDREADEMISSIONDTC_H
#define DCM_OBDREADEMISSIONDTC_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

/*******************************************************************************
**                      Macros                                                **
**                 Design ID : DCM_SDD_5132                                   **
*******************************************************************************/
/* Values of DTCStatusMask for $03,$07,$0A */
#define DCM_DEM_OBD_STATUS_CONFIRMED                    0x08u
#define DCM_DEM_OBD_STATUS_PENDING                      0x04u
#define DCM_DEM_OBD_STATUS_ALL                          0x00u

/* Second position of Dcm_GpOBDDTCFnsStatus holds the number of DTCs */
#define DCM_DTC_OBD_NUMBER_STORE_POS                0x01u

/* Third position of Dcm_GpOBDDTCFnsStatus holds the number of DTCs to
   be filled in response */
#define DCM_DTC_OBD_NUMBER_OF_DTC_RESPONSE_POS      0x02u

/* This is just a dummy value
 #define DCM_INVALID_U8                              0x00u*/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
typedef uint8 Dcm_OBDFetchDTCNumberRetType;

/*Design ID : DCM_SDD_0973*/
/*Design ID : DCM_SDD_5009*/
/*Design ID : DCM_SDD_5011*/
typedef struct STag_Dcm_OBDSetDTCFiltDTCInputs
{
  Dem_UdsStatusByteType DTCStatusMask;
  Dem_DTCKindType DTCKind;
  Dem_DTCFormatType DTCFormat;
  Dem_DTCOriginType DTCOrigin;
  boolean FilterWithSeverity;
  Dem_DTCSeverityType DTCSeverityMask;
  boolean FilterForFaultDetectionCounter;
}Dcm_OBDSetDTCFiltDTCInputs;

/*Design ID : DCM_SDD_6050*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/* constant pointer to Dcm_GaaOBDCommonRamArea were it has a position in
Dcm_GaaOBDCommonRamArea to indicate the word to use, since
Dcm_GaaOBDCommonRamArea is a shared variable*/
CONSTP2VAR(uint32, AUTOMATIC, DCM_CONST) Dcm_GpOBDDTCFnsStatus =
  &Dcm_GaaOBDCommonRamArea[DCM_ZERO];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6047*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaOBDSetDTCFiltDTCMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6058*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_OBDSetDTCFiltDTCInputs, DCM_CONST)
Dcm_GaaOBDSetDTCFiltDTCInputs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_OBDPackDTC
(
  uint32 DTC,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pResData
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_OBDFetchDTCList
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Dem_ReturnSetFilterType, DCM_CODE) Dcm_OBDSetVariousFilters
(
  P2CONST(Dcm_OBDSetDTCFiltDTCInputs, AUTOMATIC, DCM_CONST) LpOBDSetFilterInputs
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Dcm_OBDFetchDTCNumberRetType, DCM_CODE) Dcm_OBDFetchDTCNumberInfo
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_OBDDTCListInfo
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
