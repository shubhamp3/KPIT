/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DsdInternalTypes.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To declare internal datatypes for DSD                         **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated for QAC fix           **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSDINTERNALTYPES_H
#define DCM_DSDINTERNALTYPES_H
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_PBTypes.h"
#include "Dcm_InternalTypes.h"
/*******************************************************************************
**                      Macro Definitions                                     **
**                     Design ID: DCM_SDD_0904                                **
*******************************************************************************/
/*
    Possible return values of Dsd_TransmitNRC are:
     a. DCM_NRC_TRANSMISSION_SUPPRESSED: Transmission was skipped because of
        SWS_Dcm_00001
     b. E_OK: Transmission accepted, and to be performed
     c. E_NOT_OK: Transmission rejected, and to not be performed
*/
#define DCM_NRC_TRANSMISSION_SUPPRESSED 0x02u
/*
  Possible values of idContext are:
  1. DCM_DSD_RESPONSE_CONTEXT_POS_RESP: To indicate a positive response was sent
  2. DCM_DSD_RESPONSE_CONTEXT_NEG_RESP : To indicate a negative response was
  sent
  3. DCM_DSD_RESPONSE_CONTEXT_DSD_NRC: To indicate the request never was
  forwarded
     to DSP since a DSD NRC originated
  4. DCM_DSD_RESPONSE_CONTEXT_RP_RESP : To indicate a response pending (0x78)
  was sent
*/
#define DCM_DSD_RESPONSE_CONTEXT_POS_RESP 0x00u
#define DCM_DSD_RESPONSE_CONTEXT_NEG_RESP  0x01u
#define DCM_DSD_RESPONSE_CONTEXT_DSD_NRC 0x02u
#define DCM_DSD_RESPONSE_CONTEXT_RP_RESP  0x03u

/* Return NRC's within Dsd_RequestIndication from all the functions it calls */
#define DCM_NO_NRC (uint8)0x00

#define DCM_NO_NRC_REQUEST_NOT_ACCEPTED (uint8)0x01

/* Invalid SID value. It can be any value outside the request ID range. Choosing
   0xFF */
#define DCM_INVALID_SID (uint8)0xFF

/* Invalid sub function value */
#define DCM_INVALID_SUBSERVICE_ID (uint8)0xFF

#define DCM_INVALID_IO_DID 0xFFFFu


#define DCM_DSD_LOOK_UP_ROWS 0x03
#define DCM_DSD_LOOK_UP_COLUMNS 0x02
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/**
  Name: Dcm_GaaManufacturerNotification
  Type: Function Pointer Array
  Configuration Dependencies: DcmDsdServiceRequestManufacturerNotification
  Generation Description: This structure consists of function pointers for
  notification and indication pertaining to Manufacturer Notifications
  configured via DcmDsdServiceRequestManufacturerNotification.
**/
#if((DCM_DSP_DIAG_SESSION_BOOT_CONFIGURED == STD_ON)&& \
   (DCM_DSP_DIAG_SESSION_SERVICE == STD_ON))
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblRetrySetProgConditions;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
#endif

/*Design ID : DCM_SDD_6009*/
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GucServiceProcessingType;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_0931*/
/*Design ID : DCM_SDD_5008*/
/*Design ID : DCM_SDD_5034*/
typedef struct STag_Dcm_ManufacturerNotification
{
  /* This function pointer shall point to a function called Xxx_Indication where
  Xxx stands for the name of DcmDsdServiceRequestManufacturerNotification
  container. For example, if the container shortname is "Example", the function
  shall be called Example_Indication and the element shall be generated with
  the "&" operator as '&Example_Indication' */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pManufacturerIndication)
  (
    uint8 SID,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) RequestData,
    uint16 DataSize, uint8 ReqType, uint16 SourceAddress,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  /*Design ID : DCM_SDD_5036*/
  /* This function pointer shall point to a function called Xxx_Confirmation
  whereXxx stands for the name of DcmDsdServiceRequestManufacturerNotification
  container. For example, if the container shortname is "Example", the function
  shall be called Example_Confirmation and the element shall be generated with
  the "&" operator as '&Example_Confirmation' */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pManufacturerConfirmation)
  (
    uint8 SID,
    uint8 ReqType,
    uint16 SourceAddress,
    Dcm_ConfirmationStatusType ConfirmationStatus
  );
}Dcm_ManufacturerNotification;

/*Design ID : DCM_SDD_6016*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ManufacturerNotification, DCM_CONST)
Dcm_GaaManufacturerNotification[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/**
  Name: Dcm_GaaSupplierNotification
  Type: Function Pointer Array
  Configuration Dependencies: DcmDsdServiceRequestManufacturerNotification
  Generation Description: This structure consists of function pointers for
  notification and indication pertaining to Manufacturer Notifications
  configured via DcmDsdServiceRequestManufacturerNotification.
**/
/*Design ID : DCM_SDD_5065*/
typedef struct STag_Dcm_SupplierNotification
{
  /* This function pointer shall point to a function called Xxx_Indication where
  Xxx stands for the name of DcmDsdServiceRequestSupplierNotification
  container. For example, if the container shortname is "Example", the function
  shall be called Example_Indication and the element shall be generated with
  the "&" operator as '&Example_Indication' */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSupplierIndication)
  (
    uint8 SID,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) RequestData,
    uint16 DataSize, uint8 ReqType, uint16 SourceAddress,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) ErrorCode
  );

  /* This function pointer shall point to a function called Xxx_Confirmation
  where Xxx stands for the name of DcmDsdServiceRequestSupplierNotification
  container. For example, if the container shortname is "Example", the function
  shall be called Example_Confirmation and the element shall be generated with
  the "&" operator as '&Example_Confirmation' */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSupplierConfirmation)
  (
    uint8 SID,
    uint8 ReqType,
    uint16 SourceAddress,
    Dcm_ConfirmationStatusType ConfirmationStatus
  );
}Dcm_SupplierNotification;

/*Design ID : DCM_SDD_6018*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_SupplierNotification, DCM_CONST) Dcm_GaaSupplierNotification[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaDsdProcessingSwitch
  Type: uint8
  Configuration Dependencies: DcmDsdService->DcmDsdSidTabServiceId,
  DcmDsdServiceUsed Generation Description: This is  a function pointer array,
  pointing to various switches to DSP functions.This is arranged in the same
  order as the contents of Dcm_GaaServiceIDMapping. For example,
  if a service 0x68 has a Dcm_GaaServiceIDMapping equal to 0x11, then the
  17th element of Dcm_GaaDsdProcessingSwitch will contain to the correct
  function belonging to a service with SID 0x68.

  The names of the functions are as follows:
  TesterPresent: &Dcm_DspTesterPresentInd
  DiagnosticSessionControl: &Dcm_DspDiagSesCtrlInd
  Communication Control: &Dcm_DspCommunicationCtrlInd
  Security Access: &Dcm_DspSecurityAccessInd
  RDBI:&Dcm_DspReadDataByIDInd
  EcuReset:%Dcm_DspEcuResetInd
  ReadDTCInfo(0x19): &Dcm_DspReadDTCInfoInd
  ClearDTCInfo(0x14): &Dcm_DspClearDTCInfoInd
  CtrlDTCSetting(0x85): &Dcm_DspCtrlDTCsettingInd
  Note: This list shall be expanded as we implement more services.

**/
/*Design ID : DCM_SDD_5037*/
typedef P2FUNC(Std_ReturnType, DCM_CODE, pDsdProcessingSwitch)
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

/*Design ID : DCM_SDD_6004*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern  CONST(pDsdProcessingSwitch, DCM_CONST) Dcm_GaaDsdProcessingSwitch[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaDsdDiagServiceConf
  Type: uint8
  Configuration Dependencies: DcmDsdService->DcmDsdSidTabServiceId,
  DcmDsdServiceUsed Generation Description: This is  a function pointer array,
  pointing to various switches to DSP confirmation functions.This is arranged
  in the same order as the contents of Dcm_GaaServiceIDMapping. For example,
  if a service 0x68 has a Dcm_GaaServiceIDMapping equal to 0x11, then the  17th
  element of Dcm_GaaDsdDiagServiceConf will contain to the correct function.

  The names of the functions are as follows:
  TesterPresent: Dcm_DspTesterPresentConf
  DiagnosticSessionControl: Dcm_DspDiagSesCtrlConf
  Security Access: &Dcm_DspSecurityAccessConf
  RDBI:Dcm_DspReadDataByIDConf
  EcuReset:Dcm_DspEcuResetConf
  ReadDTCInfo(0x19): &Dcm_DspReadDTCInfoConf
  ClearDTCInfo(0x14): &Dcm_DspClearDTCInfoConf
  CtrlDTCSetting(0x85): &Dcm_DspCtrlDTCsettingConf
  Note: This list shall be expanded as we implement more services.

**/

typedef P2FUNC(void, DCM_CODE, pDsdDiagServiceConf)
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_ConfirmationStatusType ConfirmationStatus
);

/*Design ID : DCM_SDD_6001*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(pDsdDiagServiceConf, DCM_CONST) Dcm_GaaDsdDiagServiceConf[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

typedef P2FUNC(void, DCM_CODE, pDsdDiagServiceRPConf)
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType TransmissionResult
);

/**
  Name: Dcm_GaaDsdDiagServiceRPConf
  Type: pDsdDiagServiceRPConf
  Configuration Dependencies: DcmDsdService->DcmDsdSidTabServiceId,
  DcmDsdServiceUsed Generation Description: This is  a function pointer array,
  pointing to various switches to DSP confirmation functions.This is arranged
  in the same order as the contents of Dcm_GaaServiceIDMapping. For example,
  if a service 0x68 has a Dcm_GaaServiceIDMapping
  equal to 0x11, then the 17th element of Dcm_GaaDsdDiagServiceRPConf
  will contain to the correct function.

  The names of the functions are as follows:
  TesterPresent: Dcm_DspTesterPresentRPConf
  DiagnosticSessionControl: Dcm_DspDiagSesCtrlRPConf
  Security Access: &Dcm_DspSecurityAccessRPConf
  RDBI:Dcm_DspReadDataByIDRPConf
  EcuReset:Dcm_DspEcuResetRPConf
  ReadDTCInfo(0x19): &Dcm_DspReadDTCInfoRPConf
  ClearDTCInfo(0x14): &Dcm_DspClearDTCRPConf
  CtrlDTCSetting(0x85): &Dcm_DspCtrlDTCsettingRPConf
  Note: This list shall be expanded as we implement more services.

**/
/*Design ID : DCM_SDD_6002*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(pDsdDiagServiceRPConf, DCM_CONST) Dcm_GaaDsdDiagServiceRPConf[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

typedef P2FUNC(void, DCM_CODE, pDsdDiagServiceScheduled)
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

/**
  Name: Dcm_GaaDsdDiagServiceScheduled
  Type: pDsdDiagServiceScheduled
  Configuration Dependencies: DcmDsdService->DcmDsdSidTabServiceId,
  DcmDsdServiceUsed Generation Description: This is  a function pointer array,
  pointing to various switches to DSP main/scheduled functions.This is arranged
  in the same order as the contents
  of Dcm_GaaServiceIDMapping. For example, if a service 0x68 has a
  Dcm_GaaServiceIDMapping equal to 0x11, then the 17th element of
  Dcm_GaaDsdDiagServiceScheduled will contain the reference to the
  correct function.

  The names of the functions are as follows:
  TesterPresent: &Dcm_DspTesterPresentScheduled
  DiagnosticSessionControl: &Dcm_DspDiagSesCtrlScheduled
  Security Access: &Dcm_DspSecurityAccessScheduled
  RDBI:Dcm_DspReadDataByIDScheduled
  RDBI:Dcm_DspEcuResetScheduled
  ReadDTCInfo(0x19): &Dcm_DspReadDTCInfoRPScheduled
  ClearDTCInfo(0x14): &Dcm_DspClearDTCInfoScheduled
  CtrlDTCSetting(0x85): &Dcm_DspCtrlDTCsettingScheduled
  Note: This list shall be expanded as we implement more services.

**/
/*Design ID : DCM_SDD_6003*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(pDsdDiagServiceScheduled, DCM_CONST)
Dcm_GaaDsdDiagServiceScheduled[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/**
  The relationship between Dcm_GaaServiceIDMapping[] and
  Dcm_GaaSerTablSIDMapping[]. Dcm_GaaServiceIDMapping is a universal
  mapping array, while Dcm_GaaSerTablSIDMapping is specific to a
  certain ServiceTable. Using Dcm_GaaServiceIDMapping[] we collect all the
  DcmDsdSidTabServiceId in the module, delete all duplicates, and map them
  to the natural number range from 0 to n.

  For example, if DcmDsdSidTabServiceId values in all instances of DcmDsdService
  are: 0x01, 0x04, 0x11, Dcm_GaaServiceIDMapping[] shall be generated as:
  Dcm_GaaServiceIDMapping[0x11] =
  {
    DCM_INVALID_SID,

    0x00,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    0x01,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    DCM_INVALID_SID,

    0x02
  }

  Now suppose there are two service tables: DcmDsdServiceTable_0 and
  DcmDsdServiceTable_1.

  Suppose DcmDsdServiceTable_0 has DcmDsdSidTabServiceId's 0x01, 0x04.
  We have already mapped, using Dcm_GaaServiceIDMapping, 0x01 and 0x04 to values
  0x00, and 0x01.

  Suppose DcmDsdServiceTable_0 has DcmDsdSidTabServiceId's 0x01, 0x11.
  We have already mapped, using Dcm_GaaServiceIDMapping, 0x01 and 0x04 to values
  0x00, and 0x02.

  Within Dcm_GaaSerTablSIDMapping[], 2 elements shall be reserved for
  DcmDsdServiceTable_0, and 3 elements to DcmDsdServiceTable_1. There are 3
  elements for DcmDsdServiceTable_1 because there is a gap between 0x00 and 0x02

  Finally the array shall Dcm_GaaSerTablSIDMapping[] be:

  Dcm_GaaSerTablSIDMapping[] =
  {
    For DcmDsdServiceTable_0:

    0x00,

    0x01,

    For DcmDsdServiceTable_1:
    0x00,

    DCM_INVALID_SID,

    0x02
  }

  In Dcm_GaaServiceTable, the element pSerTablSIDMapping shall be
  &Dcm_GaaSerTablSIDMapping[0], and usNumOfSerTablMapping shall be 2.

  In Dcm_GaaServiceTable, the element pSerTablSIDMapping shall be
  &Dcm_GaaSerTablSIDMapping[2], and usNumOfSerTablMapping shall be 3.

**/
/**
  Name: Dcm_GaaServiceIDMapping
  Type: uint8
  Configuration Dependencies: DcmDsdSidTabServiceId
  Generation Description: See passage above
**/

/*Design ID : DCM_SDD_6006*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaServiceIDMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaSerTablSIDMapping
  Type: uint8
  Configuration Dependencies: DcmDsdSidTabServiceId
  Generation Description: See passage above
**/

/*Design ID : DCM_SDD_6005*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSerTablSIDMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaServiceTable
  Type: uint8
  Configuration Dependencies: DcmDslProtocolRow->DcmDslProtocolRowUsed,
  DcmDslProtocolRow->DcmDslProtocolSIDTable Generation Description:
  This structure is generated for every instance of DcmDsdServiceTable that is:
      a. Referred to by a DcmDslProtocol via DcmDslProtocolSIDTable
      b. The protocol has DcmDslProtocolRowUsed set to TRUE
**/



/*Design ID : DCM_SDD_6015*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DsdSubService, DCM_CONST) Dcm_GaaDsdSubService[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6014*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DsdService, DCM_CONST) Dcm_GaaDsdService[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6008*/
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GucProtocolSIDTableIndex;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_0934*/
typedef struct STag_Dcm_DsdServiceTable
{
  /* Pointer to the starting address of Dcm_GaaDsdService[] that is generated
     for the DcmDsdService containers configured in this instance of
     DcmDsdServiceTable */
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST) pDsdService;

  /*
    Pointer to the mapping array to map SID to references to
    Dcm_GaaDsdService[]. It points to Service mapping array:
    Dcm_GaaSerTablSIDMapping[].
  */
  P2CONST(uint8, AUTOMATIC, DCM_CONST) pSerTablSIDMapping;

  /* Number of elements of Dcm_GaaSerTablSIDMapping[] allocated to this
     service table */
  uint8 ucNumOfSerTablMapping;

}Dcm_DsdServiceTable;

/*Design ID : DCM_SDD_6017*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DsdServiceTable, DCM_CONST) Dcm_GaaServiceTable[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/**

  Name: Dcm_GaaSubServiceMapping
  Type: uint8
  Configuration Dependencies:
  DcmDsdService->DcmDsdSubService->DcmDsdSubServiceId,
  DcmDsdService->DcmDsdSubService->DcmDsdSubServiceUsed,

  Generation Description: Elements of thus array are generated
  for every instance of DcmDsdService that has sub-functions
  i.e., container(s) DcmDsdSubService configured
  An example is given with the element pSubServiceMapping.
  If for a DcmDsdSubService,DcmDsdSubServiceUsed is false,
  the corresponding element should be
  DCM_INVALID_SUBSERVICE_ID.

**/

/*Design ID : DCM_SDD_6195*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaSubServiceMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#endif
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
