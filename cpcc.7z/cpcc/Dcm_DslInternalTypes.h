/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DslInternalTypes.h                                        **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsl Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.1     19-Feb-2020   Sathyanarayana AH    Bug fix for 54661             **
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              As per CR #493                **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/* Design ID : DCM_SDD_0906                                                   **
** Design ID : DCM_SDD_5004                                                   **
** Design ID : DCM_SDD_6032                                                   **
*******************************************************************************/
#ifndef DCM_DSLINTERNALTYPES_H
#define DCM_DSLINTERNALTYPES_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_InternalTypes.h"
#include "Dcm_DslExternal.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
#define DCM_INVALID_RECEIVE_ID                     0xFFu
#define DCM_INVALID_TX_PDU_ID                      0xFFu
/* SID for Diagnostic session control */
#define DCM_DAIG_SESS_CTRL                  (uint8)0x10

/* Different statuses of Dcm_GaaProtocolInfo[].ucProtocolTxRxStatus */
#define DCM_PROTOCOL_ENGAGED 0x00u
#define DCM_PROTOCOL_DISENGAGED 0x01u
#define DCM_PROTOCOL_ENGAGED_RX_COMPLETE 0x02u

/* Possible return values of Dcm_DslProtocolPreempt() */
#define DCM_PROTOCOL_START 0x00u
#define DCM_PROTOCOL_STOP_START 0x01u
#define DCM_PROTOCOL_ARBITRATION_LOST 0x02u
/* Possible return values of Dcm_ProtocolStartActions() */
#define DCM_START_UNSUCCESSFUL 0x03u
#define DCM_STOP_UNSUCCESSFUL  0x04u
#define DCM_PROTOCOL_TP_NORESP  0x05u

/* This value is common to both Dcm_DslProtocolPreempt and
  Dcm_GstCurrentProtocolInfo.ucReqProcessingStatus */
#define DCM_PROTOCOL_IDLE_AND_AVAILABLE 0x04u
#define DCM_PROTOCOL_PREMPTED            0x07u
#define DCM_PROTOCOL_PREM_TIMER_RUN            0x08u
#define DCM_RP_START_P2SERVERTIME 0x02u
#define DCM_RESPONSE_E_PENDING 0x03u
#define DCM_RESPONSE_IN_PROGRESS 0x05u

/* Values of Dcm_GucS3ServerTimeStatus */
#define  DCM_S3SERVER_TIME_INACTIVE 0x00u
#define  DCM_START_S3SERVER_TIME 0x01u
#define  DCM_S3SERVER_TIME_ACTIVE 0x02u

#define DCM_TESTERPRESENT 0x3Eu
#define DCM_TESTERPRESENT_SUPPRESSED_RESP (uint16)0x3E80

#define DCM_PROTOCOL_NONE 0xFFu

#define DCM_INVALID_COMM_CHANNEL 0xFFu

/* Possible values of Dcm_GblActiveDiagnostic */
#define DCM_COMM_ACTIVE (boolean)0x01

/* Possible values of Dcm_GstCurrentProtocolInfo.ucTxType */
#define DCM_DSL_RP_PENDING 0x00u
#define DCM_DSD_RESPONSE 0x02u
#define DCM_DSL_APP_RP_PENDING 0x03u
#define DCM_ROE_RESPONSE 0x04u

#define DCM_P2_SERVER_TIMER 0x01
#define DCM_S3SERVER_TIMER 0x02
#define DCM_NR_SI 0x00
#define DCM_NR_FRCP 0x78u

/* Possible values for Dcm_GucNegativeResponse */
/* No NRC to be sent from main function */
#define DCM_NO_NEG_RES_MAIN          (uint8)0x00
/* NRC to be sent from main function */
#define DCM_NEG_RES_INPROGRESS_MAIN  (uint8)0x01
/* NRC 0x21 to be sent from main function */
#define DCM_SEC_DEC_INPROGRESS_MAIN  (uint8)0x02
/* NRC 0x21 and other NRC to be sent from main function */
#define DCM_TWO_NRC_INPROGRESS_MAIN  (uint8)0x03
/* NRC is sent from main function */
#define DCM_NEG_RES_PROCESSED_MAIN   (uint8)0x04

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*******************************************************************************
  RAM, not generated by tool
*******************************************************************************/
/* Design Decision: DcmDslProtocolRxPduId = DcmDslTxConfirmationPduId for
  convenience. Dcm_PduIdTable can be accessed using both RxPduId and TxConfId.
 */
/* Design ID : DCM_SDD_0935 */
/* Design ID :  DCM_SDD_5001 */
typedef struct STag_Dcm_ProtocolInfoType
{
    /* The number of bytes copied while transmitting or receiving for this
  protocol. Since transmission and reception are mutually exclusive occurrences,
  one element is enough to hold information about both */
  PduLengthType ddBytesCopied;

  /* There is no need to maintain anything else other than the
  MainConnectionId */
  PduIdType ucConnectionIndex;
  /* The status of the protocol. The various possible statuses are
     DCM_ENGAGED, DCM_DISENGAGED, DCM_EXTERNAL_PROCESS_BUSY */
  /* The following status is maintained for all protocols no matter what the
  active protocol is. So we needn't check the progress of the active protocol to
  accept or reject a Dcm_StartOfReception */
  uint8 ucProtocolTxRxStatus;
}Dcm_ProtocolInfoType;

/* This global variable contains runtime information about every protocol.
Hence, it shall be instantiated for every ProtocolRow configured. It shall be
accessible using  RxPduId and TxConfId since both shall be equal*/
/* Design ID :  DCM_SDD_5003 */
/* Design ID :  DCM_SDD_6033 */
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_ProtocolInfoType, DCM_VAR_NO_INIT) Dcm_GaaProtocolInfo
  [DCM_NUM_OF_PROTOCOLS];
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
 /* Design ID : DCM_SDD_0936 */
typedef struct STag_Dcm_CurrentProtocolInfo
{
  /* Variable holding the current transmission PDU info */
  PduInfoType stCurrentTxPduInfo;

  /* Store the active PDU Id here */
  PduIdType ddActiveRxPduId;

  /* The index of the current protocol */
  uint8 ucCurrentProtocolIndex;

  /* The priority of the current protocol */
  uint8 ucCurrentProtocolPrio;

  /* The index of the currently active connection */
  uint8 ucConnectionIndex;

  /* Id context i.e., the context of the activity esp. response */
  Dcm_IdContextType ddTxContext;

  /* Different values of ucReqProcessingStatus:
  b. DCM_PROTOCOL_PREEMPT_TIMER_ON: Pre-emption timer was on because protocol
  switch could not happen immediately
  c. DCM_RESPONSE_E_PENDING: Response is accepted and being processed
  d. DCM_RESPONSE_IN_PROGRESS: Response is in the process of being transmitted
  e. DCM_PROTOCOL_IDLE_AND_AVAILABLE: Nothing's happening but still active */
  /* DCM_PROTOCOL_IDLE_AND_AVAILABLE replaced by
  DCM_PROTOCOL_IDLE_AND_AVAILABLE */
  uint8 ucReqProcessingStatus;


  uint8 ucProPremStatus;
  /* Counter for 'Response Pending' i.e., 0x78. Maximum value is
     DcmDslDiagRespMaxNumRespPend. */
  uint8 ucRespPendingCounter;
  /*
    Possible values for ucTxType are:
      a. DCM_DSL_RP_PENDING: To indicate that this RP originated from DSL
      c. DCM_DSD_RESPONSE: To indicate that the response originated from DSD
         (or DSP but that is abstracted here anyway)
  */
  uint8 ucTxType;

  uint8 ucPendingTransmit;

  uint8 ucGenrConn;
  #if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
  uint8 ucPeriodicRequest;
  #endif
}Dcm_CurrentProtocolInfo;

/* This RAM structure holds the necessary information for the current
   protocol */
/* Design ID : DCM_SDD_6034 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_CurrentProtocolInfo, DCM_VAR_INIT) Dcm_GstCurrentProtocolInfo;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6030 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_SesCtrlType, DCM_VAR_INIT) Dcm_GddSecurityLevel;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6025 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblActiveDiagnostic;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6021 */
#define DCM_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_ComMModeType, DCM_VAR) Dcm_GaaComMMode[DCM_NUM_COMM_CHANNELS];
#define DCM_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
  ROM, generated by tool
*******************************************************************************/
/* Design ID : DCM_SDD_0937 */
/****************DSL SW-C Callbacks *******************************************/
#if (DCM_TOTAL_NUM_OF_CALLBACK_REQUEST > DCM_ZERO)
typedef struct STag_Dcm_CbkReqServices
{
  /* Pointer to the stop function, which shall be generated as Xxx_StartProtocol
     where Xxx is the name of the container DcmDslCallbackDCMRequestService.
     This shall also be declared as a required port in RTE configuration */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pStartProtocolFun)
  (Dcm_ProtocolType ProtocolID);

  /* Pointer to the stop function, which shall be generated as Xxx_StopProtocol
  where Xxx is the name of the container DcmDslCallbackDCMRequestService. This
  shall also be declared as a required port in RTE configuration */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pStopProtocolFun)
    (Dcm_ProtocolType ProtocolID);

}Dcm_CbkReqServices;

/* Design ID : DCM_SDD_6036 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_CbkReqServices, DCM_CONST) Dcm_GaaCbkReqServices[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
** Arrays of generic buffer configuration required for storing request and **
** response messages. These buffer Ids can be used as both Tx and Rx buffer Id**
*******************************************************************************/
/* This is the uint8 area that shall be pointed to by the SduDataPtr of
   Dcm_GaaBufferConfig. The size will be generated as per DcmDslBuffer
   configuration i.e., the size will be equal to
   SUM(DcmDslBuffer->DcmDslBufferSize) */
/* Design ID : DCM_SDD_6194 */
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT)Dcm_GaaBufferArea[];
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6035*/
/* Dcm_GaaBufferConfig: Size = Num of instances of DcmDslBuffer */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(PduInfoType, DCM_CONST) Dcm_GaaBufferConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_5066 */
typedef struct STagDcm_PerdTxPduIdTable
{
  /* The Pdu id of the conncetion */
  PduIdType ucTxPduId;
  PduIdType ucTxConfirmPduId;

}Dcm_PerdTxPduIdTable;

/* Design ID : DCM_SDD_6042 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_PerdTxPduIdTable, DCM_CONST) Dcm_GaaTxPerPduIdTable[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
** Structure for the Connection configuration                                 **
*******************************************************************************/
/**
  This structure lists the properties of a connection. It can be accessed by a
  RxPduId using a reference from Dcm_PduIdTable i.e., ucPduConnectionIndex
  This shall also contain a reference to periodicConnection and ROEConnection
**/
/* Design ID : DCM_SDD_0939 */
typedef struct STag_Dcm_ConnectionType
{

  /*Pointer to the Tx buffer as configured in DcmDslProtocolTxBufferRef. This is
  a reference to an array of type PduInfoType and name Dcm_GaaBufferConfig[]*/
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) pTxBufferArea;

  /*Pointer to the Rx buffer as configured in DcmDslProtocolRxBufferRef. This is
  a reference to an array of type PduInfoType and name Dcm_GaaBufferConfig[]*/
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) pRxBufferArea;
  /* Design ID : DCM_SDD_5035 */
  #if(DCM_DSP_COMM_CTRL_SERVICE == STD_ON)
  /*This function Pointer should generate as
  &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChannelID> ,the channel Id
  should be fetched from DcmDslProtocolComMChannelRef */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchDspComMChaneelFunc)
  (Dcm_CommunicationModeType CommunicationType);
  #endif

  #if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
  P2CONST(Dcm_PerdTxPduIdTable, AUTOMATIC, DCM_CONST) pTxPerPduIdTable;
  P2CONST(PduInfoType, AUTOMATIC, DCM_CONST)   pTxPeriodicBuffArea;
  uint16 ucPeriodicLength;
  #endif

  #if(DCM_DSL_TEST_SOURCE_ADDRESS == STD_ON)
  /* Source Address i.e., the address of the server as configured in
  DcmDslMainConnection->DcmDslProtocolRxTesterSourceAddr */
  uint16 usTesterSrcAddress;
  #endif

  /* The main Tx Pdu to be used for all responses as configured in
  DcmDslMainConnection-> DcmDslProtocolTx->DcmDslProtocolTxPduRef in ECU
  referred in PDUR's SrcId */
  PduIdType ddMainTxPduId;

  #if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
  /*

  The Tx PDU configured within DcmDslResponseOnEvent shall be used only if
  DcmDslProtocolTransType is TYPE1. If not, the Tx Pdu Id from "
  the same TxPduID as the ROE response is send to.� This is according
  SWS_Dcm_00927.

  If DcmDslProtocolTransType for this connection is TYPE1, ddROETxPduId
  should be generated the same as DcmDslMainConnection-> DcmDslProtocolTx->
  DcmDslProtocolTxPduRef. If DcmDslProtocolTransType is TYPE1,
  DcmDslResponseOnEvent->DcmDslRoeTxPduRef is mandatory and ddROETxPduId shall
  be fetched from  it.

  If DcmDslResponseOnEvent is not configured at all, this
  shall be DCM_INVALID_TX_PDU_ID */

  PduIdType ddROETxPduId;
  #endif

  #if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
  uint8 ucNoPduids;
  #endif

    /* The references the instance of Dcm_GaaProtocolConfig[] under which this
     connection  is configured i.e., the instance of DcmDslProtocolRow to which
     this instance of DcmDslConnection belongs */
  uint8 ucProtocolIndex;

  /* TBU: Both of these are properties of each protocol and needn't be repeated
     for each connection.
     This is done, however for easier access for now */

  /* DcmDslProtocolComMChannelRef */
  uint8 ddProtocolComMChannelRef;

}Dcm_ConnectionType;

/* Design ID : DCM_SDD_6037 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ConnectionType, DCM_CONST) Dcm_GaaConnection[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
  /* This is a reference to Dcm_ConnectionType i.e., Dcm_GaaConnection[] that
   this RxPduId is configured within
   The configuration link is as follows:
   DcmDslConnection ->DcmDslConnection->DcmDslProtocolRx->DcmDslProtocolRxPduId
   An instance of Dcm_GaaConnection is created for every DcmDslConnection and
   this structure shall provide a link to the relevant instance */
   /* Design ID : DCM_SDD_0938 */
typedef struct STag_Dcm_RxPduIdTable
{

  /* Connection type i.e., physical or functional. This is directly based on
     DcmDslProtocolRxAddrType configured within the relevant instance of
     DcmDslProtocolRx. If the configured value is DCM_FUNCTIONAL_TYPE,
     ddAddressType shall be DCM_FUNCTIONAL_TYPE and same for DCM_PHYSICAL_TYPE*/
  Dcm_DslAddressType ddAddressType;

    /* The main Rx Pdu to be used for all responses as configured in
  DcmDslMainConnection-> DcmDslProtocolTx->DcmDslProtocolTxPduRef in ECU
  referred in PDUR's SrcId */
  #if(DCM_NUM_OF_PROTOCOLS > DCM_ONE)
  PduIdType ddMainRxPduId;
  #endif

  #if (DCM_GENERIC_CONNCETION_HAND == STD_ON)
  boolean ublGenConn;
  #endif
  /* Index to the relevant instance of Dcm_GaaConnection[] */
  uint8 ucRxPduConnectionIndex;
} Dcm_RxPduIdTableType;

/* Design ID : DCM_SDD_6039 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RxPduIdTableType, DCM_CONST) Dcm_GaaRxPduIdTable[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/* This is a reference to Dcm_ConnectionType i.e., Dcm_GaaConnection[] that this
   TxConfId is configured within
   The configuration link is as follows:
   DcmDslConnection->DcmDslProtocolTx->DcmDslTxConfirmationPduId
   An instance of Dcm_GaaConnection is created for every DcmDslConnection and
   this structure shall provide a link to the relevant instance.

   ROE extension: All DcmDslResponseOnEvent->DcmDslRoeTxConfirmationPduId
   shall also be part of this array and shall point to their
   corresponding connections. */
   /* Design ID : DCM_SDD_0941 */
typedef struct STag_Dcm_TxConfIdTable
{
  /* Index to the relevant instance of Dcm_GaaConnection[] */
  uint8 ucTxConfConnectionIndex;
}Dcm_TxConfIdTableType;

/* Design ID : DCM_SDD_6040 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_TxConfIdTableType, DCM_CONST) Dcm_GaaTxConfIdTable[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/* This is a reference to Dcm_ConnectionType i.e., Dcm_GaaConnection[] that this
   ECU Tx Pdu Id is configured within
   The configuration link is as follows:
   DcmDslConnection->DcmDslConnection->DcmDslProtocolTx->DcmDslProtocolTxPduRef
   ->EcuC-> Same Pdu in PduR->PduRSourcePduHandleId
   An instance of Dcm_GaaConnection is created for every DcmDslConnection and
   this structure shall provide a link to the relevant instance */
/* Design ID : DCM_SDD_5067 */
typedef struct STag_Dcm_TxPduIdTable
{
  /* Index to the relevant instance of Dcm_GaaConnection[] */
  uint8 ucTxPduConnectionIndex;
}Dcm_TxPduIdTableType;

/* Design ID : DCM_SDD_6041 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_TxPduIdTableType, DCM_CONST) Dcm_GaaTxPduIdTable[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
/**
  Name: Dcm_GaaComMMapping
  Type: Mapping Array
  Configuration Dependencies: DcmDslMainConnection->DcmDslProtocolComMChannelRef
  Generation Description: This array maps DcmDslProtocolComMChannelRef values to
  a linear range i.e., if DcmDslProtocolComMChannelRef values are 6, 9, and 11.
  Dcm_GaaComMMapping shall be:
  {DCM_INVALID_COMM_CHANNEL, DCM_INVALID_COMM_CHANNEL, DCM_INVALID_COMM_CHANNEL,
  DCM_INVALID_COMM_CHANNEL, DCM_INVALID_COMM_CHANNEL, DCM_INVALID_COMM_CHANNEL,
  0, DCM_INVALID_COMM_CHANNEL, DCM_INVALID_COMM_CHANNEL,
  1, DCM_INVALID_COMM_CHANNEL, 1}
  The size of Dcm_GaaComMMapping shall be 12
**/

#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST) Dcm_GaaComMMapping[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

/* This is the status of the Se Server timer. The various values are:
DCM_S3SERVER_TIME_INACTIVE: The timer is not running
*/
/* This RAM variable holds the status of the S3 timer.
Possible values:
    Status for S3 Server timer. Possible values:
     a. DCM_S3SERVER_TIME_INACTIVE: the timer is not active i.e., not running
     b. DCM_START_S3SERVER_TIME: the timer is to be started in the next main
     function
     c. DCM_S3SERVER_TIME_ACTIVE: the timer is running and processed in the
     main */
/* Design ID : DCM_SDD_6029 */
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucS3ServerTimeStatus;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6028 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dcm_SesCtrlType, DCM_VAR_INIT) Dcm_GddCurrentSession;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6023 */
#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(PduIdType, DCM_VAR_INIT)Dcm_GddConcTpRxPduId;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(PduIdType, DCM_VAR_INIT)Dcm_GddRxPduId;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6023 */
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR) Dcm_GaaRespPendingBuf[DCM_THREE];
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR)  Dcm_GucNumPendingDids;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6024 */
#define DCM_START_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"
/* This array holds all the timers required by DSL */
extern VAR(uint16, DCM_VAR_NO_INIT) Dcm_GaaTimer[DCM_THREE];
#define DCM_STOP_SEC_VAR_NO_INIT_16
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6026 */
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblReqProcessingStatus;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

/* Design ID : DCM_SDD_6022 */
#if (DCM_GENERIC_CONNCETION_HAND == STD_ON)
#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR)DCM_GaaGenBuff[];
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
#endif

#if (DCM_DSL_RESP_ON_SECOND_DECLINED_REQUEST == STD_ON)

#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(PduIdType, DCM_VAR_INIT)Dcm_GddSecondDeclRxPduId;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucRepeatRequest;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucsecdeclConnectionIndex;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucsecdeclRepeatRequest[DCM_THREE];
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslRespPendConf(Std_ReturnType TpTxConfResult);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
