/*******************************************************************************
**                        KPIT Technologies Limited                           **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_Dsd.c                                                     **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : To Test Dsd                                                   **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/
/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.3.1     19-Feb-2020   Sathyanarayana AH    Bug fix for 54661             **
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              As per CR #493                **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.1     25-Jan-2019   Shriya Sasne         File name updated for Task    **
**                                              47140                         **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
/** Design ID : DCM_SDD_0287                                                  */
/** Design ID : DCM_SDD_0901                                                  */
/** Design ID : DCM_SDD_0902, DCM_SDD_0977                                    */
/** Design ID : DCM_SDD_0975, DCM_SDD_0976                                    */
/*******************************************************************************
**                   MISRA-C:2012 violations Section                          **
*******************************************************************************/
/**
* #page misra_violations MISRA-C:2012 violations
*
* #section Dcm_Dsd_c_REF_QAC_1
* Violates MISRA 2012 Advisory Rule 20.1. This statement has no side-effect.
* #include statements in a file should only be preceded by other
* preprocessor directives or comments.
*
* #section Dcm_Dsd_c_REF_QAC_2
* Violates MISRA 2012 Required Rule 2.2. This statement has no side-effect.
* All non-null statements shall either (i) have at least one side-effect
* however executed, or (ii) cause control flow to change.
*
* #section Dcm_Dsd_c_REF_QAC_3
* Violates MISRA 2012 Advisory Rule 18.4. This statement has no side-effect.
* An addition or subtraction operation is being performed on an expression of
* pointer type.
*
* #section Dcm_Dsd_c_REF_QAC_4
* Violates MISRA 2012 Advisory Rule 8.4. This statement has no side-effect.
* An object or function is being defined with external linkage but no previous
* declaration has been encountered.
*
* #section Dcm_Dsd_c_REF_QAC_5
* Violates MISRA 2012 Message Number 2211. This part of code has verified
* manually and has no side-effect.
* Variable is not aligned with the previously declared identifier.
*
* #section Dcm_Dsd_c_REF_QAC_6
* Violates MISRA 2012 Required Rule 3211,This statement has no side-effect.
* The global identifier is defined here but is not used in this translation
* unit.
*
* #section Dcm_Dsd_c_REF_QAC_7
* Violates MISRA 2012 Required Rule 11.3. This part of code has verified
* manually and has no side-effect. During unit testing boundary checks are
* performed to ensure to there is no invalid pointer access
*
* #section Dcm_Dsd_c_REF_QAC_8
* Violates MISRA 2012 Advisory Rule 11.5. This part of code has verified
* manually and has no side-effect. During unit testing boundary checks are
* performed to ensure to there is no invalid pointer access
*
* #section Dcm_Dsd_c_REF_QAC_9
* Violates MISRA 2012 Advisory Rule 19.2. We have analyzed the side effects
* of usage of union and found no issues.
*******************************************************************************/
/* PRQA S 5087 EOF */
/* PRQA S 0488 EOF */
/* PRQA S 3112 EOF */
/* PRQA S 3673 EOF */
/* PRQA S 0310 EOF */
/* PRQA S 0316 EOF */
/* PRQA S 0759 EOF */
/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm.h"
#include "Dcm_DsdInternalTypes.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DsdExternal.h"
#include "Dcm_DspUDSServices.h"
#include "SchM_Dcm.h"
#include "ComM_Dcm.h"
#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#include "Dcm_ROEConfig.h"
#endif
#if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
#include "Dcm_InternalRoutines.h"
#endif

/*******************************************************************************
**                      Version Information                                   **
*******************************************************************************/

/*******************************************************************************
**                      Version Check                                         **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
VAR(uint8, DCM_VAR_NO_INIT) Dcm_GucServiceProcessingType;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
VAR(uint8, DCM_VAR_NO_INIT) Dcm_GucProtocolSIDTableIndex;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
VAR(Dsd_MessageInfoType, DCM_VAR_NO_INIT) Dsd_GstMessageInfo;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
/*******************************************************************************
**                      Function Definitions                                  **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_DsdProcessSwitch                                **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Process DCM Request                                 **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : LpService                                           **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GucServiceProcessingType   **
**                                             Dcm_GaaServiceIDMapping        **
**                                             Dsd_GstMessageInfo             **
**                                             Dcm_GaaDsdProcessingSwitch     **
**                                             Dcm_GblResponsefromMainFunc    **
**                       Function(s) invoked: Dcm_ExternalServiceProcessingInd**
** Design ID             : DCM_SDD_7200                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
static FUNC(void, DCM_CODE) Dcm_DsdProcessSwitch(
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST)LpService
)
{
  VAR(uint8, DCM_VAR) LucGlobalServiceMappingId;
  LucGlobalServiceMappingId = Dcm_GaaServiceIDMapping[Dsd_GstMessageInfo.ucSID];

  /* If sub service is present (and validated), get the pointer to it */
  /* If there is a subfunction */
  /* Provide data to DSP switch */
  if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
  {
    (void) Dcm_GaaDsdProcessingSwitch[LucGlobalServiceMappingId]
      (DCM_INITIAL, &Dsd_GstMessageInfo.stMessageContext);
  }
  DCM_UNUSED(LpService);

}/* End of Function Dcm_DsdProcessSwitch */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_SessionValidation                               **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Performs Diag Session Validation                    **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : ServiceSesVector,NRC,ExpectedNRC                    **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :None                           **
**                                                                            **
**                        Function(s) invoked : Dcm_GetSesCtrlType            **
**                                                                            **
** Design ID             : DCM_SDD_7214                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dsd_SessionValidation(
  uint32 ServiceSesVector,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) NRC,
  Dcm_NegativeResponseCodeType ExpectedNRC
)
{

  VAR(Dcm_SesCtrlType, DCM_VAR) LddCurrentSession;
  VAR(uint32, DCM_VAR) LulBitMask;
  /* Get current session */
  (void)Dcm_GetSesCtrlType(&LddCurrentSession);
  /* Convert session to a bit mask */
  LulBitMask = (DCM_ONE_U32 << Dcm_GaaSessionMapping[LddCurrentSession]);
  if(DCM_ZERO == (ServiceSesVector & LulBitMask))
  {
    /* SWS_Dcm_00211: serviceNotSupportedInActiveSession transmission */
    *NRC = ExpectedNRC;
  }
}/* End of Function Dsd_SessionValidation */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_SubServiceValidation                            **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : Performs SubFunction Validation                     **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pService,SubFunctionId,NRC                          **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : DCM_GaaRuleFunc               **
**                                                                            **
**                        Function(s) invoked : Dsd_SessionValidation,        **
**                                              Dsd_SecurityValidation        **
**                                                                            **
** Design ID             : DCM_SDD_7216                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
static FUNC(void, DCM_CODE) Dsd_SubServiceValidation(
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST) pService,
  uint8 SubFunctionId,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) NRC
)
{
  P2CONST(Dcm_DsdSubService, DCM_CONST, DCM_CONST) LpSubFunction;

  VAR(Std_ReturnType, DCM_VAR) LddReturnValue;

  VAR(uint8, DCM_VAR) LucSubFnMapping;
  /* If SubFunctionId is lesser than the largest DcmDsdSubServiceId configured
     for this service */

  if(SubFunctionId < pService->ucNumSubServiceMapping)
  {
    /* Get the mapping ID */
    LucSubFnMapping = *(pService->pSubServiceMapping + SubFunctionId);
    /* If this is a valid sub-function parameter */
    if(DCM_INVALID_SUBSERVICE_ID != LucSubFnMapping)
    {
      LpSubFunction = pService->pSubService + LucSubFnMapping;

      {
        /* Check if the subservice can be processed in this session */
        Dsd_SessionValidation(LpSubFunction->ulSubServiceSesVector, NRC,
                  DCM_E_SUBFUNCTIONNOTSUPPORTEDINACTIVESESSION);
        /* */
        if((DCM_INVALID_U16 != LpSubFunction->ucSubServiceRuleindex)&&
            (DCM_NO_NRC == *NRC))
        {
          LddReturnValue =
          DCM_GaaRuleFunc[LpSubFunction->ucSubServiceRuleindex](NRC);
          /* Check for mode rule execution */
          if((E_NOT_OK == LddReturnValue) &&(DCM_NO_NRC == *NRC))
          {
            /* if the DcmModeRuleNrcValue is not configured
               always DCM_E_CONDITIONSNOTCORRECT needs to updated*/

            *NRC = DCM_E_CONDITIONSNOTCORRECT;
          }
        }

      }
    }
    else
    {
      *NRC = DCM_E_SUBFUNCTIONNOTSUPPORTED;
    }
  }
  else
  {
    *NRC = DCM_E_SUBFUNCTIONNOTSUPPORTED;
  }
}/* End of Function Dsd_SubServiceValidation */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_DspNewPageAvailable                             **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : This function gets called by DSP when it has a new  **
**                      : issue of the page ready                             **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pMsgContext                                         **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GucPagedBufferingStatus    **
**                                             Dsd_GstMessageInfo             **
**                                             Dcm_GulCurrentFrameSize        **
**                                             Dcm_GulCurrentSizeToCopy       **
**                        Function(s) invoked : Dcm_DslResponsePendingTransmit**
**                                              Dsd_SecurityValidation        **
**                                              Dsl_DsdTransmitMainConn       **
** Design ID             : DCM_SDD_7200                                       **
** Design ID             : DCM_SDD_7363                                       **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_DsdTriggerPosResp                               **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : To update the service and sub-function IDs.         **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : ProgConditions                                      **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dsd_GstMessageInfo            **
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
** Design ID             : DCM_SDD_7203                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_DsdTriggerPosResp(
P2CONST(Dcm_ProgConditionsType, AUTOMATIC, DCM_CONST)ProgConditions)
{
  /* Save the SID */
  Dsd_GstMessageInfo.ucSID = ProgConditions->Sid;
  /* Save the Sub-function ID */
  *(Dsd_GstMessageInfo.stMessageContext.reqData) =
    ProgConditions->SubFncId;
}/* End of Function Dcm_DsdTriggerPosResp */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_ServiceSubServiceValidation                     **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : To verify if the requested service and sub-function **
**                      : is valid (in Configured range).                     **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : LpService, RequestMessageContext, SID and LusNRC    **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :                               **
**                                                                            **
**                        Function(s) invoked : Dsd_SubServiceValidation      **
**                                                                            **
** Design ID             : DCM_SDD_7200                                       **
** Design ID             : DCM_SDD_7365                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
static FUNC(void, DCM_CODE)Dsd_ServiceSubServiceValidation(
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST)LpService,
  /* Reference to the current protocol SID Table */
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) RequestMessageContext,
  /* SID */
  uint8 SID,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) LusNRC
)
{
  VAR(uint8, DCM_VAR) LucSubFunction;
  /* If the sub-function is configured */
  if(NULL_PTR != LpService->pSubService)
  {
    /* Invalid message length check as per SWS_Dcm_00827 */
    if((RequestMessageContext->reqDataLen) >= DCM_ONE_U32)
    {
      /* Set the suppression bit as provided in the request */
      RequestMessageContext->msgAddInfo.suppressPosResponse =
        (boolean)(((*RequestMessageContext->reqData) &
        DCM_SUPPRESS_POS_RESP_MASK)>> DCM_SEVEN_U8);
      /* Suppress suppressPosResponse bit
      in the sub-function parameter in the request */

      (*RequestMessageContext->reqData) =
      (uint8)((*RequestMessageContext->reqData) &
      ((uint8)(~DCM_SUPPRESS_POS_RESP_MASK)));
      if(DCM_ROE_SID == SID)
      {
        /*Suppress StorageState ie, 6th bit of the request*/
        LucSubFunction = (*RequestMessageContext->reqData) &
          DCM_LOWER_SIX_BITS_MASKED;
      }
      else
      {
        LucSubFunction = *RequestMessageContext->reqData;
      }
      /* Fetch the pointer to the right sub-function */
      /* Validate the sub-function */
      Dsd_SubServiceValidation(LpService,
        LucSubFunction, LusNRC);
    }
    else
    {
      *LusNRC = DCM_E_INCORRECTMESSAGELENGTHORINVALIDFORMAT;
    }
  }
}/* End of Function Dsd_ServiceSubServiceValidation */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DsdScheduled                                    **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : If the OpStatus is pending, then in next main       **
**                      : function call, This API will be invoked.            **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dsd_GstMessageInfo,           **
**                                              Dcm_GaaServiceIDMapping,      **
**                                         Dcm_GaaDsdDiagServiceScheduled     **
**                                         Dcm_GucServiceProcessingType       **
**                                         Dcm_GaaDsdProcessingSwitch         **
**                                         Dcm_GblResponsefromMainFunc        **
**                                         Dcm_GstCurrentProtocolInfo         **
**                                         Dcm_GucPagedBufferingStatus        **
**                                                                            **
**                        Function(s) invoked :                               **
**                                          Dcm_ExternalServiceProcessingInd  **
**                                                                            **
** Design ID             : DCM_SDD_7202                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_DsdScheduled(void)
{
  VAR(uint8, DCM_VAR) LucGlobalServiceMappingId;
  LucGlobalServiceMappingId = DCM_INVALID_SID;
  /* Read details of the currently active message */
  if((DCM_INVALID_SID != Dsd_GstMessageInfo.ucSID)&&
     (DCM_SCHEDULED_IN_PROGRESS == Dsd_GstMessageInfo.ucProcessPendingReq))
  {
    /* Call the relevant DSP main function */
    if(Dsd_GstMessageInfo.ucSID < DCM_DSD_MAX_SID_CONFIGURED)
    {
      LucGlobalServiceMappingId =
        Dcm_GaaServiceIDMapping[Dsd_GstMessageInfo.ucSID];
    }
    {
      if((((DCM_RP_START_P2SERVERTIME ==
                Dcm_GstCurrentProtocolInfo.ucReqProcessingStatus))
        ||((DCM_RESPONSE_E_PENDING ==
                Dcm_GstCurrentProtocolInfo.ucReqProcessingStatus)))
        )
      {
        if(DCM_NO_NRC_PENDING == Dcm_GstCurrentProtocolInfo.ucPendingTransmit)
        {
          /* When response is page buffered, the sub-function can get lost */
          if(DCM_INVALID_SID != LucGlobalServiceMappingId)
          {
            if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
            {
              Dcm_GaaDsdDiagServiceScheduled[LucGlobalServiceMappingId]
                (&Dsd_GstMessageInfo.stMessageContext,
                  Dsd_GstMessageInfo.ddOpstatus);
            }
          }
        }
      }
    }
  }
}/* End of Function Dcm_DsdScheduled */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DsdResponsePendingTransmit                      **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API Transmit response pending by calling the DSL    **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dsd_GstMessageInfo            **
**                                                                            **
**                        Function(s) invoked : Dcm_DslResponsePendingTransmit**
**                                                                            **
** Design ID             : DCM_SDD_7201                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_DsdResponsePendingTransmit(void)
{
  /* Get MessageInfo */
  SchM_Enter_Dcm_DsdMsgContextProtect();
  Dsd_GstMessageInfo.stMessageContext.idContext
    = DCM_DSD_RESPONSE_CONTEXT_RP_RESP ;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  /* Transmit response pending by calling the DSL function that does it */
  Dcm_DslResponsePendingTransmit(DCM_DSD_RESPONSE);
  Dcm_DslP2TimerReset();

  Dcm_GblDiagBootJump = DCM_TRUE;
}/* End of Function Dcm_DsdResponsePendingTransmit */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DsdAppResponsePendingTransmit                   **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API Transmit response pending by calling the DSL    **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dsd_GstMessageInfo            **
**                                                                            **
**                        Function(s) invoked : Dcm_DslResponsePendingTransmit**
**                                                                            **
** Design ID             : DCM_SDD_7200                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_DsdAppResponsePendingTransmit(void)
{
  /* Get MessageInfo */
  SchM_Enter_Dcm_DsdMsgContextProtect();
  Dsd_GstMessageInfo.stMessageContext.idContext
    = DCM_DSD_RESPONSE_CONTEXT_RP_RESP ;
  Dsd_GstMessageInfo.ddOpstatus = DCM_FORCE_RCRRP_OK;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  /* Transmit response pending by calling the DSL function that does it */
  Dcm_DslResponsePendingTransmit(DCM_DSL_APP_RP_PENDING);
}/* End of Function Dcm_DsdAppResponsePendingTransmit */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_CloseRequest                                    **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : This function closes the request from Dsd's         **
**                      : perspective. This is to let the main function know  **
**                      : that Dsd has no scheduled functions.                **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : None                                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dsd_GstMessageInfo            **
**                                              Dcm_GucPagedBufferingStatus   **
**                                                                            **
**                        Function(s) invoked : Dsl_CloseRequest              **
**                                                                            **
** Design ID             : DCM_SDD_7209                                       **
** Design ID             : DCM_SDD_4902                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/* This function closes the request from Dsd's perspective. This is to let
   the mainfunction know that Dsd has no scheduled functions */
FUNC(void, DCM_CODE) Dsd_CloseRequest(void)
{
  SchM_Enter_Dcm_DsdMsgContextProtect();
  Dsd_GstMessageInfo.ucSID = DCM_INVALID_SID;
  /*If a Pending action finished in the Mainfunction*
    * then reset the Opstatus value to Dcm_Pending*/

  Dsd_GstMessageInfo.ddOpstatus= DCM_PENDING;
  Dsd_GstMessageInfo.stMessageContext.msgAddInfo.suppressPosResponse= DCM_FALSE;
  Dsd_GstMessageInfo.ucProcessPendingReq = DCM_SCHEDULED_IN_PROGRESS;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  Dsl_CloseRequest();
}/* End of Function Dsd_CloseRequest */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DslSupplierConfirmation                         **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to indicate supplier that environmental         **
**                        conditions are satisfied                            **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : SID,ReqType,SourceAddress,ConfirmationStatus        **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  : Dcm_GaaSupplierNotification   **
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
** Design ID             : DCM_SDD_7206                                       **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_DslManufacturerConfirmation                     **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to indicate Manufacturer that environmental     **
**                        conditions are satisfied                            **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : SID,ReqType,SourceAddress,ConfirmationStatus        **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GaaManufacturerNotification**
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
** Design ID             : DCM_SDD_7204                                       **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dcm_DslManufacturerNotification                     **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to call all the configured manufacturer         **
**                        notifications                                       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : SID,RequestData,DataSize,                           **
**                            ReqType,SourceAddress,NRC                       **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GaaManufacturerNotification**
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
** Design ID             : DCM_SDD_7205                                       **
*******************************************************************************/
/* This function calls all the configured manufacturer notifications as
   specified in ISO14229 and are configured with DCM configuration.*/
/*******************************************************************************
** Function Name        : Dcm_DslSupplierNotification                         **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to call all the configured Supplier             **
**                        notifications                                       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : SID,RequestData,DataSize,                           **
**                            ReqType,SourceAddress,NRC                       **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GaaSupplierNotification    **
**                                                                            **
**                        Function(s) invoked : None                          **
**                                                                            **
** Design ID             : DCM_SDD_7207                                       **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dsd_SecurityValidation                              **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to validate Security of requested service       **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : ServiceSesVector,NRC                                **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :None                           **
**                                                                            **
**                        Function(s) invoked : Dcm_GetSecurityLevel          **
**                                                                            **
** Design ID             : DCM_SDD_7212                                       **
*******************************************************************************/
/*******************************************************************************
** Function Name        : Dsd_ServiceValidation                               **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to validate requested service                   **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : Service,ProtocolSIDTableIndex,NRC                   **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :DCM_GaaRuleFunc                **
**                                                                            **
**                        Function(s) invoked : Dsd_SessionValidation         **
**                                              Dsd_SecurityValidation        **
**                                                                            **
** Design ID             : DCM_SDD_7213                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/* SWS_Dcm_00196: This function checks if input service is allowed by
  the current protocol and SID table */
static FUNC(void, DCM_CODE) Dsd_ServiceValidation(
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST) Service,
  uint8 ProtocolSIDTableIndex,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) NRC
)
{

  VAR(Std_ReturnType, DCM_VAR) LddReturnValue;

  /* The next validation is session validation as per SWS_Dcm_00827 */
  Dsd_SessionValidation(Service->ulServiceSesVector, NRC,
    DCM_E_SERVICENOTSUPPORTEDINACTIVESESSION);
  /* */
  if((DCM_INVALID_U16 != Service->ucServiceRuleindex) &&
      (DCM_NO_NRC == *NRC))
  {
    LddReturnValue =
    DCM_GaaRuleFunc[Service->ucServiceRuleindex](NRC);
    /* Check for mode rule execution */
    if((E_NOT_OK == LddReturnValue) &&(DCM_NO_NRC == *NRC))
    {
      /* if the DcmModeRuleNrcValue is not configured
         always DCM_E_CONDITIONSNOTCORRECT needs to updated*/

      *NRC = DCM_E_CONDITIONSNOTCORRECT;
    }
  }

  DCM_UNUSED(ProtocolSIDTableIndex);
}/* End of Function Dsd_ServiceValidation */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_TransmitNRC                                     **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to transmit NRC to DSL submodule                **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pMsgContext,NRC                                     **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : uint8                                               **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dsd_GstMessageInfo             **
**                                             Dcm_GaaRxPduIdTable            **
**                                             Dcm_GaaConnection              **
**                                             Dcm_GulCurrentSizeToCopy       **
**                                                                            **
**                        Function(s) invoked : Dsl_DsdTransmitMainConn       **
**                                              ComM_DCM_InactiveDiagnostic   **
** Design ID             : DCM_SDD_7200                                       **
** Design ID             : DCM_SDD_7217                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/*
    Possible return values of Dsd_TransmitNRC are:
     a. DCM_NRC_TRANSMISSION_SUPPRESSED: Transmission was skipped because of
        SWS_Dcm_00001
     b. E_OK: Transmission accepted, and to be performed
     c. E_NOT_OK: Transmission rejected, and to not be performed
*/
static FUNC(uint8, DCM_CODE) Dsd_TransmitNRC(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_NegativeResponseCodeType NRC
)
{
  P2CONST(Dcm_RxPduIdTableType, AUTOMATIC, DCM_CONST)LpRxPduTable;
  P2CONST(Dcm_ConnectionType, AUTOMATIC, DCM_CONST)LpConnection;
  VAR(Dsd_MessageInfoType, DCM_VAR) LddMessageInfo;
  VAR(uint8, DCM_VAR) LucNRCTransmitStatus;
  /* Read details of the currently active message */
  SchM_Enter_Dcm_DsdMsgContextProtect();
  LddMessageInfo = Dsd_GstMessageInfo;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  LucNRCTransmitStatus = DCM_ZERO;
   /*
    SWS_Dcm_00001:
    Attempt NRC transmission by calling Dsd_TransmitNRC which processes NRC's.
    It suppresses for functional addressing the  following Negative Responses:
    NRC 0x11 (Service not supported),
    NRC 0x12 (SubFunction not supported),
    NRC 0x31 (Request out of range),
    NRC 0x7E (Subfunction not supported in active session),
    NRC 0x7F (Service not supported in active session)
  */
  if((DCM_FUNCTIONAL_ADDRESSING == pMsgContext->msgAddInfo.reqType))
  {
    /* Check if the NRC is one among the 5 to be suppressed */
    if((DCM_E_SERVICENOTSUPPORTED == NRC)||
      (DCM_E_SUBFUNCTIONNOTSUPPORTED == NRC) ||
      (DCM_E_REQUESTOUTOFRANGE == NRC)||
      (DCM_E_SUBFUNCTIONNOTSUPPORTEDINACTIVESESSION == NRC) ||
      (DCM_E_SERVICENOTSUPPORTEDINACTIVESESSION == NRC))
    {
      LucNRCTransmitStatus = DCM_NRC_TRANSMISSION_SUPPRESSED;
      LpRxPduTable =
             &Dcm_GaaRxPduIdTable[LddMessageInfo.stMessageContext.dcmRxPduId];
      LpConnection = &Dcm_GaaConnection[LpRxPduTable->ucRxPduConnectionIndex];
      (void)ComM_DCM_InactiveDiagnostic(LpConnection->ddProtocolComMChannelRef);
    }
  }
  if(DCM_NRC_TRANSMISSION_SUPPRESSED != LucNRCTransmitStatus)
  {
    /* Assemble the negative response */
    /* Add SID to the response data. DCM_NR_SI = 0x7F */
    *(pMsgContext->resData - DCM_ONE_U8) = DCM_NR_SID;
    *pMsgContext->resData = LddMessageInfo.ucSID;
    /* Set the negative response */
    *(pMsgContext->resData + DCM_ONE_U8) = NRC;
    /* Set the NRC length */
    pMsgContext->resDataLen = DCM_NR_LENGTH;
    /* Dsl_DsdTransmitMainConn returns E_OK, E_NOT_OK. So,
       LucNRCTransmitStatus can be DCM_NRC_TRANSMISSION_SUPPRESSED, E_OK,
       E_NOT_OK.
    */



    LucNRCTransmitStatus = Dsl_DsdTransmitMainConn
      (pMsgContext->resData - DCM_ONE_U8,
      (uint16)pMsgContext->resDataLen);
  }
  return(LucNRCTransmitStatus);
}/* End of Function Dsd_TransmitNRC */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_RequestIndication                               **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to validate and forward the request to DSP      **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : RequestMessageContext,ProtocolSIDTableIndex,        **
**                          SID,SourceAddress                                 **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GaaServiceTable,           **
**                                             Dsd_GstMessageInfo,            **
**                                             Dcm_GaaServiceIDMapping,       **
**                                             Dcm_GucServiceProcessingType,  **
**                                             Dcm_GucProtocolSIDTableIndex,  **
**                                             Dcm_GddResponseMainFunction,   **
**                                             Dcm_GstCurrentProtocolInfo     **
**                       Function(s) invoked : Dcm_DslManufacturerNotification**
**                                             Dsd_ServiceValidation,         **
**                                             Dcm_DslSupplierNotification,   **
**                                             Dsd_SubServiceValidation,      **
**                                             Dsl_CloseRequest,              **
**                                             Dsd_TransmitNRC,               **
**                                             Dsd_ServiceSubServiceValidation**
**                                             Dcm_DsdProcessSwitch,          **
**                                             Dsd_CloseRequest               **
** Design ID             : DCM_SDD_7210                                       **
*******************************************************************************/
/* SWS_Dcm_00178: The DSD submodule shall only process valid requests and
   shall reject invalid ones */
/* SWS_Dcm_00827: The order of validation in DSD is based on IS) 14229 i.e.,
   1. Server busy - NRC 0x21 (handled by DSL)
   All the following belong to DSD
   2. Manufacturer or supplier specified failure
   - specified by the manufacturers
   3. SID supported - DCM_E_SERVICENOTSUPPORTED
   4. SID supported in the current session
      DCM_E_SERVICENOTSUPPORTEDINACTIVESESSION
   5. SID supported in the current security level - DCM_E_SECURITYACCESSDENIED
   6. Supplier specific failures - NRC provided
   7. Minimum length check -
   8. Subfunction supported - DCM_E_SUBFUNCTIONNOTSUPPORTED
   9. Subfunction supported in the current session
   - DCM_E_SUBFUNCTIONNOTSUPPORTEDINACTIVESESSION
   10. Subfunction supported in the current security level
   - DCM_E_SECURITYACCESSDENIED
   11. Other manufacturer specific checks - specified by the manufacturers
 */
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dsd_RequestIndication(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) RequestMessageContext,
  /* Reference to the current protocol SID Table */
  uint8 ProtocolSIDTableIndex,
  /* SID */
  uint8 SID
)

{
  P2CONST(Dcm_DsdServiceTable, AUTOMATIC, DCM_CONST)LpServiceTable;
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST)LpService;
  VAR(Dcm_NegativeResponseCodeType, DCM_VAR) LddNRC;
  VAR(uint8, DCM_VAR) LucGlobalServiceMappingId;
  VAR(uint8, DCM_VAR) LucServiceMappingId;
  VAR(uint8, DCM_VAR) LucNRCTransmitStatus;

  VAR(boolean, DCM_VAR) LblServiceSupportedFlag;
  LblServiceSupportedFlag = DCM_FALSE;
  LddNRC = DCM_NO_NRC;
  Dcm_GucServiceProcessingType = DCM_INTERNAL_PROCESSING;
  Dcm_GucProtocolSIDTableIndex = ProtocolSIDTableIndex;
  LpServiceTable = &Dcm_GaaServiceTable[ProtocolSIDTableIndex];
  LpService = LpServiceTable->pDsdService;
  /* Get the SID */
  /* Set the RequestData to start after the SID */
  RequestMessageContext->reqData += DCM_ONE_U8;
  RequestMessageContext->reqDataLen -= DCM_ONE_U8;
  /* Initializing this for situations where there is no subfunction */
  RequestMessageContext->msgAddInfo.suppressPosResponse = DCM_FALSE;
  /* Manufacturer specific checks */
  {
    /* Check if SID is configured */
    if(DCM_DSD_MAX_SERVICE_ID > SID)
    {
      /* Get the universal service mapping ID */
      LucGlobalServiceMappingId = Dcm_GaaServiceIDMapping[SID];
      /* Check if the SID exists in any SID table or not */
      if((DCM_INVALID_SID != LucGlobalServiceMappingId) &&
        (LucGlobalServiceMappingId < LpServiceTable->ucNumOfSerTablMapping))
      {
        /* Get the final mapping ID */
        LucServiceMappingId =
          *((LpServiceTable->pSerTablSIDMapping) + LucGlobalServiceMappingId);
        /* SWS_Dcm_00192, SWS_Dcm_00193: If the ID is valid at
        all or not configured within this service table */

        if(DCM_INVALID_SID != LucServiceMappingId)
        {
          /* Get the pointer to current Service */
          LpService = LpServiceTable->pDsdService + LucServiceMappingId;
          Dsd_ServiceValidation(LpService, ProtocolSIDTableIndex, &LddNRC);
          if(DCM_NO_NRC == LddNRC)
          {
            /* Supplier specific checks */
            {
              Dsd_ServiceSubServiceValidation(LpService,
                                             RequestMessageContext,
                                             SID,&LddNRC);
            }
          }
          LblServiceSupportedFlag = DCM_TRUE;
        }
      }
    }
    if(DCM_FALSE == LblServiceSupportedFlag)
    {
        LddNRC = DCM_E_SERVICENOTSUPPORTED;
    }
  }
  /* Copy the Message Context. This is the variable that remains for further
     processing of this request */

  Dsd_GstMessageInfo.stMessageContext = *RequestMessageContext;
  /* Set the SID parameter. This is required for processing in scheduled
     processing. */

  Dsd_GstMessageInfo.ucSID = SID;
  if(DCM_NO_NRC == LddNRC)
  {
    /* Call to Process switch where in it checks for whether the service or the
    sub function is externally processed or internally. Corresponding service
    indication functions are invoked there after.
    */



    Dcm_DsdProcessSwitch(LpService);
  }
  else if(DCM_NO_NRC_REQUEST_NOT_ACCEPTED == LddNRC)
  {
    /* What to pass. Void should be enough. There is nothing else required */
    /* Reset Dsd_GstMessageInfo to indicate that no request is in progress */
    Dsd_CloseRequest();
  }
  else
  {

    if (!(((SID > DCM_0x40_U8) && (SID < DCM_0x7F_U8)) ||
        ((SID > DCM_0xC0_U8) && (SID < DCM_0xFF_U8))))

    {
      /* Set the context to indicate that an NRC has been logged. */
      Dsd_GstMessageInfo.stMessageContext.idContext =
        DCM_DSD_RESPONSE_CONTEXT_DSD_NRC;
     /* E_OK: NRC is being transmitted, E_NOT_OK: NRC is not being
        transmitted. */


      LucNRCTransmitStatus = Dsd_TransmitNRC
        (&Dsd_GstMessageInfo.stMessageContext,
         LddNRC);
      if(E_OK != LucNRCTransmitStatus)
      {
        /* Reset Dsd_GstMessageInfo to indicate that no request is in
           progress. Dsd_CloseRequest calls Dsl_CloseRequest inturn and resets
           the necessary Dsl parameters. */


        Dsd_CloseRequest();
      }
    }

    else
    {
      /*Close the request if no response has been sent[SWS_Dcm_00084]*/
      Dsd_CloseRequest();
    }

  }
}/* End of Function Dsd_RequestIndication */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dsd_ResponseConfirmation                            **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to passes on the confirmation to the processor, **
**                        external or internal                                **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : TransmissionResult                                  **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dcm_GddCurrentSession          **
**                                             Dsd_GstMessageInfo,            **
**                                             Dcm_GaaServiceIDMapping,       **
**                                             Dcm_GaaRxPduIdTable,           **
**                                             Dcm_GaaConnection,             **
**                                             Dcm_GucServiceProcessingType,  **
**                                             Dcm_GaaDsdDiagServiceConf,     **
**                                             Dcm_GstCurrentProtocolInfo,    **
**                                             Dcm_GaaDsdDiagServiceRPConf    **
**                       Function(s) invoked : ComM_DCM_InactiveDiagnostic,   **
**                                             Dcm_DslManufacturerConfirmation**
**                                             Dcm_DslSupplierConfirmation,   **
**                                             Dsd_CloseRequest               **
** Design ID             : DCM_SDD_7211                                       **
** Design ID             : DCM_SDD_6000                                       **
*******************************************************************************/
/* This function passes on the confirmation to the processor, external or
   internal */
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dsd_ResponseConfirmation(
  Std_ReturnType TransmissionResult
)
{
  P2CONST(Dcm_RxPduIdTableType, AUTOMATIC, DCM_CONST)LpRxPduTable;
  P2CONST(Dcm_ConnectionType, AUTOMATIC, DCM_CONST)LpConnection;
  VAR(Dsd_MessageInfoType, DCM_VAR) LddMessageInfo;
  VAR(Dcm_ConfirmationStatusType, DCM_VAR) LddStatus;
  VAR(Dcm_IdContextType, DCM_VAR) LddIdContext;
  VAR(uint8, DCM_VAR) LucGlobalSIDMapping;
  static CONST(Dcm_ConfirmationStatusType, DCM_CONST) LaaConfStatusLookUp
  [DCM_DSD_LOOK_UP_ROWS][DCM_DSD_LOOK_UP_COLUMNS] =
  {
    /* For DCM_DSD_RESPONSE_CONTEXT_POS_RESP */
    {DCM_RES_POS_OK, DCM_RES_POS_NOT_OK},
    /* For DCM_DSD_RESPONSE_CONTEXT_NEG_RESP  */
    {DCM_RES_NEG_OK, DCM_RES_NEG_NOT_OK},
    /* For DCM_DSD_RESPONSE_CONTEXT_DSD_NRC */
    {DCM_RES_NEG_OK, DCM_RES_NEG_NOT_OK},
  };
  /* Get MessageInfo */
  SchM_Enter_Dcm_DsdMsgContextProtect();
  LddMessageInfo = Dsd_GstMessageInfo;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  /* Get mapping ID for the SID */
  if(DCM_DSD_MAX_SERVICE_ID > LddMessageInfo.ucSID)
  {
    LucGlobalSIDMapping = Dcm_GaaServiceIDMapping[LddMessageInfo.ucSID];
  }
  else
  {
    LucGlobalSIDMapping = DCM_INVALID_SID;
  }
  LddIdContext = LddMessageInfo.stMessageContext.idContext;
  /* Setting the right Dcm_ConfirmationStatusType to report to internal
     DSP or an SW-C processor */

  if(DCM_DSD_RESPONSE_CONTEXT_RP_RESP  != LddIdContext)
  {
    LddStatus = LaaConfStatusLookUp[LddIdContext][TransmissionResult];
    if((DCM_DSD_RESPONSE_CONTEXT_POS_RESP == LddIdContext) ||
    (DCM_DSD_RESPONSE_CONTEXT_NEG_RESP  == LddIdContext))
    {
      if(DCM_INVALID_SID != LucGlobalSIDMapping)
      {
        if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
        {
          /* Call the confirmation function */
          Dcm_GaaDsdDiagServiceConf[LucGlobalSIDMapping]
            (&(LddMessageInfo.stMessageContext), LddStatus);
        }
      }
    }
      /* SWS_Dcm_01000: Xxx_Confirmation shall be called even if an NRC
     was generated */

    /* SWS_Dcm_00462: Xxx_Confirmation shall be called no matter what happened
     with Xxx_Indication() */

    /* SWS_Dcm_00741, SWS_Dcm_00742: Xxx_Confirmation shall be called after
     DSP confirmation */
    if(DCM_DSD_RESPONSE_CONTEXT_DSD_NRC == LddIdContext)
    {
      /* Cannot close request here for DSP because the service might
         have scheduled actions to perform */

      /* Call Dsd_CloseRequest to close all the globals relevant to DSD */
      Dsd_CloseRequest();
    }
    if(DCM_DEFAULT_SESSION == Dcm_GddCurrentSession)
    {
      /* SWS_Dcm_00164: With the reception of Dcm_TpTxConfirmation()
      connected
      to the response given by the DSL submodule, the DCM shall call
      ComM_DCM_InactiveDiagnostic(NetworkId),with the networkId associated to
      the transmitted Pdu (see DcmDslProtocolComMChannelRef), to inform the
      ComM module that Full Communication is not longer needed */





      LpRxPduTable =
             &Dcm_GaaRxPduIdTable[LddMessageInfo.stMessageContext.dcmRxPduId];
      LpConnection = &Dcm_GaaConnection[LpRxPduTable->ucRxPduConnectionIndex];
      (void)ComM_DCM_InactiveDiagnostic(LpConnection->ddProtocolComMChannelRef);
    }
  }
  else
  {
    if(DCM_INVALID_SID != LucGlobalSIDMapping)
    {
      Dcm_GstCurrentProtocolInfo.ucPendingTransmit = DCM_NO_NRC_PENDING;
      if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
      {
        /* Call the ResponsePending confirmation function */
        Dcm_GaaDsdDiagServiceRPConf[LucGlobalSIDMapping]
          (&(Dsd_GstMessageInfo.stMessageContext), TransmissionResult);
      }
    }
  }
}/* End of Function Dsd_ResponseConfirmation */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DsdInternalProcessingDone                       **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to indicate DSL that processing is done         **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pMsgContext                                         **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dsd_GstMessageInfo             **
**                                             Dcm_GucServiceProcessingType   **
**                                             Dcm_GucROEFinalResponse        **
**                       Function(s) invoked : Dsl_DsdTransmitMainConn        **
**                                             Dsd_ResponseConfirmation       **
**                                             Dcm_DspFinalResponse           **
** Design ID             : DCM_SDD_7200                                       **
** Design ID             : DCM_SDD_0292                                       **
** Design ID             : DCM_SDD_0293                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_DsdInternalProcessingDone(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
)
{
  VAR(Std_ReturnType, DCM_VAR) LddTxRetValue;
  VAR(uint8, DCM_VAR) LucSID;
  SchM_Enter_Dcm_DsdMsgContextProtect();
  LucSID = Dsd_GstMessageInfo.ucSID;
  SchM_Exit_Dcm_DsdMsgContextProtect();
  /* Initialized to E_OK in case there is no transmission */
  LddTxRetValue = E_OK;
  if(DCM_TRUE != pMsgContext->msgAddInfo.suppressPosResponse)
  {
    if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
    {
      /* Add SID to the response data */
      *(pMsgContext->resData - DCM_ONE_U8) = (LucSID | DCM_RESPONSE_SID_MASK);
      /* Increase the length */
      pMsgContext->resDataLen += DCM_ONE_U8;
      /* If SuppressPosResponse was not set */
      LddTxRetValue = Dsl_DsdTransmitMainConn(pMsgContext->resData - DCM_ONE_U8,
        (uint16)pMsgContext->resDataLen);
    }
  }
  if(E_OK == LddTxRetValue)
  {
    /*
      Set the ID context to indicate that the response being sent (or not) is
      a positive or negative response
    */



    SchM_Enter_Dcm_DsdMsgContextProtect();
    /*
      Possible values of idContext are:
      1. DCM_DSD_RESPONSE_CONTEXT_POS_RESP: To indicate a positive response was
      sent
      2. DCM_DSD_RESPONSE_CONTEXT_NEG_RESP : To indicate a negative response
      was sent
      3. DCM_DSD_RESPONSE_CONTEXT_RP_RESP : To indicate a response pending
      (0x78) was sent
      4. DCM_DSD_RESPONSE_CONTEXT_DSD_NRC: To indicate the request never
      was forwarded
         to DSP since a DSD NRC originated
    */
    Dsd_GstMessageInfo.stMessageContext.idContext =
                                       DCM_DSD_RESPONSE_CONTEXT_POS_RESP;
    SchM_Exit_Dcm_DsdMsgContextProtect();
    /* Send an immediate confirmation to trigger actions required from
       Dsp_<Service>Conf */

    if(DCM_TRUE == pMsgContext->msgAddInfo.suppressPosResponse)
    {
      Dsd_ResponseConfirmation(LddTxRetValue);
    }
  }
  else
  {
    /*
       If PduR returns E_NOT_OK, we can complete the transmission by calling
       internal confirmation with E_NOT_OK, so that DSP is confirmed with
       the negative response
    */




    Dsd_ResponseConfirmation(E_NOT_OK);
  }
}/* End of Function Dcm_DsdInternalProcessingDone */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_InternalSetNegResponse                          **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to close functionality from DSD side on NRC     **
**                        reception from DSP                                  **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pMsgContext,ErrorCode                               **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dsd_GstMessageInfo,            **
**                                             Dcm_GaaServiceIDMapping,       **
**                                             Dcm_GucServiceProcessingType   **
**                                             Dcm_GaaDsdDiagServiceConf      **
**                       Function(s) invoked : Dsd_TransmitNRC,               **
**                                             Dsd_CloseRequest               **
** Design ID             : DCM_SDD_7208                                       **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
FUNC(void, DCM_CODE) Dcm_InternalSetNegResponse(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
  Dcm_NegativeResponseCodeType ErrorCode
)
{
  VAR(Dsd_MessageInfoType, DCM_VAR) LddMessageInfo;
  VAR(uint8, DCM_VAR) LucNRCTransmitStatus;
  VAR(uint8, DCM_VAR) LucGlobalSIDMapping;
  SchM_Enter_Dcm_DsdMsgContextProtect();
  LddMessageInfo = Dsd_GstMessageInfo;
  LucGlobalSIDMapping = Dcm_GaaServiceIDMapping[Dsd_GstMessageInfo.ucSID];
  SchM_Exit_Dcm_DsdMsgContextProtect();
  LucNRCTransmitStatus = Dsd_TransmitNRC(pMsgContext, ErrorCode);
  /* Indicate that negative response was sent by DSP */
  Dsd_GstMessageInfo.stMessageContext.idContext
    = DCM_DSD_RESPONSE_CONTEXT_NEG_RESP ;
  if(E_NOT_OK == LucNRCTransmitStatus)
  {
    if(DCM_INVALID_SID != LucGlobalSIDMapping)
    {
      if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
      {
        /* Call the confirmation function */
        Dcm_GaaDsdDiagServiceConf[LucGlobalSIDMapping]
          (&(LddMessageInfo.stMessageContext), DCM_RES_NEG_NOT_OK);
      }
    }
  }
  else if(DCM_NRC_TRANSMISSION_SUPPRESSED == LucNRCTransmitStatus)
  {
    if(DCM_INVALID_SID != LucGlobalSIDMapping)
    {
      if(DCM_INTERNAL_PROCESSING == Dcm_GucServiceProcessingType)
      {
        /* Call the confirmation function */
        Dcm_GaaDsdDiagServiceConf[LucGlobalSIDMapping]
          (&(LddMessageInfo.stMessageContext), DCM_RES_NEG_OK);
      }
    }
  }
  else
  {
    /* TO avoid the QAC warning*/
  }
}/* End of Function Dcm_InternalSetNegResponse */
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
/*******************************************************************************
** Function Name        : Dcm_DsdPeriodicResponse                             **
**                                                                            **
** Service ID           : None                                                **
**                                                                            **
** Description          : API to trigger periodic response                    **
**                                                                            **
** Sync/Async           : None                                                **
**                                                                            **
** Re-entrancy          : None                                                **
**                                                                            **
** Input Parameters     : pMsgContext,DID                                     **
**                                                                            **
** InOut parameter      : None                                                **
**                                                                            **
** Output Parameters    : None                                                **
**                                                                            **
** Return parameter     : None                                                **
**                                                                            **
** Preconditions        : None                                                **
**                                                                            **
** Remarks              : Global Variable(s)  :Dsd_GstMessageInfo             **
**                                             Dcm_GstDspPerdReadData         **
**                       Function(s) invoked : Dsl_DsdperiodicTransmitMainConn**
** Design ID             : DCM_SDD_7200                                       **
** Design ID             : DCM_SDD_7219                                       **
*******************************************************************************/
/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
