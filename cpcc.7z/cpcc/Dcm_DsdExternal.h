/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DsdExternal.h                                             **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager                      **
**                                                                            **
**  PURPOSE   : To provide Dsl routine declarations to other components       **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By          Description                    **
********************************************************************************
** 1.3.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.2.0     30-Sep-2019   Pooja S              Updated review fix            **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/

#ifndef DCM_DSDEXTERNAL_H
#define DCM_DSDEXTERNAL_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DsdInternalTypes.h"
#include "Dcm_DslExternal.h"
#include "Dcm_DslInternalTypes.h"

/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
/*Design ID : DCM_SDD_5090*/
typedef struct STag_Dsd_MessageInfoType
{
  /* */
  Dcm_MsgContextType stMessageContext;

  uint16 usTesterSrcAddress;

  uint8 ucSID;

  uint8 ucSubFunctionID;

  uint8 ucProcessPendingReq;

  Dcm_OpStatusType ddOpstatus;

}Dsd_MessageInfoType;

/*Design ID : DCM_SDD_6019*/
#define DCM_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dsd_MessageInfoType, DCM_VAR_NO_INIT) Dsd_GstMessageInfo;
#define DCM_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"

#if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
/*Design ID : DCM_SDD_6013*/
#define DCM_START_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_NO_INIT) Dcm_GusPagedBufferTimeOut;
#define DCM_STOP_SEC_VAR_NO_INIT_8
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6010*/
#define DCM_START_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR_NO_INIT) Dcm_GulCurrentFrameSize;
#define DCM_STOP_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6012*/
#define DCM_START_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR_NO_INIT) Dcm_GulPageLengthUpdate;
#define DCM_STOP_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6011*/
#define DCM_START_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"
extern VAR(uint32, DCM_VAR_NO_INIT) Dcm_GulCurrentSizeToCopy;
#define DCM_STOP_SEC_VAR_NO_INIT_32
#include "Dcm_MemMap.h"
#endif
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
#if(DCM_DSL_TEST_SOURCE_ADDRESS == STD_ON)
extern FUNC(void, DCM_CODE) Dsd_RequestIndication
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) RequestMessageContext,
  /* Reference to the current protocol SID Table */
  uint8 ProtocolSIDTableIndex,
  /* SID */
  uint8 SID,
  /* Source Address of the request */
  uint16 SourceAddress
);
#else
extern FUNC(void, DCM_CODE) Dsd_RequestIndication
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) RequestMessageContext,
  /* Reference to the current protocol SID Table */
  uint8 ProtocolSIDTableIndex,
  /* SID */
  uint8 SID
);
#endif
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslScheduled(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DsdScheduled(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspScheduled(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dsd_ResponseConfirmation
(
  Std_ReturnType TransmissionResult
);

extern FUNC(void, DCM_CODE) Dcm_DsdInternalProcessingDone
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_InternalSetNegResponse
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
  Dcm_NegativeResponseCodeType ErrorCode
);

extern FUNC(void, DCM_CODE) Dcm_DsdResponsePendingTransmit(void);

extern FUNC(void, DCM_CODE) Dcm_DsdAppResponsePendingTransmit(void);

extern FUNC(void, DCM_CODE) Dsd_CloseRequest(void);

extern FUNC(void, DCM_CODE) Dcm_DsdTriggerPosResp
  (P2CONST(Dcm_ProgConditionsType, AUTOMATIC, DCM_CONST)ProgConditions);


extern FUNC(void, DCM_CODE) Dsd_SessionValidation
(
  uint32 ServiceSesVector,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) NRC,
  Dcm_NegativeResponseCodeType ExpectedNRC
);

extern FUNC(void, DCM_CODE) Dsd_SecurityValidation
(
  uint32 ServiceSesVector,
  CONSTP2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_CONST) NRC
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dsd_DspNewPageAvailable
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext
);

extern FUNC(void, DCM_CODE) Dsd_DslPageCopied
(
  uint32 LulSduLength,
  PduLengthType availableDataPtr
);
extern FUNC(BufReq_ReturnType, DCM_CODE) Dsd_DslPageBufStatusCheck
(
  void
);
extern FUNC(uint32, DCM_CODE) Dsd_DslPageBuffCopy
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) LpBufferArea,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) info,
  uint32 LulSduLength
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DslNRCTransmit
(
  uint8 ConnectionIndex, Dcm_NegativeResponseCodeType NRCType
);

extern FUNC(uint8, DCM_CODE) Dcm_DslProtocolPreempt(
    CONSTP2CONST(Dcm_ConnectionType, AUTOMATIC, DCM_CONST)LpConnection,
    P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
    P2CONST(Dcm_RxPduIdTableType, AUTOMATIC, DCM_CONST)pRxPduTable);

extern FUNC(uint8, DCM_CODE) Dcm_ProtocolPreemptActions
   (uint8 NewConnectionIndex,
    P2CONST(Dcm_RxPduIdTableType, AUTOMATIC, DCM_CONST)LpRxPduTable);

extern FUNC(uint8, DCM_CODE) Dcm_ProtocolStartActions(uint8 NewConnectionIndex);

extern FUNC(void, DCM_CODE) Dcm_ProcessConcTP(void);
extern FUNC(void, DCM_CODE) Dcm_TpRxIndicationActions(PduIdType DcmRxPduId,
    Std_ReturnType Result);

extern FUNC(BufReq_ReturnType, DCM_CODE) Dcm_CheckConcTP(
    P2CONST(PduInfoType, AUTOMATIC, DCM_CONST) info,
    P2VAR(PduLengthType, AUTOMATIC, DCM_VAR) bufferSizePtr,
    P2CONST(Dcm_RxPduIdTableType, AUTOMATIC, DCM_CONST) pRxPduTable,
    PduIdType DcmRxPduId
  );
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)  Dcm_DsdPeriodicResponse(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext, uint8 DID);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#endif

/*******************************************************************************
**                      End of File                                           **
*******************************************************************************/
