/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_PBTypes.h                                                 **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of  published structure definitions                 **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_PBTYPES_H
#define DCM_PBTYPES_H


#include "Dcm_Types.h"
#include "Dcm_InternalTypes.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif

/*******************************************************************************
**                             Precompile Macros                              **
*******************************************************************************/
#if (DCM_PRE_COMPILE_SINGLE == STD_OFF)
#define DCM_DSP_COM_CHNL_NONE             0x0u
#endif

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/

/*****************************************************************************/
/**
Structure for protocol configuration:
This structure is generated for every configuration of DcmDslProtocolRow with
DcmDslProtocolRowUsed as TRUE
**/
/*Design ID : DCM_SDD_0940*/
typedef struct STag_Dcm_ProtocolConfig
{

  #if(DCM_PAGED_BUFFER_SUPPORT == STD_ON)
  /* This shall be equal to DcmDslProtocolMaximumResponseSize. Note that the
     parameter is mandatory when DcmPagedBufferEnabled == TRUE */
  Dcm_MsgLenType ddProtocolMaxResponseSize;
  #endif

  /* Ticks: DcmDslProtocolPreemptTimeout/DcmTaskTime */
  uint16 usPrtclPreempTimeOut;

  /* Ticks: DcmTimStrP2ServerAdjust/DcmTaskTime */
  uint16 usTimStrP2ServerAdjust;

  /* Ticks: DcmTimStrP2StarServerAdjust/DcmTaskTime */
  uint16 usTimStrP2StarServerAdjust;

  /* Pointer to the SID table configured for this protocol  via
     DcmDslProtocolSIDTable in DcmDslProtocolRow. All DcmDsdServiceTable shall
     have an instance of Dcm_GaaServiceTable[] generated and this shall be a
     pointer to the one referred by DcmDsdServiceTable. For details about
     Dcm_GaaServiceTable refer to Dcm_DslInternalTypes.h  */
   uint8 ucProtocolSIDTable;

  /* Equal to the parameter DcmDslProtocolRow->DcmDslProtocolPriority */
  uint8 ucProtocolPrio;

  /* Equal to the parameter DcmDslProtocolID which is an enumerator of
  type Dcm_ProtocolType */
  Dcm_ProtocolType ddProtocolID;

  /* Equal to the parameter DcmSendRespPendOnTransToBoot which is a boolean
     parameter. */
  boolean blSendRespPendOnBoot;

} Dcm_ProtocolConfig;

/*Design ID : DCM_SDD_6038*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ProtocolConfig, DCM_CONST) Dcm_GaaProtocolConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#if(DCM_DIDS_PRESENT == STD_ON)
typedef enum
{
  #if(DCM_SYNC_DATA_WRITE_CONFIGURED == STD_ON)
  DCM_SYNC_DATA_WRITE,
  #endif

  #if(DCM_ASYNC_DATA_WRITE_CONFIGURED == STD_ON)
  DCM_ASYNC_DATA_WRITE,
  #endif

  #if(DCM_ASYNC_DATA_WRITE_WITH_ERROR_CONFIGURED == STD_ON)
  DCM_ASYNC_ERROR_DATA_WRITE,
  #endif

  #if(DCM_NV_BLOCK_WRITE_CONFIGURED == STD_ON)
  DCM_NVM_BLOCK_ID_DATA_WRITE,
  #endif

  #if(DCM_DID_RANGE_WRITE_CONFIGURED == STD_ON)
  DCM_DID_RANGE_WRITE,
  #endif

  #if(DCM_SR_DATA_WRITE_CONFIGURED == STD_ON)
  DCM_SR_DATA_WRITE,
  #endif

  DCM_DUMMY_DATA_WRITE
}Dcm_DspDestType;
#endif

/*******************************************************************************
** Protocol Info Structure for Postbuild                                      **
*******************************************************************************/
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
/*Design ID : DCM_SDD_6301*/
typedef struct Stag_Dcm_ProtocolUsedInfo
{
 /* Pointer to DcmDslProtocolRowUsed
    boolean LblProtRowUsed ;
    Pointer to Dcm_ProtocolConfig Structure */
 P2CONST(Dcm_ProtocolConfig, AUTOMATIC, DCM_CONST) pProtocolconfig;

}Dcm_ProtocolUsedInfo;

/*Design ID : DCM_SDD_6313*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ProtocolUsedInfo, DCM_CONST) Dcm_GaaProtocolRowUsedRef[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/******************************************************************************/

/**
  Name: Dcm_GaaDsdSubService
  Type: Dcm_DsdSubService
  Configuration Dependencies: DcmDsdSubService, DcmDsdSubServiceUsed,
  DcmDsdSubServiceId Generation Description: This structure is generated
  for every instance of DcmDsdSubService with  DcmDsdSubServiceUsed as TRUE.
  SubServices belonging to a particular DcmDsdService shall be generated
  together and in an ascending order of DcmDsdSubServiceId.
**/

/*Design ID : DCM_SDD_0932*/
/*Design ID : DCM_SDD_0291*/
typedef struct STag_Dcm_DsdSubService
{
  #if(DCM_DSD_SUB_SERVICE_FNC == STD_ON)
  /* This is the pointer to function to a manufacturer specific call-out that
     validates the SubService. The name of this callout shall be identical to
     from the string parameter DcmDsdSubServiceFnc. Note that an "&" is
   necessary when dereferencing the function. If for example
   DcmDsdSubServiceFnc is 'SubServiceValidation_1' this element shall be
   &SubServiceValidation_1. If there is no DcmDsdSubServiceFnc configured,
   this element shall be NULL_PTR */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pDsdSubServiceFnc)
  (Dcm_OpStatusType OpStatus,
   Dcm_MsgContextType* pMsgContext,
   Dcm_NegativeResponseCodeType* ErrorCode);
  #endif

   /* There can only be 32 Sessions in one DCM. Hence the following is a
   mask containing if the Service is configured for this service. If for
   example, if sessions 3, 4 and 7 are referred through
   DcmDsdSubServiceSessionLevelRef, then this field will be set
   as 00000000000000000000000010011000b i.e., 0x00000098
   Note: If the field DcmDsdSubServiceSessionLevelRef is empty, the default
   value is all bits set i.e., 0xFFFFFFFF */
  uint32 ulSubServiceSesVector;

  /* There can only be 32 security levels in one DCM. Hence the following is a
  mask containing if the Service is configured for this service. If for example,
  if security levels 10, 13 and 30 are referred through
  DcmDsdSubServiceSecurityLevelRef, then this field will be
  set as 010000000001001000000000000000000b i.e., 0x40120000.
  Note: If the field DcmDsdSubServiceSecurityLevelRef is empty, the default
  value is all bits set i.e., 0xFFFFFFFF*/
  uint32 ulSubServiceSecLevVector;

  #if(DCM_DSP_MODE_RULE == STD_ON)
  /* If the DcmDsdSubServiceModeRuleRef is configured that rule index needs be
  generated else 0xFFFF needs to generated  */
  uint16 ucSubServiceRuleindex;
  #endif

}Dcm_DsdSubService;

/*
  Name: Dcm_GaaSubServiceUsed
  Type: Dcm_SubServiceUsedInfo
  Description: This structure is used to map the dcmDsdSubServiceUsed
  parameter with Dcm_GaaDsdSubService array during Post Build.
*/
#if (DCM_PRE_COMPILE_SINGLE == STD_OFF)
/* Design ID: DCM_SDD_6303 */
typedef struct STag_Dcm_DsdSubServiceUsed
{
  /*To Generate TRUE or FALSE based on dcmDsdSubServiceUsed is configured
    boolean LblSubServiceUsed;
    Reference of Dcm_GaaDsdSubService array instances*/
  P2CONST(Dcm_DsdSubService, AUTOMATIC, DCM_CONST) pSubServiceRef;
}Dcm_SubServiceUsedInfo;

/* Design ID: DCM_SDD_6317 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_SubServiceUsedInfo, DCM_CONST) Dcm_GaaSubServiceUsed[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/**
  Name: Dcm_GaaDsdService
  Type: Dcm_DsdService
  Configuration Dependencies: DcmDsdServiceTable, DcmDsdService,
  DcmDsdServiceUsedGeneration Description: This structure is generated for
  every instance of DcmDsdService that is:
      a. Referred to by at least one DcmDsdServiceTable->DcmDsdService
      b. The service has DcmDsdServiceUsed set to TRUE
**/
/*Design ID : DCM_SDD_0933*/
typedef struct STag_DcmDsdService
{
  #if(DCM_DSD_SERVICE_FNC == STD_ON)
  /* This is the pointer to function to a manufacturer specific call-out that
   validates the SubService. The name of this call-out shall be identical to
   from the string parameter DcmDsdSidTabFnc. Note that an "&" is necessary
   when dereferencing the function. If for example DcmDsdSidTabFnc is
   'ServiceValidation_1' this element shall be &ServiceValidation_1 */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pDsdServiceFnc)
  (Dcm_OpStatusType OpStatus,
   Dcm_MsgContextType* pMsgContext,
   Dcm_NegativeResponseCodeType* ErrorCode);
  #endif

  /*
    This is a pointer to Dcm_GaaSubServiceMapping containing the mapping from
    DcmDsdSubServiceId to a range starting from 0 and consecutive.

    For example, if DcmDsdSubServiceId's for a particular service are 0x01,
    0x07, 0x0A, and 0x10, the array Dcm_GaaSubServiceMapping[] for this service
    shall be

    And for another service are 0x00, 0x01, and 0x03.

    Dcm_GaaSubServiceMapping[] =
    {
      DCM_INVALID_SUBSERVICE_ID, 0x00,
      DCM_INVALID_SUBSERVICE_ID,
    DCM_INVALID_SUBSERVICE_ID, DCM_INVALID_SUBSERVICE_ID,
      DCM_INVALID_SUBSERVICE_ID, DCM_INVALID_SUBSERVICE_ID, 0x01,
      DCM_INVALID_SUBSERVICE_ID, DCM_INVALID_SUBSERVICE_ID, 0x02,
      DCM_INVALID_SUBSERVICE_ID, DCM_INVALID_SUBSERVICE_ID,
    DCM_INVALID_SUBSERVICE_ID,
      DCM_INVALID_SUBSERVICE_ID, DCM_INVALID_SUBSERVICE_ID, 0x03 ,
      0x04, 0x05, DCM_INVALID_SUBSERVICE_ID, 0x06

    }
    ucNumSubServiceMapping for the first service shall be 16.
    ucNumSubServiceMapping for the second service shall be 4.

  */

  P2CONST(uint8, AUTOMATIC, DCM_CONST) pSubServiceMapping;

  /* Reference to Dcm_GaaDsdSubService[]. If no subfunctions are available i.e.,
     DcmDsdSidTabSubfuncAvail is false and no DcmDsdSubService's configured,
     this shall be NULL_PTR. Dcm_GaaDsdSubService[] shall be configured in
     such a way that the ones belonging to a service shall be sequential
     in the array Dcm_GaaDsdSubService*/
  P2CONST(Dcm_DsdSubService, AUTOMATIC, DCM_CONST) pSubService;


  /* There can only be 32 Sessions in one DCM. Hence the following is a mask
  containing if the Service is configured for this service. If for example,
  if sessions s 3, 4 and 7 are referred through DcmDsdSidTabSessionLevelRef,
  then this field will be set as 00000000000000000000000010011000b
  i.e., 0x00000098
     Note: If the field DcmDsdSidTabSessionLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF */
  uint32 ulServiceSesVector;

  /* There can only be 32 security levels in one DCM. Hence the following is
  a mask containing if the Service is configured for this service. If for
  example, if security levels 10, 13 and 30 are referred through
  DcmDsdSidTabSecurityLevelRef, then this field will be
  set as 010000000001001000000000000000000b i.e., 0x40120000

     Note: If the field DcmDsdSidTabSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF */
  uint32 ulServiceSecLevVector;
  #if(DCM_DSP_MODE_RULE == STD_ON)
  /* If the DcmDsdSidTabModeRuleRef is configured that rule index needs be
  generated else 0xFFFF needs to generated  */
  uint16 ucServiceRuleindex;
  #endif

/* Number of elements of Dcm_GaaSubServiceMapping reserved for this Service.
 For example, in the above example, ucNumSubServiceMapping shall be
 equal to 16 */
  uint8 ucNumSubServiceMapping;

}Dcm_DsdService;

/*
  Name: Dcm_GaaServiceUsed
  Type: Dcm_ServiceUsedInfo
  Description: This structure is used to map the dcmDsdServiceUsed
  parameter with Dcm_GaaDsdService array during Post Build.
*/
#if (DCM_PRE_COMPILE_SINGLE == STD_OFF)
/* DEsign ID : DCM_SDD_6302 */
typedef struct STag_Dcm_DsdServiceUsed
{
  /*Reference of Dcm_GaaDsdService array instances*/
  P2CONST(Dcm_DsdService, AUTOMATIC, DCM_CONST) pServiceRef;
}Dcm_ServiceUsedInfo;

/* Design ID : DCM_SDD_6315 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ServiceUsedInfo, DCM_CONST) Dcm_GaaServiceUsed[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/****************************************************************************/
/**
  Name: Dcm_GaaDspRid[]
  Type: Dcm_DspRidType
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspRoutine, DcmDspRoutine->
  DcmDspRoutineIdentifier, DcmDspRoutineUsed
  Generation Description: This array of structures contains basic description
  about all the routines configured in Dcm.  It also contains further references
  RoutineControlType related data. This structure shall be instantiated for
  every instance of DcmDspRoutine with DcmDspRoutineUsed TRUE.
  Sorting: This shall be sorted according to the corresponding
  mapping array i.e., Dcm_GaaRidMapping[].
**/

/*Design ID : DCM_SDD_0966*/
typedef struct STag_Dcm_DspRidType
{
  /* Similar to ulSubServiceSesVector. DcmDsdSubServiceSessionLevelRef gets
     replaced by DcmDspRoutine->DcmDspCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSessionRef */
  uint32 ulRidSesVector;
  /* Similar to ulSubServiceSecLevVector. DcmDsdSubServiceSessionLevelRef gets
     replaced by DcmDspRoutine->DcmDspCommonAuthorizationRef->
     DcmDspCommonAuthorization->DcmDspCommonAuthorizationSecurityLevelRef. */
  uint32 ulRidSecLevVector;

  uint32 usRoutineStartStopStatus;

  uint32 usRoutineNoShiftbits;

  uint32 usRoutinePos;
  /* Reference to Dcm_GaaRoutineCtrlRef[] instance that corresponds to the
     'Start' instance of this Rid. See the notes for
     Dcm_GaaRoutineCtrlRef[]. */

  #if(DCM_DSP_MODE_RULE == STD_ON)
  /* If the DcmDspCommonAuthorizationModeRuleRef is configured that rule index
  needs be generated else 0xFFFF needs to generated  */
  uint16 ucRoutineRuleindex;
  #endif

     /* Reference to Dcm_GaaRoutineCtrlRef[] instance that corresponds to the
     'Start' instance of this Rid. See the notes for
     Dcm_GaaRoutineCtrlRef[]. */
    uint16 usRoutineCtrl;

  #if(STD_ON == DCM_DSP_RIDCONFIGSTATUS)
  /*To get DcmDspRoutineInfoByte [ECUC_Dcm_01063]*/
  uint8 usRoutineInfoByte;
  #endif
}Dcm_DspRidType;

/* Design ID : DCM_SDD_6143 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspRidType, DCM_CONST) Dcm_GaaDspRid[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*******************************************************************************
** Routine Info Structure for Postbuild                                       **
*******************************************************************************/
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
/* Design ID: DCM_SDD_6304 */
typedef struct Stag_Dcm_RoutineUsedInfo
{  /* Pointer to Routine Structure */
  P2CONST(Dcm_DspRidType, AUTOMATIC, DCM_CONST) pDspRid;
}Dcm_RoutineUsedInfo;

/* Design ID: DCM_SDD_6319 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RoutineUsedInfo, DCM_CONST) Dcm_GaaRoutineUsedRef[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/******************************************************************************/
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
/* Design ID: DCM_SDD_6305 */
typedef struct Stag_Dcm_ComCtrlAllChUsedInfo
{
 /* Pointer to DcmDspComControlAllChannelUsed */
   boolean LblChannelUsed ;

   /*This element should generate the ComMchannel id configured under
      DcmDspComControlAllChannel  */
   NetworkHandleType ucAllComMChaneelId;

 /*This function Pointer should generate as
    &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
    should be fetched from DcmDspComControlAllChannel */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchAllChaneelFunc)
  (Dcm_CommunicationModeType CommunicationType);

}Dcm_DspComControlAllChUsedInfo;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspComControlAllChUsedInfo, DCM_CONST)
Dcm_GaaComCtrlAllChanConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6306 */
typedef struct STag_Dcm_DspCommControlspecificType
{
   /*DcmDspComControlSpecificChannelUsed parameter(TRUE/FALSE) */
   boolean LblSpecChannelUsed ;

      /* This element should generate the channel id configured under
      DcmDspSpecificComMChannelRef */
   NetworkHandleType ucComCtrlSepcChaneel;

   /* This shall be a duplicate of the parameter DcmDspSubnetNumber*/
   uint16 usSubNetNumber;

  /*This function Pointer should generate as
    &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
    should be fetched from DcmDspSpecificComMChannelRef */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchCommModeSpecFunc)
  (Dcm_CommunicationModeType CommunicationType);

}Dcm_DspCommControlspecificType;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspCommControlspecificType, DCM_CONST) Dcm_GaaComCtrlConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6307 */
typedef struct STag_Dcm_DspComControlSubNode
{
  /*DcmDspComControlSpecificChannelUsed parameter(TRUE/FALSE) */
  boolean LblSubNodeUsed ;

    /* This element should generate the channel id configured under
      DcmDspComControlSubNodeComMChannelRef */
  NetworkHandleType ucComCtrlSubChaneel;

    /*This shall be a duplicate of the parameter DcmDspComControlSubNodeId */
  uint16 usDcmDspComCtrlSubNodeId;


  /*This function Pointer should generate as
  &SchM_Switch_Dcm_DcmCommunicationControl_<ComMChaneelID> ,the channel Id
  should be fetched from DcmDspComControlSubNodeComMChannelRef */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pSchMSwitchSubnodeComMChaneelFunc)
  (Dcm_CommunicationModeType CommunicationType);

}Dcm_DspComControlSubNode;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspComControlSubNode, DCM_CONST) Dcm_GaaComCtrlSubNodeConfig[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/****************************************************************************/

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON) ||\
    (DCM_DSP_OBDVEHINFO==STD_ON)||\
    (DCM_DSP_REQUESTCONTROL_TESTCOMPONENT == STD_ON)||\
    (DCM_READ_DID_SERVICE == STD_ON)||\
    (DCM_RIDS_PRESENT == STD_ON))
/*Design ID : DCM_SDD_5050*/
typedef struct STag_Dcm_DspAviliabiltyReqId
{
  /*status whether any one of PID exist in the specified Range*/
  boolean blReqIdStatus;
  /*Avialiablity PIDs from range 0x01 to 0x20*/
  uint8 ucByteA;
  /*Avialiablity PIDs from range 0x21 to 0x40*/
  uint8 ucByteB;
  /*Avialiablity PIDs from range 0x41 to 0x60*/
  uint8 ucByteC;
  /*Avialiablity PIDs from range 0x60 to 0x80*/
  uint8 ucByteD;
}Dcm_DspAviliabiltyReqId;

#endif
/*****************************************************************************/
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
typedef enum
{
  #if(DCM_SYNC_DATA_READ_CONFIGURED == STD_ON)
  DCM_SYNC_DATA_READ,
  #endif

  #if(DCM_ASYNC_DATA_READ_CONFIGURED == STD_ON)
  DCM_ASYNC_DATA_READ,
  #endif

  #if(DCM_ASYNC_DATA_READ_WITH_ERROR_CONFIGURED == STD_ON)
  DCM_ASYNC_ERROR_DATA_READ,
  #endif

  #if(DCM_NV_BLOCK_READ_CONFIGURED == STD_ON)
  DCM_NVM_BLOCK_ID_DATA_READ,
  #endif

  #if(DCM_ECU_SIGNAL_CONFIGURED == STD_ON)
  DCM_ECU_SIGNAL_DATA_READ,
  #endif

  #if(DCM_DID_RANGE_READ_CONFIGURED == STD_ON)
  DCM_DID_RANGE_READ,
  #endif

  #if(DCM_SR_DATA_READ_CONFIGURED == STD_ON)
  DCM_SR_DATA_READ,
  #endif

  DCM_0xF186_DATA_READ,

  DCM_DUMMY_DATA
}Dcm_DspSrcType;


typedef struct STag_Dcm_DspDataRead
{

  /*
     The read function can be of many types depending on DcmDspDataUsePort.
     If DcmDspDataUsePort is
     a. USE_BLOCK_ID, the function shall be NvM_BlockRead, and
        pReadDidFromSource will point to Dcm_GaaDspDidNvMBlock. ucSourceType
        shall be DCM_NVM_BLOCK_ID_DATA_READ.
     b. USE_DATA_ASYNCH_CLIENT_SERVER, USE_DATA_ASYNCH_FNC: pReadDidFromSource
        will point to Dcm_GaaDspDidAsyncFuncs. ucSourceType shall be
        DCM_ASYNC_DATA_READ.
     c. USE_DATA_ASYNCH_CLIENT_SERVER_ERROR, USE_DATA_ASYNCH_FNC_ERROR:
        pReadDidFromSource will point to Dcm_GaaDspDidAsyncErrorFuncs.
        ucSourceType shall be DCM_ASYNC_ERROR_DATA_READ.
     d. USE_DATA_SYNCH_CLIENT_SERVER, USE_DATA_SYNCH_FNC:
        pReadDidFromSource will point to Dcm_GaaDspDidSyncFuncs.
        ucSourceType shall be DCM_SYNC_DATA_READ.
     e. USE_ECU_SIGNAL: pReadDidFromSource shall point to
     Dcm_GaaDspDidEcuSignal. ucSourceType shall be DCM_ECU_SIGNAL.
     f. DcmDspDidRange: If this instance of Dcm_DspDataRead comes from a
     DcmDspDidRange and shall point to Dcm_GaaDspDidRange[], ucSourceType
     shall be DCM_DID_RANGE_READ.
     f. USE_DATA_SENDER_RECEIVER, USE_DATA_SENDER_RECEIVER_AS_SERVICE:
        pReadDidFromSource will point to Dcm_GaaDspDidSendRecFuncs.
        ucSourceType shall be DCM_SR_DATA_READ.

 */

  P2CONST(void, DCM_CONST, DCM_CONST) pReadDidFromSource;


  /* This element contains the type of source.

     Refer above for details */
  Dcm_DspSrcType  ucSourceType;

}Dcm_DspDataRead;

/*Design ID : DCM_SDD_0954*/
typedef struct STag_Dcm_DspDidRead
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidReadSessionRef, then this field will be set as
     00000000000000000000000010011000b i.e., 0x00000098.

     Note: If the field DcmDspDidReadSessionRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulReadDidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidReadSecurityLevelRef, then this field will be set as
     010000000001001000000000000000000b i.e., 0x40120000

     Note: If the field DcmDspDidReadSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulReadDidSecLevVector;

}Dcm_DspDidRead;

#if(DCM_DATA_WRITE_CONFIGURED == STD_ON)
/**
  Name: Dcm_GaaDspDidWrite[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo->DcmDspDidWrite, DcmDidUsed.
  Generation Description: This shall be instantiated per instance of
  DcmDspDidWrite, and shall be referred from Dcm_GaaDspDidInfo. Hence
  the sorting does not matter.

**/
/*Design ID : DCM_SDD_0957*/
typedef struct STag_Dcm_DspDidWrite
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidWriteSecurityLevelRef, then this field will be set as
     00000000000000000000000010011000b i.e., 0x00000098.

     Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulWriteDidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidWriteSecurityLevelRef, then this field will be set as
     010000000001001000000000000000000b i.e., 0x40120000

     Note: If the field DcmDspDidWriteSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulWriteDidSecLevVector;

}Dcm_DspDidWrite;

/* Design ID : DCM_SDD_6137 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidWrite, DCM_CONST) Dcm_GaaDspDidWrite[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif


#if(DCM_DSP_IO_CONTROL == STD_ON)
/**
  Name: Dcm_GaaDspDidRead[]
  Type: Structure
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspDidInfo->DcmDspDidRead, DcmDidUsed
  Generation Description: This shall be instantiated per instance of
  DcmDspDidRead, and shall be referred from Dcm_GaaDspDidInfo. Hence
  the sorting does not matter. DcmDidUsed applies here also.

**/
/*Design ID : DCM_SDD_5070*/
typedef struct STag_Dcm_DspIoControl
{

  /*
     There can only be 32 Sessions in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if sessions 3, 4 and 7 are referred through
     DcmDspDidControlSessionRef, then this field will be set as
     00000000000000000000000000000111b i.e., 0x00000007.

     Note: If the field DcmDspDidControlSessionRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulIODidSesVector;

  /*
     There can only be 32 security levels in one DCM. Hence the following is a
     mask containing if the Service is configured for this service.
     If for example, if security levels 10, 13 and 30 are referred through
     DcmDspDidControlSecurityLevelRef, then this field will be set as
     00000000000000000000000000000111b i.e., 0x00000007

     Note: If the field DcmDspDidControlSecurityLevelRef is empty, the default
     value is all bits set i.e., 0xFFFFFFFF
  */
  uint32 ulIODidSecLevVector;
   /* If the ucIoCtrlModeRuleIndex is configured that
  rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucIoCtrlModeRuleIndex;
  #endif

  /* this element has to be generated as per the DcmDspDidControlMask
     the follwing vaues has to be generated for coressponding literals
      if DCM_CONTROLMASK_NO -  0x00
         DCM_CONTROLMASK_EXTERNAL -0x01
         DCM_CONTROLMASK_INTERNAL -0x02
     default value - 0x02   */
  uint8 ucDcmDspDidControlMask;

  /* the duplicate value of DcmDspDidControlMaskSize */
  uint8 DcmDspDidControlMaskSize;

  /* Mask of InputOutputControlParameter i.e.,
     first bit possition is for returnControlToECU this is mandatory for all
     signals it should be seted for all DID'S defautly.

     second bit position is for resetToDefault this bit to set only if
   DcmDspDidResetToDefault is set to true for the corresponding DID.

   third bit  postion is for freezeCurrentState this bit has to be set only if
     DcmDspDidFreezeCurrentState is set to true for the corresponding DID.

     fourth bit  postion is for shortTermAdjustment this bit has to be set only
     if DcmDspDidShortTermAdjustment is set to true for the corresponding DID.
     EX:
   in DcmDspDidInfo->DcmDspDidControl if the DcmDspDidFreezeCurrentState and
      DcmDspDidShortTermAdjustment both are set to trur then the mask has to be
     generated as 0x0D

   Default value:0x01
   */
    uint8 ucIOCtrlParameter;


}Dcm_DspIoControl;

/* Design ID : DCM_SDD_6128 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspIoControl, DCM_CONST) Dcm_GaaDspDidIoCtrl[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#if((DCM_DATA_READ_CONFIGURED == STD_ON) ||\
   (DCM_DATA_WRITE_CONFIGURED == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
typedef struct STag_Dcm_DspDidInfo
{
      #if(DCM_DSP_IO_CONTROL == STD_ON)
  P2CONST(Dcm_DspIoControl, DCM_CONST, DCM_CONST) pIoControl;
  #endif

    #if(DCM_DATA_READ_CONFIGURED == STD_ON)
       /* Pointer to read structure i.e., the relevant instance of
     Dcm_GaaDspDidRead if DcmDspDid->DcmDspDidInfo->DcmDspDidRead is
     configured for a particular Did. If no DcmDspDidRead is configured,
     pDidRead shall be generated as NULL_PTR. The element also shall be
     generated only if  at least a single instance of
     DcmDspDid->DcmDspDidInfo->DcmDspDidRead is configured. */
  P2CONST(Dcm_DspDidRead, DCM_CONST, DCM_CONST) pDidRead;
    #endif

   #if(DCM_DATA_WRITE_CONFIGURED == STD_ON)
      /* Pointer to write structure. If
  DcmDspDid->DcmDspDidInfoRef->DcmDspDidWrite
     is configured for a particular Did. If no DcmDspDidWrite is configured,
     pDidRead shall be generated as NULL_PTR. The element also shall be
     generated only if  at least a single instance of
     DcmDspDid->DcmDspDidInfo->DcmDspDidWrite is configured. */
  P2CONST(Dcm_DspDidWrite, DCM_CONST, DCM_CONST) pDidWrite;
   #endif


  #if(DCM_DATA_WRITE_CONFIGURED == STD_ON)
 /* If the DcmDspDidWriteModeRuleRef is configured that
  rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucWriteModeRuleIndex;
  #endif
  #endif

     #if(DCM_DATA_READ_CONFIGURED == STD_ON)
  /* If the DcmDspDidReadModeRuleRef is configured that
     rule index needs be generated else 0XFFFF needs to generated  */
  #if(DCM_DSP_MODE_RULE == STD_ON)
  uint16 ucReadModeRuleIndex;
  #endif
  #endif
}Dcm_DspDidInfo;

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidInfo, DCM_CONST) Dcm_GaaDspDidInfo[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

typedef struct STag_Dcm_RxUnpack
{
  /*
    DcmDspDataSize is optional in case of primitive datatypes like:
    boolean: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 1
    uint8: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 8
    uint16: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 16
    uint32: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 32
    sint8: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 8
    sint16: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 16
    sint32: In case DcmDspDataSize is omitted, assume DcmDspDataSize to be 32
    The rest of the calculation remains identical.

    Signal Type based on the size of the signal configured via DcmDspDataSize
    Between 0 and 8 bits ucSignalType = 0
    Between 9 and 16 bits ucSignalType = 1
    Between 17 and 24 bits ucSignalType = 2
    Between 25 and 32 bits ucSignalType = 3
    If uint8_n, uint16_n, uint32_n,
    sint8_n, sint16_n, sint32_n, ucSignalType shall be 'n' i.e.,
    the number of bytes in case of uint8_n and sint8_n i.e.  DcmDspDataSize/8
    Number of words in case of sint16_n and uint16_n i.e.  DcmDspDataSize/16 ,
    Number of double-words in case of sint32_n, and  uint32_n i.e., i.e.
    DcmDspDataSize/32

    For DcmDspStopRoutineInSignal and DcmDspStartRoutineInSignal, the same
    logic applies, with DcmDspDataSize replaced by DcmDspRoutineSignalLength.

    Note that DcmDspRoutineSignalLength and DcmDspDataSize are optional in
    case of primitive datatypes like boolean. In case of boolean datatypes,
    the size has to be assumed to be 1 bit.
    */
  uint8 ucSignalType;

  /* Index of the read function pointer array. Depending upon the signal type
  and endianness, generation tool should generate the appropriate array index.

  There shall be following pack functions:
  Dcm_UnpackOneByte: For unpacking data of less than or equal to one byte. For
  this ucWrFuncIndex shall be 0.
  Dcm_UnpackBytes: For unpacking data that spread across 2 and 4 bytes. For
  this ucWrFuncIndex shall be 1.
  Dcm_UnpackFiveBytes: For unpacking data that spread across 5 bytes. For
  this ucWrFuncIndex shall be 2.
  Dcm_UnpackByteOrdering: For unpacking data that spread across 2 and 4 bytes
  with endianness conversion. For this ucWrFuncIndex shall be 3.
  Dcm_UnpackFiveByteOrdering: For unpacking data that spread across 5 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 4.
  Dcm_UnpackNBytes: For unpacking uint8_n/sint8_n data. For
  this ucWrFuncIndex shall be 5.
  Dcm_Unpack2NBytes: For unpacking uint16_n/sint16_n data. For
  this ucWrFuncIndex shall be 6.
  Dcm_Unpack4NBytes: For unpacking uint32_n/sint32_n data. For
  this ucWrFuncIndex shall be 7.
  Dcm_Unpack2NBytesOrdering: For unpacking uint16_n/sint16_n data with
  endianness conversion. For this ucWrFuncIndex shall be 8.
  Dcm_Unpack4NBytesOrdering: For unpacking uint32_n/sint32_n data with
  endianness conversion. For this ucWrFuncIndex shall be 9.

  For the example given above (6th starting bit, 8 bits) the ucWrFuncIndex
  shall be 2 i.e., Dcm_UnpackBytes.

  Endianness conversion becomes necessary if system endianness is different
  from DcmDspDataEndianness. If DcmDspDataEndianness is not configured, the
  endianness of all data shall be derived from DcmDspDataDefaultEndianness.
  System endianness can be found in the system's
  Platform_Types.h as CPU_BYTE_ORDER. If CPU_BYTE_ORDER is HIGH_BYTE_FIRST
  then the endian-ness of the system is BIG_ENDIAN. If it is LOW_BYTE_FIRST,
  then the endianness of the system is LITTLE_ENDIAN.

  For DcmDspStopRoutineInSignal and DcmDspStartRoutineInSignal, the same
    logic applies, with DcmDspDataSize replaced by DcmDspRoutineSignalLength,
  DcmDspDataEndianness replaced by DcmDspRoutineSignalEndianness.
  DcmDspDataDefaultEndianness is used as before.

  */
  uint8 ucRdFuncIndex;

  /* Number of shift bits. Generation tool should generate the value based on
  the configuration

  Again, which byte we consider for shifting depending on the endianness.

  The logic is the same as in TxPack structure.

  */
  uint8 ucNoOfShiftBits;


  /* End mask value. Generation tool should generate the end mask value based
  on the size of the network signal.

    End mask in unpack structure is the reverse of the end mask in TxPack i.e.,
    it has to be set for the bits the data occupies not reset.

    For example consider a signal that starts at the 6th bit and occupies
    8 bits. The signal is configured as a LE system i.e., coming in
    from a LE system. In that frame the last byte is the 2nd byte, and
    0-4 bits are occupied. Hence ucRdEndMask shall be 00011111b.

  */
  uint8 ucRdEndMask;



  /* This should be generated only for the
  signed data. For unsigned data it shall be generated as
  This shall be used for sign extension.

  For example, if a signed data of type sint16 contains only 13 bits,
  we have to convert it to full 16 bits i.e., we have to extend the sign
  by 3 bits. Hence the ucRdSignMask here is 11110000b i.e., 4 bits.
  It's 4 bits because it includes the sign bit as well.

 */
  uint8 ucRdSignMask;

    /* Size of the signal. Generation tool should generate the value based on
    the size of the signal spread across an I-PDU. This value is in bytes. */
  PduLengthType ddSignalSize;

}Dcm_RxUnpackType;


/* Design ID : DCM_SDD_6149 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_RxUnpackType, DCM_CONST) Dcm_GaaRxUnpack[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#if(DCM_DATA_WRITE_CONFIGURED == STD_ON)
/*Design ID : DCM_SDD_0958*/
typedef struct STag_Dcm_DspDataWrite
{

  /*
    Default value: Not necessary because if write is configured, there will
    be a valid reference to one of the below structures.


     The read function can be of many types depending on DcmDspDataUsePort.
     If DcmDspDataUsePort is
     a. USE_BLOCK_ID, the function shall be NvM_BlockRead, and pWriteDidToDest
        will point to Dcm_GaaDspDidNvMBlock. ucSourceType shall be
        DCM_NVM_BLOCK_ID_DATA_WRITE.
     b. USE_DATA_ASYNCH_CLIENT_SERVER, USE_DATA_ASYNCH_FNC: pWriteDidToDest
        will point to Dcm_GaaDspDidAsyncFuncs. ucSourceType shall be
        DCM_ASYNC_DATA_WRITE.
     c. USE_DATA_ASYNCH_CLIENT_SERVER_ERROR, USE_DATA_ASYNCH_FNC_ERROR:
        pWriteDidToDest will point to Dcm_GaaDspDidAsyncErrorFuncs.
        ucSourceType shall be DCM_ASYNC_ERROR_DATA_WRITE.
     d. USE_DATA_SYNCH_CLIENT_SERVER, USE_DATA_SYNCH_FNC:
        pWriteDidToDest will point to Dcm_GaaDspDidSyncFuncs.
        ucSourceType shall be DCM_SYNC_DATA_WRITE.
     f. DcmDspDidRange: If this instance of Dcm_DspDataWrite comes from a
     DcmDspDidRange and shall point to Dcm_GaaDspDidRange[], ucSourceType
     shall be DCM_DID_RANGE.

      Note: USE_ECU_SIGNAL cannot be configured for read.

 */

  P2CONST(void, DCM_CONST, DCM_CONST) pWriteDidToDest;


  /* This element contains the type of source.

     Refer above for details */
  Dcm_DspDestType  ucSourceType;

}Dcm_DspDataWrite;

/* Design ID : DCM_SDD_6122 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDataWrite, DCM_CONST) Dcm_GaaDspDataWrite[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

typedef struct STag_Dcm_TxPack
{
  /* Signal type or size of the signal. Higher nibble represents the type of the
  signal and Lower nibble represents the size of the signal that is spread
  across I-PDU. Generation tool should generate the value based on the following
  formulae:
    0x11     8 bit signal pack into one byte
    0x12     8 bit signal pack into two byte
    0x22    16 bit signal pack into two byte
    0x23    16 bit signal pack into three byte
    0x33    24 bit signal pack into three byte
    0x34    24 bit signal pack into four byte
    0x44    24  bit signal pack into four byte
    0x45    32 bit signal pack into five byte
    0x0x    uint8[x], uint32[x], uint16[x], sint8[x], sint32[x], sint16[x]
    To determine how many bytes a particular data spreads across depends on the
    following characteristics:
    DcmDspDataSize, DcmDspDidDataPos.
    For example, if the DcmDspDidDataPos is 6, and DcmDspDataSize is 8, then
    the data begins at 6th bit in the response and ends at the 14th bit.
    Hence it spreads across 2 bytes.
    Incremental implementation:
    Endianness also plays a role in this but this will be done in the next
    cycles. Right now we are only considering Little Endian signals in a
    Little Endian System.

    */
  PduLengthType ddSigTypeOrSize;

  /* Index of the write function pointer array. Generation tool should allocate
  the array index based on the type of the signal and size of the network signal
  that is spread across an I-PDU.



  There shall be following pack functions:
  Dcm_PackOneByte: For packing data of less than or equal to one byte. For
  this ucWrFuncIndex shall be 0.
  Dcm_PackBytes: For packing data that spread across 2 and 4 bytes. For
  this ucWrFuncIndex shall be 1.
  Dcm_PackFiveBytes: For packing data that spread across 5 bytes. For
  this ucWrFuncIndex shall be 2.
  Dcm_PackByteOrdering: For packing data that spread across 2 and 4 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 3.
  Dcm_PackFiveByteOrdering: For packing data that spread across 5 bytes with
  endianness conversion. For this ucWrFuncIndex shall be 4.
  Dcm_PackNBytes: For packing uint8_n/sint8_n data. For
  this ucWrFuncIndex shall be 5.
  Dcm_Pack2NBytes: For packing uint16_n/sint16_n data. For
  this ucWrFuncIndex shall be 6.
  Dcm_Pack4NBytes: For packing uint32_n/sint32_n data. For
  this ucWrFuncIndex shall be 7.
  Dcm_Pack2NBytesOrdering: For packing uint16_n/sint16_n data with
  endianness conversion. For this ucWrFuncIndex shall be 8.
  Dcm_Pack4NBytesOrdering: For packing uint32_n/sint32_n data with
  endianness conversion. For this ucWrFuncIndex shall be 9.

  For the example given above (6th starting bit, 8 bits) the ucWrFuncIndex
  shall be 2 i.e., Dcm_PackBytes.

  Endianness conversion becomes necessary if system endianness is different
  from DcmDspDataEndianness. If DcmDspDataEndianness is not configured, the
  endianness of all data shall be derived from DcmDspDataDefaultEndianness.
  System endianness can be found in the system's
  Platform_Types.h as CPU_BYTE_ORDER. If CPU_BYTE_ORDER is HIGH_BYTE_FIRST
  then the endian-ness of the system is BIG_ENDIAN. If it is LOW_BYTE_FIRST,
  then the endianness of the system is LITTLE_ENDIAN.

  Decision pending: How to fetch the system endianness.

  */
  uint8 ucWrFuncIndex;

  /*
    Number of shift bits. Generation tool should generate the value based on
    the offset position in an I-PDU.
    For LE data types: ucNoOfShiftBit means shifting in the starting byte.
    For example, suppose a data begins at 6th bit and is of length 8 bits.
    This means, to fit it in the first byte, we have to shift the data by
    6 bits.

    Extending this example. Suppose instead of 6, the starting bit 13, and
    the size is still 8. This means this data begins in the 2nd byte. In the
    2nd byte, it starts actually from 5th bit. Hence the  ucNoOfShiftBit shall
    be 0x05.

    For BE signals, the logic will be reverse and we will be shifting in the
    last byte of the signal.

    If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

    Hence ucNoOfShiftBit will be considered from the higher byte as 7.

  */
  uint8 ucNoOfShiftBit;

  /*
  Write start mask. Generation tool should generate the value based on the
  start position of the signal in an I-PDU i.e.., lowest byte for
  LE signals and highest byte for BE signals.

  When writing a (part of) data into a byte, we must make sure that the rest
  of the byte remains intact. For this purpose, we have a ucWrStartMask.

  Consider the above example. Data is starting at the 6th bit. It means that the
  first 6 bits could be occupied by another data. Hence we have to have a mask
  to retain that data. Hence this mask shall be 00011111b i.e., 0x1F.

  For BE systems, the StartMask will apply to the higher byte in the frame.

  If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

  Hence ucWrStartMask will be considered from the higher byte as 01111111 i.e.,
  the lowest 7 bits set.


  */
  uint8 ucWrStartMask;

  /*

  Write end mask. Generation tool should generate the value based on the end
  position of the signal in an I-PDU.

  This has the same logic as the ucWrStartMask except for the end byte.


  Consider the below examples.


  For Little Endian data in a Little Endian system:
  Data is starting at the 6th bit and ending
  at 13th bit. It means that the
  last 2 bits in the second byte be occupied by another data.

  Hence we have to have a mask
  to retain that data. Hence this mask shall be 11000000b i.e., 0xC0.

  For Big Endian data in a Little Endian system:
  If the data is starting at the 6th bit and ending
  at 13th bit. It means that the
  last 2 bits in the second byte be occupied by another data.

  Hence we have to have a mask
  to retain that data. Hence this mask shall be 11000000b i.e., 0xC0.

  For BE systems, the StartMask will apply to the higher byte in the frame.

  If there is a BE signal that starts at the 6th bit, it will end in the
    7th bit of the next byte i.e., the 15th bit.

  Hence ucWrStartMask will be considered from the higher byte as 01111111 i.e.,
  the lowest 7 bits set.

  */
  uint8 ucWrEndMask;

}Dcm_TxPackType;

#if(DCM_DSP_SCALINGSERVICE == STD_ON)
#if((DCM_DSP_SCALING_SYNC_FUNC == STD_ON)||\
   (DCM_DSP_SCALING_ASYNC_FUNC == STD_ON)||\
   (DCM_DSP_SCALING_SENDERRECEVIER == STD_ON))
typedef struct STag_Dcm_DspScalingInformation
{
  #if(DCM_DSP_SCALING_SYNC_FUNC == STD_ON)
  /*
   Default value: NULL_PTR.
   If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as DataServices_{Data}_GetScalingInformation where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in pReadSyncScalingData. */
   P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadSyncScalingData)
   (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) pErrorCode
   );
  #endif
  #if(DCM_DSP_SCALING_ASYNC_FUNC == STD_ON)
   /*
   Default value: NULL_PTR.
   If DcmDspDataUsePort is USE_DATA_ASYNCH_CLIENT_SERVER and
   USE_DATA_ASYNCH_CLIENT_SERVER_ERROR this shall
   be generated as DataServices_{Data}_GetScalingInformation where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_ASYNCH_FNC and USE_DATA_ASYNCH_FNC_ERROR,
   it shall be the function name in pReadASyncScalingData. */
   P2FUNC(Std_ReturnType, DCM_APPL_CODE, pReadASyncScalingData)
   (
    Dcm_OpStatusType OpStatus,
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data,
    P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) pErrorCode
   );
  #endif

  #if(DCM_DSP_SCALING_SENDERRECEVIER == STD_ON)
  /*PointerReference to SenderReceiver Array*/
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pDspScalingSRSignal)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );
  #endif

  /*DcmDspScalininfosize*/
  uint32 ulScalingSize;

}Dcm_DspScalingInformation;

/* Design ID : DCM_SDD_6132 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspScalingInformation, DCM_CONST) Dcm_GaaDspDidScalingFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif

typedef struct STag_Dcm_DspDidSignal
{


  /* This pointer shall be used for packing data into the response buffers.
     The type of pack shall depend on characteristics of DcmDspData and also,
     DcmDspDidDataPos. This shall be explained further in Dcm_TxPackType.
     This shall be NULL_PTR if pDspDataRead is also NULL_PTR. Similar conditions
     apply.

     pTxPack can also be NULL_PTR when no processing at all is required. Data
     can directly be copied into the response buffer.

     Processing is not required when the data
     a. Starts at byte boundaries
     b. Fits completely in full, discrete bytes: For example,
        all uint16 bytes that fit in complete 2 bytes and start on byte
        boundaries.
     c. Doesn't require endianness conversion

     All uint8_n, uint8_dyn data does not require any processing.

     For other data types it is necessary to consider the above 3 conditions.

   */
  #if((DCM_DATA_READ_PROCESSING_NECESSARY == STD_ON) && \
    (DCM_DATA_READ_CONFIGURED == STD_ON))
  P2CONST(Dcm_TxPackType, DCM_CONST, DCM_CONST) pTxPack;
  #endif

  #if(DCM_DATA_WRITE_PROCESSING_NECESSARY == STD_ON)
  P2CONST(Dcm_RxUnpackType, DCM_CONST, DCM_CONST) pRxUnpack;
  #endif

  #if(DCM_DATA_READ_CONFIGURED == STD_ON)
  /* Pointer to Dcm_DspDataRead allocated to the
    DcmDspDidSignal->DcmDspDidDataRef or DcmDspDidControl
  configured in this signal.

    pDspDataRead shall be NULL_PTR if the corresponding
    DcmDspDid->DcmDspDidInfo->DcmDspDidRead or DcmDspDid
  ->DcmDspDidInfo->DcmDspDidControl
  is not configured.

    A NULL_PTR means that for this Did, this data cannot be read. It may be read
    from another Did.
   */
  P2CONST(Dcm_DspDataRead, DCM_CONST, DCM_CONST) pDspDataRead;
  #endif

  #if(DCM_DATA_WRITE_CONFIGURED == STD_ON)
  /* Pointer to Dcm_DspDataWrite allocated to the
    DcmDspDidSignal->DcmDspDidDataRef configured in this signal.

    This pointer can be NULL_PTR if for this Did,
    DcmDspDid->DcmDspDidInfo->DcmDspDidWrite is not
    configured.

    A NULL_PTR means that for this Did, this data cannot be written.
    It may be written from another Did.

  For DcmDspDidRange, this shall always be point to the relevant
  Dcm_DspDataWrite if write is configured. More details are provided in
  Dcm_DspDataWrite.
   */
  P2CONST(Dcm_DspDataWrite, DCM_CONST, DCM_CONST) pDspDataWrite;
  #endif
  #if(DCM_DSP_IO_CONTROL == STD_ON)
   /* This element has to be generated as based on the DcmDspDataType
      the value has to generated for each type of signal:
      UINT8  -0x01
      uint16 -0x02
      uint32 -0x03
      uint8_N - the Number of bytes configured.
      uint16_N - the Number of bytes configured
      uint32_N - the Number of bytes configured */

   uint32 UcBytes;

   /* This mask has to to be generated based on the DcmDspDidControlMaskSize
  1)if DcmDspDidControlMaskSize==1
  then ucControlMask has to set the bits  from 7 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 7 th position and 6 th position has
  to be set 0x000000B0
  2)if DcmDspDidControlMaskSize==2
  hen ucControlMask has to set the bits  from 15 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 15 th position and 14 th position
  has to be set 0x0000B000
  3)if DcmDspDidControlMaskSize>=3
  hen ucControlMask has to set the bits  from 15 position until the UcBytes
  i.e., if the UcBytesis  generated as 2 the 15 th position and 14 th position
  has to be set 0xB00000000
    */
   uint32 ucControlMask;
  #endif

  #if(DCM_DSP_SCALINGSERVICE == STD_ON)
  P2CONST(Dcm_DspScalingInformation, DCM_CONST, DCM_CONST) pDspDataScalingFnc;
  #endif

     /* Starting position in the response in bytes.

   For LE data, this will equate to the lowest byte the signal is occupying
   i.e., DcmDspDidDataPos/8.

   For BE data, this will equate to the highest byte the signal is occupying
   in the frame

   For example, suppose an LE signal's DcmDspDidDataPos is 6 and it occupies 8
   bits, ddPosInBytes shall be 0.

   For example, suppose a BE signal's DcmDspDidDataPos is 13 and it occupies 8
   bits, ddPosInBytes shall be the highest byte the signal occupies i.e.,
   2.

   The above rules are an exception when the type is uint32_n, uint16_n,
   sint32_n, sint16_n. Even
   when these types BE endianness configured, ddPosInBytes shall be the lowest
   bytee i.e., DcmDspDidDataPos/8.

   For uint8_n signals which always have OPAQUE endianness,
   ddPosInBytes shall be the lowest byte i.e., DcmDspDidDataPos/8.

   For DcmDspDidRange, this shall always be 0x00.
   */

  PduLengthType ddPosInBytes;

  #if(DCM_DSP_IO_CONTROL == STD_ON)
      /*  ucIOCtrlIndex has to be  allocated to the if
    DcmDspDidSignal->DcmDspDidControl configured in this signal.

    This ucIOCtrlIndex can be 0xFFFF if for this Did,
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl is not
    configured.

    1.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeOne if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize is 0x01
    2.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeTwo if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize is 0x02
    3.The ucIOCtrlIndex has generate the index of
    Dcm_GaaDspIoCtrlMaskSizeFour if the
    DcmDspDid->DcmDspDidInfo->DcmDspDidControl->DcmDspDidControlMaskSize >= 0x03

    More details are provided in Dcm_GaaDspIoCtrlMaskSizeOne,
    Dcm_GaaDspIoCtrlMaskSizeTwo, Dcm_GaaDspIoCtrlMaskSizeFour.

   */
   uint16 ucIOCtrlIndex;
   #endif
}Dcm_DspDidSignal;

/*Design ID : DCM_SDD_0948*/
typedef struct STag_Dcm_DspDid
{
  /* Pointer to the structure Dcm_DspDidInfo allocate for the instance of
     Dcm_DspDidInfo referred by DcmDspDidInfoRef. This is a mandatory
     container hence this pointer shall never be NULL_PTR.

    If this instance of Dcm_GaaDspDid is for DcmDspDidRange, then the reference
    shall be derived from DcmDspDidRange->DcmDspDidRangeInfoRef */
  #if((DCM_DATA_READ_CONFIGURED == STD_ON) ||\
  (DCM_DATA_WRITE_CONFIGURED == STD_ON)||(DCM_DSP_IO_CONTROL == STD_ON))
  P2CONST(Dcm_DspDidInfo, DCM_CONST, DCM_CONST) pDidInfo;
  #endif
  /*
     If DcmDspDidRef is not configured, DcmDspDidSignal instances
     contained in this Did are listed
     sequentially in the structure Dcm_DspDidSignal. This shall point to the
     first of those. DcmDspDidSignal is not a mandatory container.

     If DcmDspDidRef is configured, DcmDspDidSignal configuration
     will be omitted. In this scenario, pDspDidSignal shall point to
     all the signals that referred to by the Did's referred in DcmDspDidRef.

     For example if DcmDspDidRef for DcmDspDid_0 is configured as
     DcmDspDid_1, DcmDspDid_2, and DcmDspDid_3.

     DcmDspDid_1 contains signals DcmDspDidSignal_1, DcmDspDidSignal_2.
     DcmDspDid_2 contains signals DcmDspDidSignal_3, DcmDspDidSignal_4.
     DcmDspDid_3 contains signals DcmDspDidSignal_5, DcmDspDidSignal_6.

     The signals DcmDspDidSignal_1, DcmDspDidSignal_2, DcmDspDidSignal_3
     DcmDspDidSignal_4, and DcmDspDidSignal_6 shall be sequentially filled
     in structure Dcm_DspDidSignal and the starting address provided in
     pDspDidSignal here

     Updated for DcmDspDidRange:
     DcmDspDidRange has no signals. But this design shall be reused for
     DcmDspDidRanges as well. Just one instance of pDspDidSignal shall be
     created for use when a DcmDspDidRange is configured and referred in
     pDspDidSignal. How to generate this signal shall be described
     in Dcm_DspDidSignal. */
  P2CONST(Dcm_DspDidSignal, DCM_CONST, DCM_CONST) pDspDidSignal;

  /* The number of bytes the DcmDspDidSignal's configured for read
     in this DID occupy. This is based on
     DcmDspDidSignal->DcmDspDidDataPos and the
     characteristics of the signal like endianness and size

     Updated for DcmDspDidRange:
     For DcmDspDidRange, ddTotalSignalBytes shall come directly from
     ddTotalSignalBytes.

     */
  PduLengthType ddTotalSignalBytes;

    #if(DCM_DSP_IO_CONTROL  == STD_ON)
     /* This element has to be generated as based on the DcmDspDataType
the value has to generated for each type of signal:
UINT8  -0x01
uint16 -0x02
uint32 -0x03
uint8_N - the Number of bytes configured.
uint16_N - the Number of bytes configured
uint32_N - the Number of bytes configured

The total addition of values has to reflected in ucnoofbytes.
 EX: if signal_0 has uint8,signal_1 has uint16,signal_1 has uint32

 so the value of ucnoofbytes has to generated as 0x06
    */
  uint32 ucnoofbytes;


  /* the position of the  has to generated for the DID's
     DcmDspDid->DcmDspDidInfo->DcmDspDidControl
     else the value 0xFFFF has to generated.   */
  uint16 ucIoCtrlPos;

  #endif

  #if(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)
  /* This position has to be generated  as the dynamic Did
  configured which is in the range of 0xF300 to 0xF3FF
  */
  uint16 ucDcmDynPos;
  /* this element will be generated as DCM_TRUE if the configured DID is dynamic
     Did which is in the range of 0xF300 to 0xF3FF */
  uint8 ucDynamicallyDefined;

  /* this element is generated based on DcmDspDDDIDMaxElements configured for
  dynamic Did, if DID is not in the range of 0xF300 to 0xF3FF then default value
  0xFF will be generated */
  uint8 ucDspDDDIDMaxElements;
  #endif

  #if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
  /* the position of the DID has to generated which is in the range of
     F2000-F2FF else the value 0xFFFF has to generated.   */
  uint8 ucPeriodicPos;

  /* for each DID container if the  DcmDspDid->DcmDspDidControl->DcmDspData the
  parameter DcmDspDataType is configured as uint8_DYN then this element has to
  be generated as DCM_TRUE else DCM_FALSE */
  boolean ulReadLenCheck;
  #endif
  /* The number of instances of DcmDspDidSignal from this Did.

     For DcmDspDidRef, ucNoOfDidSignals shall be the total of all signals in
     the Did's referred via DcmDspDidRef.

     Updated for DcmDspDidRange:
     For DcmDspDidRange, ucNoOfDidSignals shall always be 0x01 since
     only one instance of pDspDidSignal is sufficient.
  */
  uint8 ucNoOfDidSignals;

    /*

    Configuration dependencies:
    DcmDspDid->DcmDspDidSignal->DcmDspDidDataRef->DcmDspDataType:
    DcmDspDid->DcmDspDidRef->DcmDspDidSignal->DcmDspDidDataRef->DcmDspDataType,
    DcmDspDidRange.


    If this instance of  Dcm_DspDid is instantiated for a DID  which is a
    normal DID without any dynamic signals i.e., none of
    the referred DcmDspDidDataRef have DcmDspDataType as uint8_dyn,
    ucDIDType should be generated as DCM_DID_STATIC. If there is at least one
    signal with DcmDspDidDataRef with DcmDspDataType as uint8_dyn
    ucDIDType should be generated as DCM_DID_DYNAMIC.

    If the Did refers to other DIDs via DcmDspDidRef, and if none of the
    referred DcmDspDidRef's have DcmDspDataType as uint8_dyn,
    ucDIDType should be generated as DCM_DID_STATIC. If at least one signal
    has DcmDspDataType as uint8_dyn, ucDIDType should be
    generated as DCM_DID_DYNAMIC.

    If the DID is instantiated for DcmDspDidRange, then ucDIDType shall
    be DCM_DID_RANGE.

  */
 #if( DCM_DATA_WRITE_CONFIGURED == STD_ON)
  uint8 ucDIDType;
  #endif

}Dcm_DspDid;



#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDid, DCM_CONST) Dcm_GaaDspDid[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidSignal, DCM_CONST) Dcm_GaaDspDidSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDataRead, DCM_CONST) Dcm_GaaDspDataRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"




#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDidRead, DCM_CONST) Dcm_GaaDspDidRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#if((STD_ON == DCM_DIDS_PRESENT) || (STD_ON == DCM_READ_DID_SERVICE))
/* Design ID: DCM_SDD_6308 */
typedef struct Stag_Dcm_DspDIDUsedInfo
{
 /* Pointer to Dcm_GaaDspPid Structure */
 P2CONST(Dcm_DspDid, AUTOMATIC, DCM_CONST) pDspDID;

}Dcm_DspDIDUsedInfo;

/* Design ID: DCM_SDD_6321 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspDIDUsedInfo, DCM_CONST) Dcm_GaaDspDidUsed[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

#endif

/******************************************************************************/
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)

#if(DCM_SYNC_DATA_PID_READ_CONFIGURED == STD_ON || \
   DCM_SYNC_CLIENTSERVER_DATA_PID_READ_CONFIGURED== STD_ON)
/*Design ID : DCM_SDD_5051*/
typedef struct STag_Dcm_DspPidSyncFuncs
{
  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.

  If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as DataServices_{Data}_ReadData() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in DcmDspDataReadFnc. */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pPidReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );

}Dcm_DspPidSyncFuncs;

/* Design ID : DCM_SDD_6142 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidSyncFuncs, DCM_CONST) Dcm_GaaDspPidSyncFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
typedef enum
{
  #if(DCM_SYNC_DATA_PID_READ_CONFIGURED == STD_ON || \
   DCM_SYNC_CLIENTSERVER_DATA_PID_READ_CONFIGURED== STD_ON)
  DCM_SYNC_DATA_PID_RAED,
  #endif

  #if(DCM_SR_DATA_PID_READ_CONFIGURED == STD_ON)
  DCM_SR_DATA_PID_READ,
  #endif

  #if(DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON)
  DCM_FREEZEFRAME,
  #endif

  #if(DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)
  DCM_INVALID_PID_ONE = 0xFF
  #endif

}Dcm_DspPidSrcType;
#endif

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
/*Design ID : DCM_SDD_5052*/
typedef struct STag_Dcm_DspPidDataRead
{
   /*
 The read function can be of many types depending on DcmDspPidDataUsePort.
 If DcmDspDataUsePort is
 a. USE_DATA_SYNCH_FNC, USE_DATA_SYNCH_CLIENT_SERVER:  pReadPidOneFromSource
    will point to Dcm_GaaDspPidSendRecFuncs. ucPidOneSourceType shall be
    DCM_SYNC_DATA_PID_RAED.
 b. USE_DATA_SENDER_RECEIVER, USE_DATA_SENDER_RECEIVER_AS_SERVICE:
    pReadDidFromSource will point to Dcm_GaaDspDidSendRecFuncs.
    ucSourceType shall be DCM_SR_DATA_READ.
  */

  #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON))
  /* This element contains the type of source.
  Refer above for details */
  Dcm_DspPidSrcType  ucPidOneSourceType;

  P2CONST(void, DCM_CONST, DCM_CONST) pReadPidOneFromSource;
  #endif

  #if(DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON)
  P2CONST(void, DCM_CONST, DCM_CONST) pReadPidTwoFromSource;
  #endif

}Dcm_DspPidDataRead;


/* Design ID : DCM_SDD_6139 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidDataRead, DCM_CONST) Dcm_GaaDspPidDataRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif



/* Design ID : DCM_SDD_6152 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_TxPackType, DCM_CONST) Dcm_GaaTxPack[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON) || \
  (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
/*Design ID : DCM_SDD_5053*/
typedef struct STag_Dcm_DspPidSignal
{
  /* Starting position in the response in bytes.

  For LE data, this will equate to the lowest byte the signal is occupying
  i.e., DcmDspPidDataPos/8.

  For BE data, this will equate to the highest byte the signal is occupying
  in the frame

  For example, suppose an LE signal's DcmDspPidDataPos is 6 and it occupies 8
  bits, ddPosInBytes shall be 0.

  For example, suppose a BE signal's DcmDspPidDataPos is 13 and it occupies 8
  bits, ddPosInBytes shall be the highest byte the signal occupies i.e.,
  2.

  The above rules are an exception when the type is uint32_n, uint16_n,
  sint32_n, sint16_n. Even
  when these types BE endianness configured, ddPosInBytes shall be the lowest
  bytee i.e., DcmDspPidDataPos/8.

  For uint8_n signals which always have OPAQUE endianness,
  ddPosInBytes shall be the lowest byte i.e., DcmDspDidDataPos/8.

  For DcmDspDidRange, this shall always be 0x00.
  */
  #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON))
  PduLengthType ddPosInBytesServiceOne;
  #endif

  #if((DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON))
  PduLengthType ddPosInBytesServiceTwo;
  #endif
    /* This pointer shall be used for packing data into the response buffers.
     The type of pack shall depend on characteristics of DcmDspData and also,
     DcmDspDidDataPos. This shall be explained further in Dcm_TxPackType.
     This shall be NULL_PTR if pDspDataRead is also NULL_PTR. Similar conditions
     apply.

     pTxPack can also be NULL_PTR when no processing at all is required. Data
     can directly be copied into the response buffer.

     Processing is not required when the data
     a. Starts at byte boundaries
     b. Fits completely in full, discrete bytes: For example,
        all uint16 bytes that fit in complete 2 bytes and start on byte
        boundaries.
     c. Doesn't require endianness conversion

     All uint8_n, uint8_dyn data does not require any processing.

     For other data types it is necessary to consider the above 3 conditions.
  */
   #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON) && \
      (DCM_DSP_PID_DATA_PROCESSING == STD_ON))
    P2CONST(Dcm_TxPackType, DCM_CONST, DCM_CONST) pTxPack;
  #endif



  /* Pointer to Dcm_DspPidDataRead allocated to the
    DcmDspDidSignal->DcmDspDidDataRef configured in this signal.

    pDspDataRead shall be NULL_PTR if the corresponding
    DcmDspDid->DcmDspDidInfo->DcmDspDidRead is not configured.

    A NULL_PTR means that for this Did, this data cannot be read. It may be read
    from another Did.
  */
  P2CONST(Dcm_DspPidDataRead, DCM_CONST, DCM_CONST) pDspPidDataRead;

  #if((DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON))
  uint8   ddDemPidDataElementIndex;
  #endif

  #if(DCM_DSP_SUPOORTINFO== STD_ON)
  uint8 ucDspPidSupportInfoPos;

  uint8 ucDspPidSupportInfo;
  #endif
}Dcm_DspPidSignal;

/* Design ID : DCM_SDD_6141 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidSignal, DCM_CONST) Dcm_GaaDspPidSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
/*Design ID : DCM_SDD_5054*/
typedef struct STag_Dcm_DspPid
{
  /*
     sequentially in the structure Dcm_DspPidSignal. This shall point to the
     first of those. Dcm_DspPidSignal is a mandatory container.

     DcmDspPid_1 contains signals DcmDspPidSignal_1, DcmDspPidSignal_2.
     DcmDspPid_2 contains signals DcmDspPidSignal_3, DcmDspPidSignal_4.
     DcmDspPid_3 contains signals DcmDspPidSignal_5, DcmDspPidSignal_6.

     The signals DcmDspPidSignal_1, DcmDspPidSignal_2, DcmDspPidSignal_3
     DcmDspPidSignal_4, and DcmDspPidSignal_6 shall be sequentially filled
     in structure DcmDspPidSignaL and the starting address provided in
     pDspPidSignal here
  */

  P2CONST(Dcm_DspPidSignal, DCM_CONST, DCM_CONST) pDspPidSignal;
  /* The number of bytes the DcmDspDidSignal's configured for read
     in this PID occupy. This is based on
     DcmDspPid->DcmDspPidSize and the
     characteristics of the signal like endianness and size
  */
  uint32 ddTotalSignalBytes;

  /* The number of instances of DcmDspPidData from this Pid.*/
  uint8 ddNoOfPidSgnals;



}Dcm_DspPid;

/* Design ID : DCM_SDD_6138 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPid, DCM_CONST) Dcm_GaaDspPid[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif


#if((STD_ON == DCM_DSP_REQUESTPOWERTRAIN_DATA) || \
                  (STD_ON == DCM_DSP_REQUESTFREEZEFRAME_DATA))
/* Design ID: DCM_SDD_6309 */
typedef struct Stag_Dcm_DspPIDUsedInfo
{
 /* Pointer to Dcm_GaaDspPid Structure */
 P2CONST(Dcm_DspPid, AUTOMATIC, DCM_CONST) pDspPID;

}Dcm_DspPIDUsedInfo;

/* Design ID : DCM_SDD_6316 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPIDUsedInfo, DCM_CONST) Dcm_GaaDspPidUsed[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif
#endif

/* Design ID : DCM_SDD_6324 */
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#if(STD_ON == DCM_DSP_REQUESTPOWERTRAIN_DATA)
#define DCM_START_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
extern CONST(boolean, DCM_CONST) Dcm_GaaSerUsd_OBD01[];
#define DCM_STOP_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
#endif

/* Design ID : DCM_SDD_6325 */
#if(STD_ON == DCM_DSP_REQONBOARDMONITORTEST)
#define DCM_START_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
extern CONST(boolean, DCM_CONST) Dcm_GaaSerUsd_OBD06[];
#define DCM_STOP_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
#endif

/* Design ID : DCM_SDD_6327 */
#if(STD_ON == DCM_DSP_OBDVEHINFO)
#define DCM_START_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
extern CONST(boolean, DCM_CONST) Dcm_GaaSerUsd_OBD09[];
#define DCM_STOP_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
#endif

/* Design ID : DCM_SDD_6326 */
#if(STD_ON == DCM_DSP_REQUESTCONTROL_TESTCOMPONENT)
#define DCM_START_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
extern CONST(boolean, DCM_CONST) Dcm_GaaSerUsd_OBD08[];
#define DCM_STOP_SEC_CONST_BOOLEAN
#include "Dcm_MemMap.h"
#endif
#endif
/*******************************************************************************
**                      Dcm_ConfigType                                        **
*******************************************************************************/
/*Design ID : DCM_SDD_6309 */
/*Design ID : DCM_SDD_5098 */
typedef struct STag_Dcm_ConfigType
{
  #if (DCM_PRE_COMPILE_SINGLE == STD_OFF)

  /* Database start value */
  uint32 ulStartOfDbToc;

  /* Pointer to Protocol related Data */
  P2CONST(Dcm_ProtocolUsedInfo, AUTOMATIC, DCM_CONST) pProtocolRowUsedRef;

  /*Pointer to access Dcm_GaaServiceUsed[] data*/
  P2CONST(Dcm_ServiceUsedInfo, AUTOMATIC, DCM_CONST) pServiceUsed;

  /* Pointer to access Dcm_GaaSubServiceUsed[] data */
  P2CONST(Dcm_SubServiceUsedInfo, AUTOMATIC, DCM_CONST)pSubserviceused;

  #if (DCM_RIDS_PRESENT == STD_ON)
  /* Pointer to Routine related Data */
  P2CONST(Dcm_RoutineUsedInfo, AUTOMATIC, DCM_CONST) pRoutineUsedRef;
  #endif

  #if(DCM_DSP_COM_CHNL_NONE < DCM_DSP_COM_CTRL_ALLCHANNEL)
  /* Pointer to ComControlAllChannel related Data */
  P2CONST(Dcm_DspComControlAllChUsedInfo, AUTOMATIC, DCM_CONST)
                                                          pComCtrlAllChUsedRef;
  #endif

  #if(DCM_DSP_COM_CHNL_NONE < DCM_DSP_COMMCTRL_SPEC_CHANNEL)
  P2CONST(Dcm_DspCommControlspecificType, AUTOMATIC, DCM_CONST)
                                                      pComCtrlSpecChnlUsedRef;
  #endif

  #if(DCM_DSP_COM_CHNL_NONE < DCM_DSP_COMCTRL_SUBNODE)
  P2CONST(Dcm_DspComControlSubNode, AUTOMATIC, DCM_CONST)
                                                      pComCtrlSubNodeUsedRef;
  #endif

  #if((STD_ON == DCM_DSP_REQUESTPOWERTRAIN_DATA) || \
(STD_ON == DCM_DSP_REQUESTFREEZEFRAME_DATA)||(STD_ON == DCM_RDTCREADOBDFF_DATA))
  P2CONST(Dcm_DspPIDUsedInfo, AUTOMATIC, DCM_CONST) pDspPidUsed;
  #endif

  #if((STD_ON == DCM_DIDS_PRESENT) || (STD_ON == DCM_READ_DID_SERVICE))
  P2CONST(Dcm_DspDIDUsedInfo, AUTOMATIC, DCM_CONST) pDspDidUsed;
  #endif

  #if((DCM_DSP_ENABLEOBDMIRROR == STD_OFF)&&(DCM_READ_DID_SERVICE == STD_ON)\
  &&(DCM_OBD_POWERTRAIN_DIDS == STD_ON))
  P2CONST(Dcm_DspAviliabiltyReqId, AUTOMATIC, DCM_CONST) pAvailDIDF4;
  #endif

  #if((DCM_DSP_ENABLEOBDMIRROR == STD_OFF)&&(DCM_READ_DID_SERVICE == STD_ON)\
  &&(DCM_OBD_INFOTYPE_DIDS == STD_ON))
  P2CONST(Dcm_DspAviliabiltyReqId, AUTOMATIC, DCM_CONST) pAvailDIDF8;
  #endif

  #if((STD_OFF == DCM_DSP_ENABLEOBDMIRROR) && (DCM_RIDS_PRESENT == STD_ON)\
  &&(DCM_OBD_ROUTINE == STD_ON))
  P2CONST(Dcm_DspAviliabiltyReqId, AUTOMATIC, DCM_CONST) pAvailRID;
  #endif

  #if(STD_ON == DCM_DSP_REQUESTPOWERTRAIN_DATA)
  P2CONST(Dcm_DspAviliabiltyReqId, AUTOMATIC, DCM_CONST) pAvailPID_Serv01;
  #endif

  #if(STD_ON == DCM_DSP_REQUESTFREEZEFRAME_DATA)
  P2CONST(Dcm_DspAviliabiltyReqId, AUTOMATIC, DCM_CONST) pAvailPID_Serv02;
  #endif

  #if((STD_ON == DCM_DSP_REQUESTPOWERTRAIN_DATA) \
  && (STD_ON == DCM_READ_DID_SERVICE))
  P2CONST(boolean, AUTOMATIC, DCM_CONST) pServUsed_OBD01;
  #endif

  #if((STD_ON == DCM_DSP_REQONBOARDMONITORTEST) \
  && (STD_ON == DCM_READ_DID_SERVICE))
  P2CONST(boolean, AUTOMATIC, DCM_CONST) pServUsed_OBD06;
  #endif

  #if((STD_ON == DCM_DSP_OBDVEHINFO)\
  && (STD_ON == DCM_READ_DID_SERVICE))
  P2CONST(boolean, AUTOMATIC, DCM_CONST) pServUsed_OBD09;
  #endif

  #if((STD_ON == DCM_DSP_REQUESTCONTROL_TESTCOMPONENT)\
  && (STD_ON == DCM_RIDS_PRESENT))
  P2CONST(boolean, AUTOMATIC, DCM_CONST) pServUsed_OBD08;
  #endif

    /*Variant*/
    uint8 ucReqVariant;

  #else /*(DCM_PRE_COMPILE_SINGLE == STD_OFF)*/

  uint8 LucDummy;
  #endif  /*(DCM_PRE_COMPILE_SINGLE == STD_OFF)*/
}Dcm_ConfigType;

#if (DCM_PRE_COMPILE_SINGLE == STD_OFF)

/* Design ID: DCM_SDD_6322 */
#define DCM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

/* Configset Structure */
extern CONST(Dcm_ConfigType, DCM_CONST) Dcm_GaaConfig[DCM_NUMBER_OF_CONFIGSET];

#define DCM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif



#endif /* DCM_PBTYPES_H */

/*******************************************************************************
**                                End of File                                 **
*******************************************************************************/
