/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspUDSServices.h                                          **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsl Structure definitions                        **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPUDSSERVICE_H
#define DCM_DSPUDSSERVICE_H

#include "Dcm_Cfg.h"
#if(DCM_PRE_COMPILE_SINGLE == STD_OFF)
#include "Dcm_PBcfg.h"
#include "Dcm_Lcfg.h"
#endif
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DspDidConfig.h"
/*******************************************************************************
**                      Macro Definitions                                     **
*******************************************************************************/
/* Possible values of ucReqState for SecurityAccess  */
#define DCM_DSP_NO_SEC_ACCESS (uint8)0x00
#define DCM_DSP_SEED_SENT_NO_CONF (uint8)0x01
#define DCM_DSP_GET_SEED_IN_MAIN (uint8)0x02
#define DCM_DSP_SEND_KEY_EXPECTED (uint8)0x03
#define DCM_DSP_COMPARE_KEY_IN_MAIN (uint8)0x04
#define DCM_DSP_KEY_VALID_NO_CONF (uint8)0x05
/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/
#if(DCM_DSP_CTRL_DTC_SETTING == STD_ON)
#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
/*This global variable is to know whether the ControlDTCSetting service request
 with DTCSetting equal to Off is received and processed successfully*/
extern VAR(boolean, DCM_VAR) Dcm_GblDTCSettingDisabled;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)
/*Design ID : DCM_SDD_0962*/
typedef struct STag_Dsp_SecAccessData
{
  /* Storing the security level because we needn't calculate SecLevel again */
  uint8 ucRequestedSecLevel;

  /*
    State of the request. The possible values are:
    a. DCM_DSP_NO_SEC_ACCESS: Nothing to be done asynchronously or in
    confirmation
    b. DCM_DSP_SEED_SENT_NO_CONF: Seed sent, confirmation expected
    c. DCM_DSP_GET_SEED_IN_MAIN: Xxx_GetSeed() again to be called asynchronously
    d. DCM_DSP_SEND_KEY_EXPECTED: Seed sent, key expected
    e. DCM_DSP_COMPARE_KEY_IN_MAIN: Xxx_CompareKey() again to be called
    asynchronously
    e. DCM_DSP_KEY_VALID_NO_CONF: Key validated, confirmation expected for the
    key
  */
  uint8 ucReqState;
}Dsp_CurrentSecAccess;

#define DCM_START_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
extern VAR(Dsp_CurrentSecAccess, DCM_VAR_INIT) Dsp_GstCurrentSecAccess;
#define DCM_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/

#if(DCM_DSP_SECURITY_ACCESS_SERVICE == STD_ON)

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dsp_BootDelayTimerScheduled(void);

extern FUNC(void, DCM_CODE) Dsp_AttemptCounterScheduled(void);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspSecurityAccessInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspSecurityAccessConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspSecurityAccessRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE)
  Dcm_DspSecurityAccessScheduled
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
      Dcm_OpStatusType Opstatus);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DSP_SECURITY_ADR == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dsp_ValidateKey
(
  P2CONST(Dcm_DspSecurityRow, AUTOMATIC, DCM_CONST) pSecurityRow,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dsp_ProcessSendKey
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSecurityRow, AUTOMATIC, DCM_CONST) pSecurityRow,
  uint8 SecLevel
);

extern FUNC(void, DCM_CODE) Dsp_SendZeroSeed
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  uint32 SeedSize
);

extern FUNC(void, DCM_CODE) Dsp_SendNewSeed
(
  P2CONST(Dcm_DspSecurityRow, AUTOMATIC, DCM_CONST) pSecurityRow,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  uint8 SecLevel,
  Dcm_OpStatusType OpStatus
);

extern FUNC(boolean, DCM_CODE) Dsp_ValidateSecurityAccessTimers
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSecurityRow, AUTOMATIC, DCM_CONST) pSecurityRow
);
extern FUNC(void, DCM_CODE) Dsp_ProcessRequestSeed
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSecurityRow, AUTOMATIC, DCM_CONST) pSecurityRow,
  uint8 SecLevel
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_NUM_SECROWS_WITH_ATTEMPT_CNTR_EXT_STR > DCM_ZERO)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(boolean, DCM_CODE) Dsp_AttemptCounterInit(Dcm_OpStatusType
  OpStatus);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#endif

#if(((DCM_DSD_SERVICE_FNC == STD_ON)||(DCM_DSD_SUB_SERVICE_FNC == STD_ON))\
  &&(DCM_NUM_OF_PROTOCOLS > DCM_ONE))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_Protocolpremptimer(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_TransmitGeneralReject(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#if((DCM_DSD_SERVICE_FNC == STD_ON) || (DCM_DSD_SUB_SERVICE_FNC == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_ExternalServiceProcessingInd
(
  Dcm_OpStatusType OpStatus,
  CONSTP2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif




#if((DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON) ||\
   (DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(boolean, DCM_CODE)Dcm_Didvalidation(uint16 DID);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"


extern FUNC(void, DCM_CODE) Dcm_UnpackDTC
(
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pReqData,
  P2VAR(uint32, AUTOMATIC, DCM_VAR) DTC
);
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspTesterPresentInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
extern FUNC(void, DCM_CODE) Dcm_DspTesterPresentConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_ConfirmationStatusType ConfirmationStatus
);
extern FUNC(void, DCM_CODE) Dcm_DspTesterPresentScheduled
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspTesterPresentRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"


#if(DCM_DSP_DIAG_SESSION_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspDiagSesCtrlRespAssemble
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSessionRowType, AUTOMATIC, DCM_CONST)LpSessionRow
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspDiagSesCtrlInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspDiagSesCtrlConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_ConfirmationStatusType ConfirmationStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspDiagSesCtrlRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE)
  Dcm_DspDiagSesCtrlScheduled
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
      Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspBLFullCom(void);

extern FUNC(void, DCM_CODE) Dcm_DspBLOrJumpFromBL(void);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_DIAG_SESSION_SERVICE == STD_ON)&& \
     (DCM_DSP_DIAG_SESSION_BOOT_CONFIGURED == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
/*Design ID : DCM_SDD_6100*/
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspBootloaderExecute
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSessionRowType, AUTOMATIC, DCM_CONST)pSessionRow
);

extern  FUNC(Std_ReturnType, DCM_CODE) Dcm_DspJumpToBootloader
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2CONST(Dcm_DspSessionRowType, AUTOMATIC, DCM_CONST)pSessionRow);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#if(DCM_DSP_COMM_CTRL_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspComMCtrlRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result);

extern FUNC(void, DCM_CODE)Dcm_DspCommCtrlScheduled
(Dcm_MsgContextType* pMsgContext,
 Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_CommunicationCtrlConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspCommunicationCtrlInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspComMCtrlSesTrans
(Dcm_SesCtrlType SesCtrlType);

extern FUNC(void, DCM_CODE)Dcm_DslComContrlConn
(Dcm_CommunicationModeType ComType);


extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspComCtrlComSpec
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext, uint8 subnetbyte);

extern FUNC(void, DCM_CODE)Dcm_DspComCtrlResponse(P2VAR(Dcm_MsgContextType,
   AUTOMATIC, DCM_VAR)pMsgContext);

extern FUNC(void, DCM_CODE)Dcm_DspComCtrlInterConf
(Dcm_CommunicationModeType LddComType);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspWriteDataByIDInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspWriteDataByIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspWriteDataByIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE)
  Dcm_DspWriteDataByIDScheduled
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReadDataByIDInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDataByIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(uint8, DCM_CODE) Dcm_ValidateReadDID
(
  uint16 ReqDID,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(boolean, DCM_CODE) Dcm_DspScheduledProcessDID
(
  uint16 ReqDID,
  P2VAR(uint8, AUTOMATIC, DCM_VAR)pDidData,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
  Dcm_OpStatusType Opstatus,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(uint8, DCM_CODE) Dcm_ProcessDID
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDataByIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE)
  Dcm_DspReadDataByIDScheduled
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE)
  Dcm_DspRdbiObdServices
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspEcuResetNoReqAc(void);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspEcuResetInd
 ( Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext );

 extern FUNC(void, DCM_CODE) Dcm_DspEcuResetConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE)Dcm_DspEcuResetScheduled
(Dcm_MsgContextType* pMsgContext,
 Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspEcuResetRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DSP_READ_DTC == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspReadDTCInfoConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDTCInfoRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspReadDTCInfoScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReadDTCInfoInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)Dcm_DspMemoryConv(
P2VAR(uint8, AUTOMATIC, DCM_VAR)Src, uint8 size, uint32 *Dest);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DSP_CLEAR_DTC_DIAG_INFO == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspClearDTCRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspClearDTCInfoConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspClearDTCInfoInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspDemClearDTC
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext, uint32 gropofDTC);

extern FUNC(void, DCM_CODE)Dcm_DspClearDTCInfoScheduled
(Dcm_MsgContextType* pMsgContext,
 Dcm_OpStatusType Opstatus);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_RIDS_PRESENT==STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspRoutineControlInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspRoutineControlScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType Opstatus
);

extern FUNC(void, DCM_CODE) Dcm_DspRoutineControlConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspRoutineControlRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_CTRL_DTC_SETTING == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
 extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspCtrlDTCsettingInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspEnableDTCSetting
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,uint32 groupDTC,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspDisableDTCSetting
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,uint32 groupDTC
);
extern FUNC(void, DCM_CODE) Dcm_DsdCtrlDTCSesValidation
(
  uint32 ServiceSesVector,
  Dcm_SesCtrlType CurrentSession
);

extern FUNC(void, DCM_CODE)Dcm_DspCtrlDTCsettingScheduled
(Dcm_MsgContextType* pMsgContext, Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspCtrlDTCsettingConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);
extern FUNC(void, DCM_CODE) Dcm_DspCtrlDTCsettingRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif


#if((DCM_DSP_REQ_DOWNLOAD == STD_ON) || (DCM_DSP_REQ_UPLOAD == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspRequestDownloadInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspProcessCall
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE)Dcm_DspReqDownResponse
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext, uint32 BlockLength);

extern FUNC(void, DCM_CODE)Dcm_DspMemoryConvUint8(
P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8 size, uint8 *Dest);

extern FUNC(void, DCM_CODE)Dcm_DspRequestDownloadScheduled
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE) Dcm_DspRequestDownloadRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspRequestDownloadConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_TRANSFER_DATA_SERVICE == STD_ON)

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspTransferDataInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspTransferDataScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspTransferDataRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspTransferDataConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif


#if(DCM_ROE_SERVICE_CONFIGURED == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspEnableRoeDefSes
(
  void
);

extern FUNC(void, DCM_CODE) Dcm_DspDisableRoeNonDefSes
(
  void
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspROEInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspROEScheduled
(Dcm_MsgContextType* pMsgContext, Dcm_OpStatusType Opstatus);

extern FUNC(void, DCM_CODE) Dcm_DspROEConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);
extern FUNC(void, DCM_CODE) Dcm_DspROERPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReadMemoryByAddrInd
    (
      Dcm_OpStatusType OpStatus,
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
    );

extern FUNC(void, DCM_CODE)Dcm_DspReadMemoByAddrScheduled
    (Dcm_MsgContextType* pMsgContext, Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE)Dcm_DspReadCall
    (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
      Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE) Dcm_DspReadMemoByAddrRPConf
    (
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
      Std_ReturnType LucResult
    );

extern FUNC(void, DCM_CODE) Dcm_DspReadMemoByAddrConf
    (
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
      Dcm_OpStatusType OpStatus
    );
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspWriteMemoryByAddrInd
    (
      Dcm_OpStatusType OpStatus,
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
    );

extern FUNC(void, DCM_CODE)Dcm_DspWriteMemoByAddrScheduled
    (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR)pMsgContext,
     Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE)Dcm_DspWriteCall
  (P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
    Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE) Dcm_DspWriteMemoByAddrRPConf
    (
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
      Std_ReturnType LucResult
    );

extern FUNC(void, DCM_CODE) Dcm_DspWriteMemoByAddrConf
    (
      P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
      Dcm_OpStatusType OpStatus
    );
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_READ_PERIODIC_IDENTIFIER_SERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)Dcm_DspDisablePeriodicTx(void);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ReadPeriodicDataByIdentifier
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspReadperiodicDataByIDScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspReadPeriodicDataByIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus );

  extern FUNC(void, DCM_CODE) Dcm_DspReadPeriodicDataByIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_StopTransCheck
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  uint32 LucDidNum
);

extern FUNC(boolean, DCM_CODE)Dcm_DspSeSSecCheck(uint16 DIDIndex);

extern FUNC(void, DCM_CODE)Dcm_LienarRemDID(uint8 DIDIndex);

extern FUNC(void, DCM_CODE)Dcm_PeriodicMemCpy(
P2VAR(uint8, AUTOMATIC, DCM_VAR) Src,
P2VAR(uint8, AUTOMATIC, DCM_VAR) Dest,
       uint32 Length);

extern FUNC(boolean, DCM_CODE) Dcm_LinearSearch(uint16 DID);

extern FUNC(void, DCM_CODE)
  Dcm_DspPeriodicTImer(uint8 DidIndex,uint8 TransMode);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_InBuffCheck(
  P2VAR(uint8, AUTOMATIC, DCM_VAR)reqData, VAR(uint32, DCM_VAR)LulDidNum);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_REQ_DOWNLOAD == STD_ON) ||\
    (DCM_DSP_REQ_UPLOAD == STD_ON) ||\
   (DCM_DSP_READ_MEMORY_BY_ADD == STD_ON)||\
     (DCM_DSP_WRITE_MEMORY_BY_ADD == STD_ON)||\
     (DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON))
#if((DCM_DSP_WRITE_MEM_RANGE_INFO == STD_ON)||\
    (DCM_DSP_READ_MEM_RANGE_INFO == STD_ON))

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspMemValidation(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
VAR(uint32, DCM_VAR) LulMemoryAddress,VAR(uint8, DCM_VAR) LucMemoryAdressbytes,
VAR(uint8, DCM_VAR) LucMemoryStatus);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspAddrValidate(
  VAR(uint8, DCM_VAR) LucMemoryStatus);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

#if((DCM_DSP_MEMORY_INFO == STD_ON)||(DCM_DSP_MEM_IDS_ONLY == STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)Dcm_MemIdValidate(
  P2VAR(uint16, AUTOMATIC, DCM_VAR) LusMemId,
   VAR(uint8, DCM_VAR) LucMemoryStatus,
    VAR(uint8, DCM_VAR) LucMemoryAdressbytes,
    P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#endif


#if(DCM_DSP_IO_CONTROL == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspIoSesTrans
(
  Dcm_SesCtrlType session
);
extern FUNC(void, DCM_CODE) Dcm_DspIoCtrlRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspIOCtrlConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);
extern FUNC(void, DCM_CODE) Dcm_DspIoCtrlScheduled
  (Dcm_MsgContextType* pMsgContext,
   Dcm_OpStatusType Opstatus);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspIoCntrlInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_TRANSFER_EXIT_SERVICE == STD_ON)

#define DCM_START_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"
extern VAR(boolean, DCM_VAR_INIT) Dcm_GblTransferExitPending;
#define DCM_STOP_SEC_VAR_INIT_BOOLEAN
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE)Dcm_DspCallTransferExit
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
 Dcm_OpStatusType OpStatus);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspTransferExitInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspTransferExitScheduled
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspTransferExitRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_DspTransferExitConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

#if((DCM_DSP_REQ_DOWNLOAD == STD_ON) || (DCM_DSP_REQ_UPLOAD == STD_ON) || \
  (DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)|| \
         (DCM_TRANSFER_DATA_SERVICE == STD_ON))

#define DCM_START_SEC_VAR_INIT_16
#include "Dcm_MemMap.h"
extern VAR(uint16, DCM_VAR_INIT) Dcm_GucBlkSeqCounter;
#define DCM_STOP_SEC_VAR_INIT_16
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_INIT) Dcm_GucTransferStart;
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"

#define DCM_START_SEC_VAR_CLEARED_32
#include "Dcm_MemMap.h"
/* Initialise Global BlockSequenceCounter to 0x01 as per ISO -14229 page 281 and
   Table 404 */
extern VAR(uint32, DCM_VAR) DCM_GulDspMemAddres;
#define DCM_STOP_SEC_VAR_CLEARED_32
#include "Dcm_MemMap.h"


#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_DspWriteTransferData
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  uint8 LucMemId, uint32 LulMemAddress, uint32 LulMemSize, uint8* LpWriteData,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SrcElementsValidation
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  uint16 DDDIDIndex,
  uint8 ProcessOrValid,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus,
  boolean NegRespFlag
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if(DCM_DYNAMIC_DEFINED_INDENTIFIER == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspUDSDynamicallyDefDIDInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspUDSDynamicallyDefDIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspUDSDynamicallyDefDIDScheduled
(
  Dcm_MsgContextType* pMsgContext,
  Dcm_OpStatusType Opstatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_DspUDSDynamicallyDefDIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(void, DCM_CODE) Dcm_InitializeDDID(void);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

#if(DCM_DSP_REQUEST_FILE_TRANSFER == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspRequestFileInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) RequestFileTransferCall
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_RequestFileLengthCheck
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_FileValidateLFID(void);

extern FUNC(void, DCM_CODE) Dcm_RequestFileFetchInputs
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_FileTransferReturnValidate
(
  Dcm_OpStatusType OpStatus,
  VAR(Std_ReturnType, DCM_VAR) Lddreturnvalue,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  VAR(Dcm_NegativeResponseCodeType, AUTOMATIC) LddNRC
);

extern FUNC(void, DCM_CODE) Dcm_RequestFileResponse
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspRequestFileScheduled
(Dcm_MsgContextType* pMsgContext, Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE) Dcm_DspRequestFileRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType LucResult
);

extern FUNC(void, DCM_CODE) Dcm_DspRequestFileConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE)Dcm_MemConvU32ToU8(
P2VAR(uint8, AUTOMATIC, DCM_VAR) Src, uint8_least size, uint8 *Dest);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspRequestProcess
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif

#if(DCM_DSP_REQ_UPLOAD == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspRequestUploadInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE)Dcm_DspRequestUploadScheduled
(
P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
Dcm_OpStatusType OpStatus
);

extern FUNC(void, DCM_CODE) Dcm_DspRequestUploadRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);
extern FUNC(void, DCM_CODE) Dcm_DspRequestUploadConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif


#if(DCM_DSP_SCALINGSERVICE == STD_ON)
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackScalingAsyncData
(
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackScalingSRData
(
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame
);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackScalingSyncData
(
  P2CONST(Dcm_DspDidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentDidFrame,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(void, DCM_CODE) Dcm_DspReadScalingDataByIDScheduled
  (Dcm_MsgContextType* pMsgContext,
   Dcm_OpStatusType OpStatus);

extern FUNC(void, DCM_CODE) Dcm_DspReadScalingDataByIDConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Dcm_OpStatusType OpStatus
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspReadScalingDataByIDInd
(
  Dcm_OpStatusType OpStatus,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(void, DCM_CODE) Dcm_DspReadScalingDataByIDRPConf
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_APPL_DATA) pMsgContext,
  Std_ReturnType result
);

extern FUNC(void, DCM_CODE) Dcm_ValidateScalingInformation
(
  P2CONST(Dcm_DspDid, AUTOMATIC, DCM_CONST)LpDidConfig,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(uint8, DCM_CODE) Dcm_ValidateReadScalingDID
(
  uint16 ReqDID,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);

extern FUNC(void, DCM_CODE) Dcm_ProcessScalingDID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_CODE) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC,
  Dcm_OpStatusType OpStatus
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#endif

#endif

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
