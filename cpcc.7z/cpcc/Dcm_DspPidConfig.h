/*******************************************************************************
**                      KPIT Technologies Limited                             **
**                                                                            **
** KPIT Technologies Limited owns all the rights to this work. This work      **
** shall not be copied, reproduced, used, modified or its information         **
** disclosed without the prior written authorization of KPIT Technologies     **
** Limited.                                                                   **
**                                                                            **
**  SRC-MODULE: Dcm_DspPidConfig.h                                            **
**                                                                            **
**  TARGET    : All                                                           **
**                                                                            **
**  PRODUCT   : AUTOSAR Diagnostic Communication Manager Module               **
**                                                                            **
**  PURPOSE   : Provision of Dsp Structure definitions for Service            **
**              Request Current PowerTrainData(0x01)                          **
**                                                                            **
**  PLATFORM DEPENDANT [yes/no]: no                                           **
**                                                                            **
**  TO BE CHANGED BY USER [yes/no]: no                                        **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
**                      Revision History                                      **
********************************************************************************
** Revision  Date          Changed By           Description                   **
********************************************************************************
** 1.2.0     31-Oct-2019   Sathyanarayana AH    As per CR #555, #564          **
** 1.1.0     06-Jun-2019   Sathyanarayana AH    As per CR #388                **
** 1.0.0     07-Jan-2019   Sathyanarayana AH    Initial version DCM 4.2.2     **
*******************************************************************************/
#ifndef DCM_DSPPIDCONFIG_H
#define DCM_DSPPIDCONFIG_H

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Dcm_Types.h"
#include "Dcm_DspInternalTypes.h"
#include "Dcm_DspDidConfig.h"
#include "NvM.h"


/*******************************************************************************
**                      Macro Definitions                                     **
**                  Design ID : DCM_SDD_5130                                  **
*******************************************************************************/
#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
#define DCM_INVALID_PID 0xFFu
#endif

/*******************************************************************************
**                      Global Data                                           **
*******************************************************************************/


typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_ReqIdValidate)
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);




#if((DCM_DSP_ENABLEOBDMIRROR == STD_OFF) &&\
(DCM_READ_DID_SERVICE == STD_ON))
/* Design ID : DCM_SDD_6120 */

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyUDSInfoType[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#else

#define DCM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyUDSInfoType[];
#define DCM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

#endif

#if((DCM_DSP_ENABLEOBDMIRROR == STD_OFF) &&\
(DCM_RIDS_PRESENT == STD_ON))
/* Design ID : DCM_SDD_6119 */
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)

#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId, DCM_CONST)Dcm_GaaDspAviliabiltyRID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#else

#define DCM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId, DCM_CONST)Dcm_GaaDspAviliabiltyRID[];
#define DCM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif

#endif


#define DCM_START_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR_CLEAR) Dcm_GucCurrentReqIdIndex;
#define DCM_STOP_SEC_VAR_CLEARED_8
#include "Dcm_MemMap.h"

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
 (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON) ||(DCM_RDTCREADOBDFF_DATA == STD_ON))

#if (DCM_DSP_PID_DATA_PROCESSING == STD_ON)
/*Design ID : DCM_SDD_6188*/
#define DCM_START_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
extern VAR(uint8, DCM_VAR) Dcm_GaaOBDTempReadData[DCM_FOUR_U8];
#define DCM_STOP_SEC_VAR_INIT_8
#include "Dcm_MemMap.h"
#endif

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
                        (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
typedef enum
{
  #if(DCM_SYNC_DATA_PID_READ_CONFIGURED == STD_ON || \
   DCM_SYNC_CLIENTSERVER_DATA_PID_READ_CONFIGURED== STD_ON)
  DCM_SYNC_DATA_PID_RAED
  #endif

  #if(DCM_SR_DATA_PID_READ_CONFIGURED == STD_ON)
  ,DCM_SR_DATA_PID_READ
  #endif

  #if(DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON)
  ,DCM_FREEZEFRAME
  #endif

  #if(DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)
  ,DCM_INVALID_PID_ONE = 0xFF
  #endif

}Dcm_DspPidSrcType;
#endif
#endif

/*Design ID : DCM_SDD_6547*/
#define DCM_START_SEC_CONST_8
#include "Dcm_MemMap.h"
extern CONST(uint8, DCM_CONST)Dcm_GaaPID[];
#define DCM_STOP_SEC_CONST_8
#include "Dcm_MemMap.h"

#if(DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)

/*Design ID : DCM_SDD_6199*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyPID_One[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#else

#define DCM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspAviliabiltyReqId,
DCM_CONST)Dcm_GaaDspAviliabiltyPID_One[];
#define DCM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif
#endif

#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if(DCM_SYNC_DATA_PID_READ_CONFIGURED == STD_ON || \
   DCM_SYNC_CLIENTSERVER_DATA_PID_READ_CONFIGURED== STD_ON)
/*Design ID : DCM_SDD_5051*/
typedef struct STag_Dcm_DspPidSyncFuncs
{
  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.

  If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as DataServices_{Data}_ReadData() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in DcmDspDataReadFnc. */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pPidReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );

}Dcm_DspPidSyncFuncs;

/* Design ID : DCM_SDD_6142 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidSyncFuncs, DCM_CONST) Dcm_GaaDspPidSyncFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif
#endif

/**
  Name: Dcm_GaaDspPidDataRead[]
  Type: DcmDspPidData, DcmDspPid
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspPidData, DcmPidUsed
  Generation Description: The array of structures contains information
  about all the instances of DspPidData i.e.,
  DcmDspPidData configured. For every instance of DcmDspPidData
  instance of this array is instantiated if at least one instance
  DcmDspPidRead with DcmPidUsed true is configured.
  Sorting: Sorting is independent of any structure
**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
 (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON) ||(DCM_RDTCREADOBDFF_DATA == STD_ON))
/*Design ID : DCM_SDD_5052*/
typedef struct STag_Dcm_DspPidDataRead
{

  /*
     The read function can be of many types depending on DcmDspPidDataUsePort.
     If DcmDspDataUsePort is
     a. USE_DATA_SYNCH_FNC, USE_DATA_SYNCH_CLIENT_SERVER:  pReadPidOneFromSource
        will point to Dcm_GaaDspPidSendRecFuncs. ucPidOneSourceType shall be
        DCM_SYNC_DATA_PID_RAED.
     b. USE_DATA_SENDER_RECEIVER, USE_DATA_SENDER_RECEIVER_AS_SERVICE:
        pReadDidFromSource will point to Dcm_GaaDspDidSendRecFuncs.
        ucSourceType shall be DCM_SR_DATA_READ.
  */
  #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON))
    /* This element contains the type of source.
    Refer above for details */

  Dcm_DspPidSrcType  ucPidOneSourceType;

  P2CONST(void, DCM_CONST, DCM_CONST) pReadPidOneFromSource;
  #endif

#if(DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON)||(DCM_RDTCREADOBDFF_DATA == STD_ON)
  P2CONST(void, DCM_CONST, DCM_CONST) pReadPidTwoFromSource;
#endif

}Dcm_DspPidDataRead;


/* Design ID : DCM_SDD_6139 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidDataRead, DCM_CONST) Dcm_GaaDspPidDataRead[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

#endif
#endif

/**
  Name: Dcm_GaaDspPidSignal[]
  Type: Dcm_DspPid->Dcm_GaaDspPidData,
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspPid, DcmDspPid->Dcm_GaaDspPidData.
  Dcm_DspPid->DcmDspPidUsed
  Generation Description: The array of structures contains information
  about all the instances of Signals i.e.,
  DcmDspPidData configured. For every instance of DcmDspPidSignal
  instance of this array is instantiated.
  Sorting: The sorting of this array depends on Dcm_DspPid and its element
  pDspPidSignal. If for example, a DcmDspPid contains signals
  DcmDspData_1,DcmDspData_2, DcmDspData_2 pDspDidSignal
  shall point to the instance of Dcm_GaaDspPidSignal[] belonging to
  DcmDspData_1 and ucNoOfPidSignals shall be 3. The instances for
  DcmDspData_2 and DcmDspData_3 shall be generated immediately
  following DcmDspDidSignal_1.
  The signal type is always
  assumed to be uint8_n hence Dcm_TxPackType shall be generated accordingly
  for this "signal". No endianness conversion is required either.
  Note: This structure should not be instantiated if DcmDspDidUsed
  is false for this signal.

**/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON) || \
 (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON) ||(DCM_RDTCREADOBDFF_DATA == STD_ON))
/*Design ID : DCM_SDD_5053*/
typedef struct STag_Dcm_DspPidSignal
{
  /* Starting position in the response in bytes.

  For LE data, this will equate to the lowest byte the signal is occupying
  i.e., DcmDspPidDataPos/8.

  For BE data, this will equate to the highest byte the signal is occupying
  in the frame

  For example, suppose an LE signal's DcmDspPidDataPos is 6 and it occupies 8
  bits, ddPosInBytes shall be 0.

  For example, suppose a BE signal's DcmDspPidDataPos is 13 and it occupies 8
  bits, ddPosInBytes shall be the highest byte the signal occupies i.e.,
  2.

  The above rules are an exception when the type is uint32_n, uint16_n,
  sint32_n, sint16_n. Even
  when these types BE endianness configured, ddPosInBytes shall be the lowest
  bytee i.e., DcmDspPidDataPos/8.

  For uint8_n signals which always have OPAQUE endianness,
  ddPosInBytes shall be the lowest byte i.e., DcmDspDidDataPos/8.

  For DcmDspDidRange, this shall always be 0x00.
  */
  #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON))
  PduLengthType ddPosInBytesServiceOne;
  #endif

  #if((DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON) \
                     ||(DCM_RDTCREADOBDFF_DATA == STD_ON))
  PduLengthType ddPosInBytesServiceTwo;
  #endif

  /* This pointer shall be used for packing data into the response buffers.
     The type of pack shall depend on characteristics of DcmDspData and also,
     DcmDspDidDataPos. This shall be explained further in Dcm_TxPackType.
     This shall be NULL_PTR if pDspDataRead is also NULL_PTR. Similar conditions
     apply.

     pTxPack can also be NULL_PTR when no processing at all is required. Data
     can directly be copied into the response buffer.

     Processing is not required when the data
     a. Starts at byte boundaries
     b. Fits completely in full, discrete bytes: For example,
        all uint16 bytes that fit in complete 2 bytes and start on byte
        boundaries.
     c. Doesn't require endianness conversion

     All uint8_n, uint8_dyn data does not require any processing.

     For other data types it is necessary to consider the above 3 conditions.
  */
   #if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON) && \
      (DCM_DSP_PID_DATA_PROCESSING == STD_ON))
    P2CONST(Dcm_TxPackType, DCM_CONST, DCM_CONST) pTxPack;
  #endif



  /* Pointer to Dcm_DspPidDataRead allocated to the
    DcmDspDidSignal->DcmDspDidDataRef configured in this signal.

    pDspDataRead shall be NULL_PTR if the corresponding
    DcmDspDid->DcmDspDidInfo->DcmDspDidRead is not configured.

    A NULL_PTR means that for this Did, this data cannot be read. It may be read
    from another Did.
  */
  P2CONST(Dcm_DspPidDataRead, DCM_CONST, DCM_CONST) pDspPidDataRead;

  #if((DCM_DSP_REQUESTFREEZEFRAME_DATA == STD_ON) \
                   ||(DCM_RDTCREADOBDFF_DATA == STD_ON))
  uint8   ddDemPidDataElementIndex;
  #endif


  #if(DCM_DSP_SUPOORTINFO== STD_ON)
  uint8 ucDspPidSupportInfoPos;

  uint8 ucDspPidSupportInfo;
  #endif
}Dcm_DspPidSignal;

/* Design ID : DCM_SDD_6141 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidSignal, DCM_CONST) Dcm_GaaDspPidSignal[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif
#endif
/**
  Name: Dcm_GaaDspPid[]
  Type: Dcm_DspPid
  Tool Generated?: Yes
  Configuration Dependencies: DcmDspPid, DcmDspPid->DcmDspPidUsed,
  DcmDspPidIdentifier,
  Generation Description:

  The array of structures contains information
  about all the instances of Dids i.e., DcmDspPid
  configured. For DcmDspPid
  with DcmDspPidUsed as true one instance of this array is instantiated.

  Sorting: The sorting of this array depends on Dcm_GaaPID[]. If for
  example, for a DcmDspPid with DcmDspPidIdentifier 0x01, the
  Dcm_GaaPID[] value 0x05, then the 5th element of Dcm_GaaPID
  shall belong to 0x07th Did.

  This array shall exist only number of PIDs is greater than 0 i.e., at least
  one instance of DcmDspDid is configured.
**/

/*Design ID : DCM_SDD_5054*/
#if(DCM_PRE_COMPILE_SINGLE == STD_ON)
typedef struct STag_Dcm_DspPid
{
  /*
     sequentially in the structure Dcm_DspPidSignal. This shall point to the
     first of those. Dcm_DspPidSignal is a mandatory container.

     DcmDspPid_1 contains signals DcmDspPidSignal_1, DcmDspPidSignal_2.
     DcmDspPid_2 contains signals DcmDspPidSignal_3, DcmDspPidSignal_4.
     DcmDspPid_3 contains signals DcmDspPidSignal_5, DcmDspPidSignal_6.

     The signals DcmDspPidSignal_1, DcmDspPidSignal_2, DcmDspPidSignal_3
     DcmDspPidSignal_4, and DcmDspPidSignal_6 shall be sequentially filled
     in structure DcmDspPidSignaL and the starting address provided in
     pDspPidSignal here
  */

  P2CONST(Dcm_DspPidSignal, DCM_CONST, DCM_CONST) pDspPidSignal;


  /* The number of bytes the DcmDspDidSignal's configured for read
  in this PID occupy. This is based on
  DcmDspPid->DcmDspPidSize and the
  characteristics of the signal like endianness and size
  */
  uint32 ddTotalSignalBytes;

  /* The number of instances of DcmDspPidData from this Pid.*/
  uint8 ddNoOfPidSgnals;

}Dcm_DspPid;

/* Design ID : DCM_SDD_6138 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPid, DCM_CONST) Dcm_GaaDspPid[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif



typedef P2FUNC(Std_ReturnType, DCM_CODE, Dcm_PidDataSrcFuncType)
(

  P2CONST(Dcm_DspPidSignal, AUTOMATIC, DCM_CONST) pDidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentPidFrame
);


/*Design ID : DCM_SDD_6071*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_PidDataSrcFuncType, DCM_CONST) Dcm_GaaReadAndPackPidData[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_6548*/
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_ReqIdValidate, DCM_CONST) Dcm_GaaDspProcessPID[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"

/*Design ID : DCM_SDD_5055*/
typedef struct STag_Dcm_DspPidSendRecFuncs
{
  /*
   Default value: NULL_PTR.
   If none of the DIDs referring to this data have read configured,
   pReadData will be NULL_PTR.

  If DcmDspDataUsePort is USE_DATA_SYNCH_CLIENT_SERVER this shall
   be generated as DataServices_{Data}_ReadData() where
   Data is equal to the shortname of the relevant container DcmDspData.
   If  DcmDspDataUsePort is USE_DATA_SYNCH_FNC, it shall be the function
   name in DcmDspDataReadFnc. */
  P2FUNC(Std_ReturnType, DCM_APPL_CODE, pPidReadData)
  (
    P2VAR(uint8, AUTOMATIC, DCM_VAR) Data
  );

}Dcm_DspPidSendRecFuncs;

/* Design ID : DCM_SDD_6140 */
#define DCM_START_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
extern CONST(Dcm_DspPidSendRecFuncs, DCM_CONST) Dcm_GaaDspPidSendRecFuncs[];
#define DCM_STOP_SEC_CONST_UNSPECIFIED
#include "Dcm_MemMap.h"
#endif

/*******************************************************************************
**                      Function Prototypes                                   **
*******************************************************************************/
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(uint8, DCM_CODE) Dcm_DspOBDReqIDValidation(
    P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_SetNegResponse(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"

#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON)||\
    (DCM_DSP_REQUESTFREEZEFRAME_DATA==STD_ON))
#define DCM_START_SEC_CODE
#include "Dcm_MemMap.h"
extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackPidSyncData
(
  P2CONST(Dcm_DspPidSignal, AUTOMATIC, DCM_CONST) pPidSignal,
  P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentPidFrame
);

extern FUNC(Std_ReturnType, DCM_CODE)Dcm_ReadAndPackPidSRData
(
P2CONST(Dcm_DspPidSignal, AUTOMATIC, DCM_CONST) pPidSignal,
P2VAR(uint8, AUTOMATIC, DCM_VAR) pCurrentPidFrame
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspOBDProcessAvialiabiltyPID
(
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_DspProcessNonAvialiabilityPID
(P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext);

extern FUNC(boolean, DCM_CODE) Dcm_ValidateReadPID
(
  uint8 ReqPID
);

extern FUNC(Std_ReturnType, DCM_CODE) Dcm_ProcessPID
(
  uint8 ReqPID,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext
);
#if((DCM_DSP_REQUESTPOWERTRAIN_DATA == STD_ON) && \
(DCM_READ_DID_SERVICE == STD_ON))
extern FUNC(Std_ReturnType,DCM_CODE) Dcm_DspProcessReadDataByPID
(
  uint16 ReqDID,
  uint8 AvailablitySwitch,
  P2VAR(Dcm_MsgContextType, AUTOMATIC, DCM_VAR) pMsgContext,
  P2VAR(Dcm_NegativeResponseCodeType, AUTOMATIC, DCM_VAR) LddNRC
);
#endif
#define DCM_STOP_SEC_CODE
#include "Dcm_MemMap.h"
#endif
#endif/* DCM_DSPDidCONFIG_H */

/*******************************************************************************
**                          End of File                                       **
*******************************************************************************/
